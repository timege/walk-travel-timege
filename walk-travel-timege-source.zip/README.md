# Walk Travel Timege v0.5.3

- Permanent explored-world cloud mask remains the core mechanic.
- Compact top search panel with safe-area spacing.
- Calmer blue primary controls and smaller location control.
- Destination card shows route distance and approximate walking time.
- Thin navigation route line.
- Floating north compass; tap to reset map bearing.
- Search placeholder remains unchanged.

# Walk Travel Timege — Android v0.5.0

## Главная идея
Одна постоянная карта мира. Всё, что пользователь когда-либо открыл во время движения, сохраняется локально и остаётся открытым между запусками приложения.

## Интерфейс v0.5
- Единый холодный сине-серый стеклянный стиль.
- Закрытые территории покрыты светлыми многослойными облаками белых и серых оттенков.
- Под облаками карта видна слабо.
- Текущее положение — компактная зелёная точка с мягким ореолом.
- Снизу слева — кнопка центрирования.
- Главная кнопка компактная и синяя: «Начать», «В путь» или «Завершить».
- Строка GPS/метров под заголовком убрана.
- Кнопки и карточки поиска приведены к одному стилю.

## Поиск и маршруты
- Поиск объектов через Nominatim / OpenStreetMap.
- Результаты показываются прямо внутри приложения, без системного AlertDialog.
- После выбора объекта строится маршрут через OSRM.
- Маршрут показывается поверх облаков, чтобы оставаться читаемым в закрытой зоне.
- Точка назначения — синий маркер.
- Текущее положение — зелёная точка.

## Исследование мира
- Пешком, велосипед, автомобиль и другой транспорт расширяют одну общую открытую карту.
- История поездок в интерфейсе отсутствует.
- Данные открытых территорий не очищаются при старте нового движения.
- Вокруг текущего положения есть небольшое временное окно в облаках; постоянным участок становится после записи движения.


## Progress backup (v0.5.3)
The layers menu now also contains **Сохранить прогресс** and **Восстановить прогресс**. Backups are portable JSON files and contain all permanently explored GPS tracks. Restore merges data without erasing current progress and skips duplicate samples.

## Android updates
For install-in-place updates, every APK must be signed by the same key. Use the provided `build-apk.yml` together with the private GitHub Actions secret `WTT_DEBUG_KEYSTORE_BASE64`. Never commit the signing keystore or secret value into the public repository.
