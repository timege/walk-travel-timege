# Walk Travel Timege — Android MVP v0.3

Persistent fog-of-world map for Android.

## v0.3
- One permanent explored world map. Previously opened territory is never reset automatically.
- New recordings only add new explored territory.
- No user-facing walk history button.
- Dark frosted-glass fog; the hidden map is only faintly visible.
- Continuous reveal corridor for walking, cycling, driving and public transport.
- Obvious GPS teleports are filtered, but vehicle travel remains valid.
- Updated bottom controls: location button + primary Start/Finish button with pedestrian icon.
- Non-destructive database upgrade from v0.2: existing explored points are retained.
