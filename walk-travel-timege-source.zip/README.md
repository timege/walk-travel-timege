# Walk Travel Timege — v0.2

Android prototype of a fog-of-war travel map.

## v0.2 changes
- continuous revealed corridor instead of disconnected circles;
- all real travel counts: walking, bicycle, car, bus, etc.;
- obvious GPS teleports are rejected while normal vehicle speeds are preserved;
- milky semi-transparent frosted-glass fog with soft reveal edges;
- new application icon;
- database v2 resets the early test-build artefacts once on upgrade.

The debug APK is built by GitHub Actions from this source archive.
