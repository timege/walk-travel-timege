# Walk Travel Timege v0.5.9

- Realistic multi-layer cloud sprites replace the old circular/washed fog.
- Unexplored map is fully covered; explored GPS corridors stay clear permanently.
- Soft feathered cloud edges remain around explored territory.
- Progress stays in kilometers, with `км` on a separate line in the UI.
- Persistent signing/update and backup/restore logic are preserved.

Walk Travel Timege v0.5.8

# Walk Travel Timege v0.5.5

UI: compact left vertical skeuomorphic exploration menu, permanent explored-distance counter, denser cloud cover, thin permanent explored route line, search shown only on demand. Progress backup/restore and update-safe database are preserved.

# Walk Travel Timege — v0.5.4

Android prototype of a persistent exploration map.

## v0.5.4

- New green/lime skeuomorphic visual theme based on the approved mockup.
- Tactile layered search panel, search/layers buttons, location button, compass and Start/Finish button.
- Green route and destination styling.
- Softer irregular cloud clusters for unexplored areas.
- Permanent explored-world progress remains unchanged.
- Backup/restore progress remains available from the layers menu.
- Same application id and incremented versionCode for normal Android updates.


## v0.5.7
- Self-healing permanent explored layer: historical track points are merged back before every render.
- Restore now repopulates explored cloud cutouts even when track history already existed.
- Import verifies persisted explored points before redrawing/focusing the map.


## v0.6.0
- 5 animated cloud layers with slow drift
- explored territory remains permanently cut out of the cloud field
- progress is hidden from the main interface and shown only on tapping the statistics button
- progress popup: total, today, 7 days, last walk, walk count
