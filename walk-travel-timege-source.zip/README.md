# Walk Travel Timege v0.5.5

UI: compact left vertical skeuomorphic exploration menu, permanent explored-distance counter, denser cloud cover, thin permanent explored route line, search shown only on demand. Progress backup/restore and update-safe database are preserved.

# Walk Travel Timege — v0.5.4

Android prototype of a persistent exploration map.

## v0.5.4

- New green/lime skeuomorphic visual theme based on the approved mockup.
- Tactile layered search panel, search/layers buttons, location button, compass and Start/Finish button.
- Green route and destination styling.
- Softer irregular cloud clusters for unexplored areas.
- Permanent explored-world progress remains unchanged.
- Backup/restore progress remains available from the layers menu.
- Same application id and incremented versionCode for normal Android updates.
