# Walk Travel Timege — v0.5.4

Android prototype of a persistent exploration map.

## v0.5.4

- New green/lime skeuomorphic visual theme based on the approved mockup.
- Tactile layered search panel, search/layers buttons, location button, compass and Start/Finish button.
- Green route and destination styling.
- Softer irregular cloud clusters for unexplored areas.
- Permanent explored-world progress remains unchanged.
- Backup/restore progress remains available from the layers menu.
- Same application id and incremented versionCode for normal Android updates.
