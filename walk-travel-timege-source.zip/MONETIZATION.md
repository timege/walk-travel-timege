# Monetization plan — Walk Travel Timege

Recommended model: **freemium + optional Pro subscription + lifetime unlock**.

## Free
- Fog-of-war map and walking mode.
- Local history.
- Basic stats.
- Enough functionality to understand the product and form a habit.

## Pro subscription
Suggested launch test: €2.99/month or €19.99/year, with localized prices.
- Cloud backup/sync between devices.
- Unlimited long-term history and advanced statistics.
- Offline map packs.
- GPX import/export.
- Achievements/challenges and richer map themes.
- Shareable exploration cards / yearly recap.

## Lifetime
Suggested launch test: €39.99–59.99 one-time.
Useful for users who dislike subscriptions and gives early cash flow.

## What should NOT be paywalled at launch
Do not charge for the core “walk and reveal the map” mechanic immediately. The user needs to experience the hook first.

## Ads
Avoid banner/interstitial ads in the walking experience. If ads are ever tested, use an optional rewarded ad for a non-core cosmetic benefit; paid Pro should be ad-free.

## Google Play implementation
Digital subscriptions and one-time unlocks distributed through Google Play should use Google Play Billing. Billing integration can be added after retention is validated in the MVP.
