# Google Play Data Safety — preparation notes

These answers are based on the audited 1.0.0 source. Re-check them in Play Console if SDKs or network features change.

## Data processed by the App

### Precise location
Purpose: App functionality — map position, route recording, distance, explored-map progress and routing.

Recorded walk/location history is stored locally in Android private app storage and is not uploaded to a developer-operated cloud account.

Important third-party transmission: when the user explicitly requests routing, start/destination coordinates are sent to the OSRM routing service. Map requests also contact OpenFreeMap. Standard network metadata such as IP address is necessarily visible to remote services.

### Search queries
When the user performs place search, the query is sent to Nominatim / OpenStreetMap to return search results.

### App activity / locally stored history
Walks, track points, explored areas and related preferences are maintained locally on the device.

## Accounts
No account creation or login in the audited 1.0.0 build.

## Advertising
No advertising SDK found in the audited source.

## Analytics
No dedicated analytics SDK found in the audited source.

## Data sale
No code or integration indicating sale of personal data found in the audited source.

## Encryption in transit
The App's configured network endpoints use HTTPS and Android cleartext traffic is disabled.

## User deletion
Local App data can be removed by App functionality where provided, by clearing App storage, or by uninstalling the App. GPX files exported by the user are outside App-private storage and must be managed by the user.

## Play Console caution
Google Play's Data Safety form definitions distinguish collection from some forms of ephemeral processing and service-provider transfers. Answer the Console's exact current questions based on the final published build and the role of each third-party service. Do not simply copy a yes/no answer from this document without reading the form wording.
