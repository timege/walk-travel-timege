# Walk Travel Timege 0.9.6 — POI interface disabled, build preparation fixed

This revision has NOT been compiled. Compilation requires the user's approval.
Base APK 0.9.6 was built successfully; that does not validate these new changes.

Failure diagnosed from GitHub Actions run 35478597165:
the uploaded ZIP contained android-src/, while the workflow unpacked it inside
another android-src/. The build stopped before Gradle on a missing settings file.
The legacy cumulative patch was also intended for source 0.9.2, not a full 0.9.6 ZIP.

Fixes:
- Source archive now has the Android project at the ZIP root.
- Draft workflow detects either ZIP layout and builds complete sources without old patches.
- POI button, markers, previews, cards, discovery banners, walk summary POI rows,
  widget POI count and notification entry points are disabled by PLACES_UI_ENABLED.
- Background POI discovery and feed sync are paused while the feature is disabled.
- Existing POI data, import/export architecture and implementation are retained.
- User's ocean polygon seam fix and localized widget distances are retained.
- Walking, GPS, offline downloads and sea visibility are preserved.

Validation: ZIP integrity, both archive layouts unpacked by the exact CI helper,
XML parsing and source diff review. No Kotlin/Gradle compilation or device test.

Build: Java 17, Gradle 9.6.0, Android SDK platform 37 and build-tools 36.0.0.
Run installed Gradle from project root: gradle :app:assembleDebug
The archive has no gradle-wrapper.jar. The signing key remains in GitHub secrets.

CI_IMPORTANT: Replacing only the source ZIP under the old main workflow is not enough.
Use the matching workflow from draft/fix-096-no-poi-build before the next build.
