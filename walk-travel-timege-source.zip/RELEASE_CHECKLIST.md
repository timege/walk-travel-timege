# Walk Travel Timege 1.0.0 — Release Checklist

## Code / security — complete
- [x] versionName 1.0.0
- [x] versionCode 46
- [x] targetSdk 36
- [x] compileSdk 37
- [x] minSdk 26
- [x] HTTPS-only application configuration
- [x] App backup disabled
- [x] Private location/history excluded from backup and device transfer rules
- [x] TrackingService not exported
- [x] Widget receiver not exported
- [x] No embedded API tokens/passwords found in source audit
- [x] Release minification and resource shrinking enabled
- [x] Existing functional GPS/map/tracking logic left unchanged during release hardening

## Before Play upload
- [ ] Create a permanent upload keystore and store it outside GitHub
- [ ] Configure RELEASE_STORE_FILE, RELEASE_STORE_PASSWORD, RELEASE_KEY_ALIAS, RELEASE_KEY_PASSWORD
- [ ] Build: ./gradlew :app:bundleRelease
- [ ] Verify generated AAB signature / upload through Play App Signing
- [ ] Install/test release build on at least one Android 16 device and one older supported device
- [ ] Test fresh install permission flow
- [ ] Test tracking with screen off for 20+ minutes
- [ ] Test GPS loss/recovery
- [ ] Test GPX import/export
- [ ] Test search and routing

## Play Console
- [ ] Create app listing
- [ ] Add support email (required in Play Console)
- [ ] Publish Privacy Policy on a public HTTPS page
- [ ] Add Privacy Policy URL to Play Console
- [ ] Complete Data Safety form using DATA_SAFETY.md as audit notes
- [ ] Complete Location/foreground-service declarations requested by Play Console
- [ ] Upload phone screenshots
- [ ] Upload 512×512 app icon
- [ ] Upload 1024×500 feature graphic
- [ ] Complete content rating
- [ ] Set target countries/regions and pricing
- [ ] Internal testing track first
- [ ] Review pre-launch report
- [ ] Production rollout
