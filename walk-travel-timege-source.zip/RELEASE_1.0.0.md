# Walk Travel Timege 1.0.0

Production release candidate.

- Version code: 46
- Target SDK: 36
- Minimum SDK: 26
- Core GPS, fog/map and track-recording behavior retained from the validated GitHub build.
- Android backup disabled for private route/location data.
- Cleartext network traffic disabled.
- Release minification/resource shrinking enabled.
- Release signing supports secrets supplied externally; no production key or password belongs in source control.
- Privacy Policy, Store listing, Data Safety audit notes and release checklist included in the source archive.
