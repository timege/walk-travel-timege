# Privacy Policy — Walk Travel Timege

Last updated: September 27, 2026

Walk Travel Timege ("the App") is a map exploration and route-tracking application. This policy explains what information the App processes and how it is used.

## Location data

The App uses precise device location while you use route tracking and map exploration features. Location is used to:

- show your position on the map;
- record walks and routes;
- calculate distance;
- reveal areas of the map you have explored;
- provide navigation-related features.

Your recorded route history and explored-area data are stored locally on your device in the App's private storage. The App does not upload your recorded walk history to a developer-operated account or cloud database.

The App uses a foreground location service while an active walk is being recorded. Android displays a persistent notification while this service is running.

## Third-party map and routing services

Some features require network requests to third-party services:

- OpenFreeMap is used to load map data/style resources.
- Nominatim / OpenStreetMap is used when you perform a place search. Your search query is sent to that service.
- OSRM is used when you request a route. The route request includes the route start and destination coordinates required to calculate that route.
- A Normal Thai endpoint may be contacted to retrieve the optional places catalogue used by the App's existing discovery architecture.

These services may receive standard network information such as your IP address and request metadata. Their handling of information is governed by their own privacy policies and terms.

## Files and GPX

GPX import and export use Android's system document picker. The App accesses only files you explicitly select or destinations you explicitly choose for export.

## Notifications

The App may request notification permission so Android can show the persistent foreground-service notification required while route tracking is active and related App notifications.

## Backups

The App disables Android application backup and excludes its private location, route, preferences and internal files from Android cloud backup and device-to-device transfer rules.

## Accounts, advertising and analytics

The App does not require an account. The current version does not include developer-operated advertising or analytics SDKs and does not sell personal data.

## Data retention and deletion

Route and exploration information remains on your device until it is removed through App functionality, App data is cleared, or the App is uninstalled. Exported GPX files remain wherever you chose to save them and are controlled by you.

## Security

Network connections configured by the App use HTTPS. Cleartext HTTP traffic is disabled. App-private data is stored in Android private application storage.

## Children

The App is a general-purpose map and activity application and is not specifically directed to children.

## Changes

This policy may be updated when App functionality or data practices change. The updated policy will show a new "Last updated" date.

## Contact

Website: https://normalthai.ru/
