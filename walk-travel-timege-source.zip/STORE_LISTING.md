# Google Play Store Listing — Walk Travel Timege

## App name
Walk Travel Timege

## Short description
Explore the real world and reveal the map as you walk, ride and travel.

## Full description
Walk Travel Timege turns everyday movement into exploration.

The map starts covered. As you walk, ride and travel, the places you have actually visited are revealed and remain part of your personal explored world.

Track a walk, watch new territory appear on the map and gradually build a visual history of where you have been.

Key features:
- Reveal the map by physically exploring the real world
- Record walks and routes with GPS
- Keep explored territory between sessions
- See distance and activity progress
- Import and export GPX routes
- Use map search and routing tools
- Continue active tracking with the screen off using an Android foreground service
- Keep recorded route history locally on your device

There are no accounts required. The core experience is simple: go somewhere and uncover it.

Location permission is required for GPS tracking and map exploration. During an active walk, Android shows a persistent notification while location tracking is running.

## Suggested category
Maps & Navigation

## Suggested tags / positioning
walking, exploration, GPS, map, travel, route tracking, outdoor

## Release notes — 1.0.0
First public release of Walk Travel Timege.

Explore the real world, record your routes and reveal the map as you move.
