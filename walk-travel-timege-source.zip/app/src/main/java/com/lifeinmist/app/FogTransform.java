package com.lifeinmist.app;

/** Camera geometry shared by the mask renderer and host-side regression tests. */
public final class FogTransform {
    private FogTransform() {}
    public static double scale(double zoom, double cachedZoom) {
        return Math.pow(2.0, zoom - cachedZoom);
    }
    public static double rotation(double bearing, double cachedBearing) {
        // Camera bearing is clockwise; the map on screen rotates counter-clockwise.
        double angle = (cachedBearing - bearing) % 360.0;
        if (angle > 180.0) angle -= 360.0;
        if (angle < -180.0) angle += 360.0;
        return angle;
    }
    public static boolean covers(double width, double height, double centerX, double centerY,
                                 double halfWidth, double halfHeight, double degrees) {
        if (!(halfWidth > 0 && halfHeight > 0)) return false;
        double radians = Math.toRadians(degrees);
        double cos = Math.cos(radians), sin = Math.sin(radians);
        for (double x : new double[] {-8, width + 8}) {
            for (double y : new double[] {-8, height + 8}) {
                double dx = x - centerX, dy = y - centerY;
                double localX = cos * dx + sin * dy;
                double localY = -sin * dx + cos * dy;
                if (Math.abs(localX) > halfWidth || Math.abs(localY) > halfHeight) return false;
            }
        }
        return true;
    }
}
