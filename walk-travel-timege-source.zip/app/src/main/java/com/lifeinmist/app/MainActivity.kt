package com.lifeinmist.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import org.maplibre.android.MapLibre
import org.maplibre.android.annotations.Marker
import org.maplibre.android.annotations.MarkerOptions
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private lateinit var mapView: MapView
    private lateinit var fogOverlay: FogOverlay
    private lateinit var database: MistDatabase
    private lateinit var startStopButton: Button
    private lateinit var statusText: TextView
    private lateinit var statsText: TextView

    private var map: MapLibreMap? = null
    private var locationMarker: Marker? = null
    private var tracking = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                TrackingService.ACTION_LOCATION_UPDATE -> {
                    val lat = intent.getDoubleExtra(TrackingService.EXTRA_LAT, Double.NaN)
                    val lon = intent.getDoubleExtra(TrackingService.EXTRA_LON, Double.NaN)
                    val accuracy = intent.getFloatExtra(TrackingService.EXTRA_ACCURACY, 0f)
                    val distance = intent.getDoubleExtra(TrackingService.EXTRA_DISTANCE, 0.0)
                    if (!lat.isNaN() && !lon.isNaN()) {
                        updateCurrentLocation(lat, lon)
                    }
                    statsText.text = "${formatDistance(distance)}  •  GPS ±${accuracy.roundToInt()} м"
                    refreshFog()
                }

                TrackingService.ACTION_TRACKING_STOPPED -> {
                    tracking = false
                    updateTrackingUi()
                    refreshFog()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        database = MistDatabase(this)
        tracking = database.activeWalk() != null

        buildUi(savedInstanceState)
        registerTrackingReceiver()
        initMap()
        updateTrackingUi()
    }

    private fun buildUi(savedInstanceState: Bundle?) {
        val root = FrameLayout(this)

        mapView = MapView(this)
        mapView.onCreate(savedInstanceState)
        root.addView(
            mapView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        fogOverlay = FogOverlay(this)
        root.addView(
            fogOverlay,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val topCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = roundedBackground(Color.argb(225, 17, 19, 23), 18f)
        }
        statusText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 17f
        }
        statsText = TextView(this).apply {
            setTextColor(Color.LTGRAY)
            textSize = 13f
            text = "Мир ждёт, пока ты его откроешь"
        }
        topCard.addView(statusText)
        topCard.addView(statsText)
        root.addView(
            topCard,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP
            ).apply {
                setMargins(dp(16), dp(18), dp(16), 0)
            }
        )

        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = roundedBackground(Color.argb(235, 17, 19, 23), 22f)
        }

        val historyButton = Button(this).apply {
            text = "История"
            setOnClickListener { showHistory() }
        }
        val centerButton = Button(this).apply {
            text = "⌖"
            setOnClickListener { centerOnLastLocation() }
        }
        startStopButton = Button(this).apply {
            setOnClickListener {
                if (tracking) stopWalk() else ensurePermissionAndStart()
            }
        }

        bottomBar.addView(historyButton, LinearLayout.LayoutParams(0, dp(52), 1f))
        bottomBar.addView(centerButton, LinearLayout.LayoutParams(dp(64), dp(52)).apply {
            marginStart = dp(8)
            marginEnd = dp(8)
        })
        bottomBar.addView(startStopButton, LinearLayout.LayoutParams(0, dp(52), 1.3f))

        root.addView(
            bottomBar,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            ).apply {
                setMargins(dp(12), 0, dp(12), dp(18))
            }
        )

        setContentView(root)
    }

    private fun initMap() {
        mapView.getMapAsync { readyMap ->
            map = readyMap
            fogOverlay.map = readyMap
            readyMap.uiSettings.isRotateGesturesEnabled = true
            readyMap.uiSettings.isTiltGesturesEnabled = false
            readyMap.setStyle(MAP_STYLE_URL) {
                readyMap.cameraPosition = CameraPosition.Builder()
                    .target(LatLng(20.0, 0.0))
                    .zoom(2.0)
                    .build()
                refreshFog()
                centerOnLastLocation()
            }
            readyMap.addOnCameraMoveListener { fogOverlay.invalidate() }
            readyMap.addOnCameraIdleListener { fogOverlay.invalidate() }
        }
    }

    private fun ensurePermissionAndStart() {
        val fineGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fineGranted) {
            val permissions = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
            ActivityCompat.requestPermissions(this, permissions.toTypedArray(), REQUEST_LOCATION)
            return
        }
        startWalk()
    }

    private fun startWalk() {
        tracking = true
        updateTrackingUi()
        val intent = Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_START)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopWalk() {
        startService(Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_STOP))
        tracking = false
        updateTrackingUi()
    }

    private fun updateTrackingUi() {
        if (tracking) {
            statusText.text = "Прогулка идёт"
            startStopButton.text = "Завершить"
            database.activeWalk()?.let { statsText.text = "${formatDistance(it.distanceM)}  •  открываем карту" }
        } else {
            statusText.text = "Walk Travel Timege"
            startStopButton.text = "Начать прогулку"
            statsText.text = "Двигайся — карта открывается по пути"
        }
    }

    private fun updateCurrentLocation(lat: Double, lon: Double) {
        val currentMap = map ?: return
        val position = LatLng(lat, lon)
        val existing = locationMarker
        if (existing == null) {
            locationMarker = currentMap.addMarker(
                MarkerOptions()
                    .position(position)
                    .title("Вы здесь")
            )
            currentMap.animateCamera(
                org.maplibre.android.camera.CameraUpdateFactory.newLatLngZoom(position, 16.5)
            )
        } else {
            existing.position = position
        }
    }

    private fun refreshFog() {
        fogOverlay.setTrackPoints(database.trackPoints())
    }

    private fun centerOnLastLocation() {
        val fineGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fineGranted && !coarseGranted) return

        LocationServices.getFusedLocationProviderClient(this).lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                updateCurrentLocation(location.latitude, location.longitude)
                map?.animateCamera(
                    org.maplibre.android.camera.CameraUpdateFactory.newLatLngZoom(
                        LatLng(location.latitude, location.longitude),
                        16.5
                    )
                )
            }
        }
    }

    private fun showHistory() {
        val walks = database.walks()
        if (walks.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("История")
                .setMessage("Пока нет прогулок. Начни первую — и карта начнёт открываться.")
                .setPositiveButton("ОК", null)
                .show()
            return
        }

        val formatter = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
        val items = walks.map { walk ->
            val end = walk.endedAt ?: System.currentTimeMillis()
            val duration = (end - walk.startedAt).coerceAtLeast(0L)
            val active = if (walk.endedAt == null) "  •  сейчас" else ""
            "${formatter.format(Date(walk.startedAt))}\n${formatDistance(walk.distanceM)}  •  ${formatDuration(duration)}$active"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("История прогулок")
            .setItems(items, null)
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun registerTrackingReceiver() {
        val filter = IntentFilter().apply {
            addAction(TrackingService.ACTION_LOCATION_UPDATE)
            addAction(TrackingService.ACTION_TRACKING_STOPPED)
        }
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_LOCATION) {
            val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (granted) startWalk()
            else AlertDialog.Builder(this)
                .setTitle("Нужна геолокация")
                .setMessage("Без точной геолокации приложение не сможет открывать карту по маршруту прогулки.")
                .setPositiveButton("ОК", null)
                .show()
        }
    }

    private fun formatDistance(meters: Double): String =
        if (meters < 1000.0) "${meters.roundToInt()} м" else String.format(Locale.getDefault(), "%.2f км", meters / 1000.0)

    private fun formatDuration(ms: Long): String {
        val minutes = ms / 60_000L
        val hours = minutes / 60
        val rest = minutes % 60
        return if (hours > 0) "${hours} ч ${rest} мин" else "${rest} мин"
    }

    private fun roundedBackground(color: Int, radiusDp: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp.toInt()).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    override fun onStart() {
        super.onStart()
        mapView.onStart()
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
        tracking = database.activeWalk() != null
        updateTrackingUi()
        refreshFog()
    }

    override fun onPause() {
        mapView.onPause()
        super.onPause()
    }

    override fun onStop() {
        mapView.onStop()
        super.onStop()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView.onLowMemory()
    }

    override fun onDestroy() {
        unregisterReceiver(receiver)
        mapView.onDestroy()
        database.close()
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        mapView.onSaveInstanceState(outState)
    }

    companion object {
        private const val REQUEST_LOCATION = 7001
        private const val MAP_STYLE_URL = "https://tiles.openfreemap.org/styles/liberty"
    }
}
