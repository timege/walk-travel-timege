package com.lifeinmist.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.location.LocationServices
import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private lateinit var mapView: MapView
    private lateinit var cloudOverlay: FogOverlay
    private lateinit var navigationOverlay: NavigationOverlay
    private lateinit var database: MistDatabase

    private lateinit var sidePanel: LinearLayout
    private lateinit var topPanel: LinearLayout
    private lateinit var searchRow: LinearLayout
    private lateinit var searchInput: EditText
    private lateinit var statusText: TextView
    private lateinit var searchResultsPanel: LinearLayout
    private lateinit var destinationCard: LinearLayout
    private lateinit var destinationTitle: TextView
    private lateinit var destinationSubtitle: TextView
    private lateinit var startStopButton: Button
    private lateinit var exploredValueText: TextView
    private lateinit var compassArrow: TextView
    private lateinit var centerButton: ImageButton
    private lateinit var compassButton: FrameLayout

    private var map: MapLibreMap? = null
    private var tracking = false
    private var followNavigation = false
    private var currentLocation: LatLng? = null
    private var currentAccuracyM: Float = 0f
    private var destination: SearchPlace? = null
    private var routePoints: List<LatLng> = emptyList()
    private var selectedMapStyle = 0
    private var pendingStartAfterPermission = false
    private var routeBuilding = false
    private var routeDistanceM: Double = 0.0
    private var routeDurationS: Double = 0.0

    private data class SearchPlace(
        val name: String,
        val lat: Double,
        val lon: Double
    )

    private val exportProgressLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        thread {
            try {
                val json = database.exportProgressJson()
                contentResolver.openOutputStream(uri, "w")?.bufferedWriter()?.use { it.write(json) }
                    ?: error("Cannot open backup file")
                runOnUiThread {
                    Toast.makeText(this, "Резервная копия сохранена", Toast.LENGTH_LONG).show()
                }
            } catch (_: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Не удалось сохранить копию", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private val importProgressLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        thread {
            try {
                val json = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: error("Cannot read backup file")
                val restored = database.importProgressJson(json)
                runOnUiThread {
                    // Read back from the persistent layer after import instead of trusting
                    // only the import counters. This also exercises the DB self-heal path.
                    val persistedExplored = database.exploredPoints()
                    refreshClouds()
                    cloudOverlay.postInvalidateOnAnimation()
                    navigationOverlay.postInvalidateOnAnimation()
                    if (persistedExplored.isNotEmpty()) focusOnExploredArea()
                    Toast.makeText(
                        this,
                        if (persistedExplored.isNotEmpty()) {
                            "Исследованные территории загружены: ${persistedExplored.size} точек"
                        } else {
                            "В резервной копии нет точек исследования"
                        },
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (_: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Это не резервная копия Walk Travel Timege", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                TrackingService.ACTION_LOCATION_UPDATE -> {
                    val lat = intent.getDoubleExtra(TrackingService.EXTRA_LAT, Double.NaN)
                    val lon = intent.getDoubleExtra(TrackingService.EXTRA_LON, Double.NaN)
                    currentAccuracyM = intent.getFloatExtra(TrackingService.EXTRA_ACCURACY, 0f)
                    if (!lat.isNaN() && !lon.isNaN()) {
                        updateCurrentLocation(lat, lon, followNavigation)
                    }
                    refreshClouds()
                }

                TrackingService.ACTION_TRACKING_STOPPED -> {
                    tracking = false
                    followNavigation = false
                    updateUiState()
                    refreshClouds()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        database = MistDatabase(this)
        tracking = database.activeWalk() != null
        selectedMapStyle = getSharedPreferences("ui", MODE_PRIVATE).getInt("mapStyle", 0)
            .coerceIn(0, MAP_STYLES.lastIndex)

        buildUi(savedInstanceState)
        registerTrackingReceiver()
        initMap()
        updateUiState()
    }

    private fun buildUi(savedInstanceState: Bundle?) {
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(234, 242, 231))
        }

        mapView = MapView(this)
        mapView.onCreate(savedInstanceState)
        root.addView(mapView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        cloudOverlay = FogOverlay(this)
        root.addView(cloudOverlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        navigationOverlay = NavigationOverlay(this)
        root.addView(navigationOverlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // Compact vertical exploration menu on the left: search, layers, stats, real progress.
        sidePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(7), dp(8), dp(7), dp(8))
            background = sidePanelBackground()
            elevation = dp(10).toFloat()
        }

        val searchMenuButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_search)
            setColorFilter(Color.rgb(20, 94, 35))
            background = roundGlassButtonBackground()
            setPadding(dp(13), dp(13), dp(13), dp(13))
            contentDescription = "Поиск места"
            setOnClickListener { toggleSearchPanel() }
        }
        sidePanel.addView(searchMenuButton, LinearLayout.LayoutParams(dp(54), dp(54)).apply { bottomMargin = dp(6) })

        val layersMenuButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_layers)
            setColorFilter(Color.rgb(20, 94, 35))
            background = roundGlassButtonBackground()
            setPadding(dp(13), dp(13), dp(13), dp(13))
            contentDescription = "Карты и резервная копия"
            setOnClickListener { showMapMenu(this) }
        }
        sidePanel.addView(layersMenuButton, LinearLayout.LayoutParams(dp(54), dp(54)).apply { bottomMargin = dp(6) })

        val statsMenuButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_stats)
            setColorFilter(Color.rgb(20, 94, 35))
            background = roundGlassButtonBackground()
            setPadding(dp(13), dp(13), dp(13), dp(13))
            contentDescription = "Статистика исследования"
            setOnClickListener { showStats(this) }
        }
        sidePanel.addView(statsMenuButton, LinearLayout.LayoutParams(dp(54), dp(54)).apply { bottomMargin = dp(7) })

        val progressCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(8), dp(4), dp(8))
            background = progressCardBackground()
            setOnClickListener { showStats(this) }
        }
        val progressLabel = TextView(this).apply {
            text = "Исследовано"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 10f
        }
        exploredValueText = TextView(this).apply {
            text = "0 м"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 17f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        progressCard.addView(progressLabel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        progressCard.addView(exploredValueText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(2) })
        sidePanel.addView(progressCard, LinearLayout.LayoutParams(dp(60), dp(68)))

        root.addView(
            sidePanel,
            FrameLayout.LayoutParams(dp(74), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START).apply {
                setMargins(dp(12), dp(14), 0, 0)
            }
        )

        // Search is secondary: it appears only after tapping the magnifier in the side menu.
        topPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = compactPanelBackground()
            elevation = dp(11).toFloat()
            visibility = View.GONE
        }
        searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        searchInput = EditText(this).apply {
            hint = "Куда отправимся?"
            setHintTextColor(Color.rgb(79, 103, 80))
            setTextColor(Color.rgb(38, 70, 43))
            textSize = 15f
            setSingleLine(true)
            background = searchFieldBackground()
            setPadding(dp(14), 0, dp(10), 0)
            setOnEditorActionListener { _, _, _ ->
                searchPlaces()
                true
            }
        }
        searchRow.addView(searchInput, LinearLayout.LayoutParams(0, dp(46), 1f))

        val executeSearch = ImageButton(this).apply {
            setImageResource(R.drawable.ic_search)
            setColorFilter(Color.rgb(20, 94, 35))
            background = roundGlassButtonBackground()
            setPadding(dp(11), dp(11), dp(11), dp(11))
            contentDescription = "Найти"
            setOnClickListener { searchPlaces() }
        }
        searchRow.addView(executeSearch, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginStart = dp(7) })

        val closeSearch = TextView(this).apply {
            text = "×"
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(48, 92, 53))
            textSize = 25f
            setOnClickListener {
                topPanel.visibility = View.GONE
                hideSearchResults()
                hideKeyboard()
            }
        }
        searchRow.addView(closeSearch, LinearLayout.LayoutParams(dp(36), dp(46)).apply { marginStart = dp(4) })
        topPanel.addView(searchRow)

        statusText = TextView(this).apply {
            setTextColor(Color.rgb(49, 90, 54))
            textSize = 12f
            setPadding(dp(8), dp(6), dp(4), 0)
            visibility = View.GONE
        }
        topPanel.addView(statusText)

        root.addView(
            topPanel,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
                setMargins(dp(98), dp(14), dp(14), 0)
            }
        )

        searchResultsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = lightGlassCardBackground()
            elevation = dp(12).toFloat()
            visibility = View.GONE
        }
        root.addView(
            searchResultsPanel,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
                setMargins(dp(98), dp(76), dp(14), 0)
            }
        )

        destinationCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(8), dp(10))
            background = lightGlassCardBackground()
            elevation = dp(10).toFloat()
            visibility = View.GONE
        }
        val pinBadge = TextView(this).apply {
            text = "●"
            gravity = Gravity.CENTER
            textSize = 20f
            setTextColor(Color.WHITE)
            background = destinationBadgeBackground()
        }
        destinationCard.addView(pinBadge, LinearLayout.LayoutParams(dp(42), dp(42)))

        val destinationTextColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, dp(6), 0)
        }
        destinationTitle = TextView(this).apply {
            setTextColor(Color.rgb(31, 72, 39))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 1
        }
        destinationSubtitle = TextView(this).apply {
            setTextColor(Color.rgb(70, 132, 71))
            textSize = 12f
            setPadding(0, dp(2), 0, 0)
            maxLines = 1
        }
        destinationTextColumn.addView(destinationTitle)
        destinationTextColumn.addView(destinationSubtitle)
        destinationCard.addView(destinationTextColumn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val closeDestination = TextView(this).apply {
            text = "×"
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(70, 104, 74))
            textSize = 24f
            setOnClickListener { clearDestination() }
        }
        destinationCard.addView(closeDestination, LinearLayout.LayoutParams(dp(36), dp(42)))
        root.addView(
            destinationCard,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
                setMargins(dp(98), dp(14), dp(14), 0)
            }
        )

        centerButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_my_location)
            setColorFilter(Color.rgb(20, 94, 35))
            background = locateButtonBackground()
            setPadding(dp(13), dp(13), dp(13), dp(13))
            contentDescription = "Показать меня"
            elevation = dp(8).toFloat()
            setOnClickListener { centerOnLastLocation() }
        }
        root.addView(
            centerButton,
            FrameLayout.LayoutParams(dp(52), dp(52), Gravity.BOTTOM or Gravity.START).apply {
                setMargins(dp(18), 0, 0, dp(20))
            }
        )

        startStopButton = Button(this).apply {
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            minWidth = dp(138)
            minHeight = 0
            setPadding(dp(28), 0, dp(28), 0)
            elevation = dp(10).toFloat()
            background = primaryButtonBackground()
            setOnClickListener {
                when {
                    tracking -> stopWalk()
                    destination != null && routePoints.isNotEmpty() -> ensurePermissionAndStart()
                    destination != null && !routeBuilding -> buildRoute()
                    else -> ensurePermissionAndStart()
                }
            }
        }
        root.addView(
            startStopButton,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                setMargins(0, 0, 0, dp(20))
            }
        )

        compassButton = FrameLayout(this).apply {
            background = locateButtonBackground()
            elevation = dp(8).toFloat()
            contentDescription = "Компас. Вернуть север вверх"
            setOnClickListener { resetNorth() }
        }
        compassArrow = TextView(this).apply {
            text = "▲"
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(20, 94, 35))
            textSize = 17f
        }
        compassButton.addView(
            compassArrow,
            FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER).apply { topMargin = -dp(4) }
        )
        val northLabel = TextView(this).apply {
            text = "N"
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(20, 94, 35))
            textSize = 10f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        compassButton.addView(
            northLabel,
            FrameLayout.LayoutParams(dp(24), dp(18), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(4) }
        )
        root.addView(
            compassButton,
            FrameLayout.LayoutParams(dp(52), dp(52), Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(18), dp(20))
            }
        )

        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())

            (sidePanel.layoutParams as FrameLayout.LayoutParams).apply {
                topMargin = bars.top + dp(14)
                sidePanel.layoutParams = this
            }
            (topPanel.layoutParams as FrameLayout.LayoutParams).apply {
                topMargin = bars.top + dp(14)
                topPanel.layoutParams = this
            }
            (searchResultsPanel.layoutParams as FrameLayout.LayoutParams).apply {
                topMargin = bars.top + dp(76)
                searchResultsPanel.layoutParams = this
            }
            (destinationCard.layoutParams as FrameLayout.LayoutParams).apply {
                topMargin = bars.top + dp(14)
                destinationCard.layoutParams = this
            }
            (centerButton.layoutParams as FrameLayout.LayoutParams).apply {
                bottomMargin = bars.bottom + dp(18)
                centerButton.layoutParams = this
            }
            (startStopButton.layoutParams as FrameLayout.LayoutParams).apply {
                bottomMargin = bars.bottom + dp(18)
                startStopButton.layoutParams = this
            }
            (compassButton.layoutParams as FrameLayout.LayoutParams).apply {
                bottomMargin = bars.bottom + dp(18)
                compassButton.layoutParams = this
            }
            insets
        }
        ViewCompat.requestApplyInsets(root)
    }

    private fun initMap() {
        mapView.getMapAsync { readyMap ->
            map = readyMap
            cloudOverlay.map = readyMap
            navigationOverlay.map = readyMap
            readyMap.uiSettings.isRotateGesturesEnabled = true
            readyMap.uiSettings.isTiltGesturesEnabled = false
            applyMapStyle(initial = true)
            readyMap.addOnCameraMoveListener {
                cloudOverlay.invalidate()
                navigationOverlay.invalidate()
                updateCompass()
            }
            readyMap.addOnCameraIdleListener {
                cloudOverlay.invalidate()
                navigationOverlay.invalidate()
            }
        }
    }

    private fun applyMapStyle(initial: Boolean = false) {
        val readyMap = map ?: return
        readyMap.setStyle(MAP_STYLES[selectedMapStyle].second) {
            if (initial) {
                readyMap.cameraPosition = CameraPosition.Builder()
                    .target(LatLng(20.0, 0.0))
                    .zoom(2.0)
                    .build()
            }
            refreshClouds()
            navigationOverlay.setCurrentLocation(currentLocation)
            navigationOverlay.setDestination(destination?.let { LatLng(it.lat, it.lon) })
            navigationOverlay.setRoute(routePoints)
            if (initial) centerOnLastLocation()
        }
    }

    private fun toggleSearchPanel() {
        if (topPanel.visibility == View.VISIBLE) {
            topPanel.visibility = View.GONE
            hideSearchResults()
            hideKeyboard()
            return
        }
        destinationCard.visibility = View.GONE
        topPanel.visibility = View.VISIBLE
        statusText.visibility = View.GONE
        searchInput.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun showMapMenu(anchor: View) {
        PopupMenu(this, anchor).apply {
            menu.add(0, MENU_MAP_NORMAL, 0, if (selectedMapStyle == 0) "✓ Карта: обычная" else "Карта: обычная")
            menu.add(0, MENU_MAP_LIGHT, 1, if (selectedMapStyle == 1) "✓ Карта: светлая" else "Карта: светлая")
            menu.add(0, MENU_BACKUP_EXPORT, 3, "Сохранить прогресс")
            menu.add(0, MENU_BACKUP_IMPORT, 4, "Восстановить прогресс")
            setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    MENU_MAP_NORMAL -> setMapStyle(0)
                    MENU_MAP_LIGHT -> setMapStyle(1)
                    MENU_BACKUP_EXPORT -> exportProgressBackup()
                    MENU_BACKUP_IMPORT -> importProgressBackup()
                }
                true
            }
            show()
        }
    }

    private fun showStats(anchor: View) {
        val totalM = database.totalDistanceM()
        val walksCount = database.walks().size
        val pointsCount = database.totalTrackPoints()
        PopupMenu(this, anchor).apply {
            menu.add("Исследовано: ${formatDistance(totalM)}").isEnabled = false
            menu.add("Записей движения: $walksCount").isEnabled = false
            menu.add("GPS-точек сохранено: $pointsCount").isEnabled = false
            show()
        }
    }

    private fun setMapStyle(index: Int) {
        if (index !in MAP_STYLES.indices || index == selectedMapStyle) return
        selectedMapStyle = index
        getSharedPreferences("ui", MODE_PRIVATE).edit().putInt("mapStyle", selectedMapStyle).apply()
        applyMapStyle()
    }

    private fun exportProgressBackup() {
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        exportProgressLauncher.launch("walk-travel-timege-progress-$date.json")
    }

    private fun importProgressBackup() {
        importProgressLauncher.launch(arrayOf("application/json", "text/plain", "application/octet-stream"))
    }

    private fun ensurePermissionAndStart() {
        val fineGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fineGranted) {
            pendingStartAfterPermission = true
            val permissions = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
            ActivityCompat.requestPermissions(this, permissions.toTypedArray(), REQUEST_LOCATION)
            return
        }
        startWalk()
    }

    private fun startWalk() {
        tracking = true
        followNavigation = destination != null
        topPanel.visibility = View.GONE
        hideSearchResults()
        updateUiState()
        val intent = Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_START)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopWalk() {
        startService(Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_STOP))
        tracking = false
        followNavigation = false
        updateUiState()
    }

    private fun updateUiState() {
        val hasDestination = destination != null
        val routeReady = routePoints.size > 1

        if (tracking) {
            startStopButton.text = "Завершить"
            startStopButton.isEnabled = true
            startStopButton.alpha = 1f
            startStopButton.background = primaryButtonBackground()
            destinationCard.visibility = if (hasDestination) View.VISIBLE else View.GONE
            if (hasDestination) {
                destinationTitle.text = shortName(destination!!.name)
                destinationSubtitle.text = if (routeReady) routeSummaryText() else "Маршрут активен"
            }
            updateExploredProgress()
            return
        }

        if (hasDestination) {
            topPanel.visibility = View.GONE
            hideSearchResults()
            destinationCard.visibility = View.VISIBLE
            destinationTitle.text = shortName(destination!!.name)
            destinationSubtitle.text = when {
                routeBuilding -> "Строим маршрут…"
                routeReady -> routeSummaryText()
                else -> "Выберите действие"
            }
            startStopButton.text = when {
                routeBuilding -> "Строим…"
                routeReady -> "В путь"
                else -> "Построить маршрут"
            }
            startStopButton.isEnabled = !routeBuilding
            startStopButton.alpha = if (routeBuilding) 0.72f else 1f
            startStopButton.background = primaryButtonBackground()
        } else {
            destinationCard.visibility = View.GONE
            startStopButton.text = "Начать"
            startStopButton.isEnabled = true
            startStopButton.alpha = 1f
            startStopButton.background = primaryButtonBackground()
        }
        updateExploredProgress()
    }

    private fun updateExploredProgress() {
        if (::exploredValueText.isInitialized) {
            exploredValueText.text = formatDistance(database.totalDistanceM())
        }
    }

    private fun updateCurrentLocation(lat: Double, lon: Double, follow: Boolean = false) {
        val position = LatLng(lat, lon)
        currentLocation = position
        cloudOverlay.setCurrentLocation(position)
        navigationOverlay.setCurrentLocation(position)
        if (follow) map?.animateCamera(CameraUpdateFactory.newLatLngZoom(position, 16.2))
    }

    private fun refreshClouds() {
        // The cloud mask is driven by the permanent explored-world layer, not by
        // temporary walk/session history. This is what makes backup restore reliable.
        val explored = database.exploredPoints()
        cloudOverlay.setTrackPoints(explored)
        cloudOverlay.setCurrentLocation(currentLocation)
        navigationOverlay.setExploredTrack(explored)
        updateExploredProgress()
    }

    private fun focusOnExploredArea() {
        val points = database.exploredPoints()
        val readyMap = map ?: return
        if (points.isEmpty()) return
        if (points.size == 1) {
            val p = points.first()
            readyMap.animateCamera(
                CameraUpdateFactory.newLatLngZoom(LatLng(p.latitude, p.longitude), 16.0)
            )
            return
        }

        val builder = org.maplibre.android.geometry.LatLngBounds.Builder()
        points.forEach { builder.include(LatLng(it.latitude, it.longitude)) }
        try {
            readyMap.animateCamera(CameraUpdateFactory.newLatLngBounds(builder.build(), dp(54)))
        } catch (_: Exception) {
            val p = points.last()
            readyMap.animateCamera(
                CameraUpdateFactory.newLatLngZoom(LatLng(p.latitude, p.longitude), 15.0)
            )
        }
    }

    private fun centerOnLastLocation() {
        val fineGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

        if (!fineGranted && !coarseGranted) {
            pendingStartAfterPermission = false
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                REQUEST_LOCATION
            )
            return
        }

        LocationServices.getFusedLocationProviderClient(this).lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                currentAccuracyM = location.accuracy
                updateCurrentLocation(location.latitude, location.longitude)
                map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(location.latitude, location.longitude), 16.2))
                if (destination != null && routePoints.isEmpty() && !routeBuilding) buildRoute()
            }
        }
    }

    private fun searchPlaces() {
        val query = searchInput.text.toString().trim()
        if (query.length < 2) {
            Toast.makeText(this, "Введите название места", Toast.LENGTH_SHORT).show()
            return
        }

        hideKeyboard()
        statusText.visibility = View.VISIBLE
        statusText.text = "Ищем место…"
        hideSearchResults()

        thread {
            try {
                val encoded = URLEncoder.encode(query, "UTF-8")
                val url = URL("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=5&addressdetails=1&q=$encoded")
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 12_000
                    readTimeout = 12_000
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "WalkTravelTimege/0.5.5 (Android)")
                    setRequestProperty("Accept-Language", "ru,en;q=0.8")
                }
                val text = connection.inputStream.bufferedReader().use { it.readText() }
                val json = JSONArray(text)
                val places = ArrayList<SearchPlace>()
                for (i in 0 until json.length()) {
                    val obj = json.getJSONObject(i)
                    places += SearchPlace(
                        name = obj.optString("display_name", query),
                        lat = obj.getString("lat").toDouble(),
                        lon = obj.getString("lon").toDouble()
                    )
                }
                runOnUiThread { showSearchResults(places) }
            } catch (_: Exception) {
                runOnUiThread {
                    statusText.visibility = View.VISIBLE
                    statusText.text = "Поиск не удался"
                    Toast.makeText(this, "Проверьте интернет и попробуйте ещё раз", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun showSearchResults(places: List<SearchPlace>) {
        if (places.isEmpty()) {
            statusText.visibility = View.VISIBLE
            statusText.text = "Ничего не найдено"
            return
        }

        searchResultsPanel.removeAllViews()
        statusText.visibility = View.GONE

        places.forEachIndexed { index, place ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(9), dp(8), dp(9))
                background = if (index == places.lastIndex) null else searchRowBackground()
                setOnClickListener { selectDestination(place) }
            }

            val badge = TextView(this).apply {
                text = "●"
                gravity = Gravity.CENTER
                textSize = 16f
                setTextColor(Color.WHITE)
                background = searchBadgeBackground()
            }
            row.addView(badge, LinearLayout.LayoutParams(dp(38), dp(38)))

            val textColumn = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), 0, dp(8), 0)
            }
            val title = TextView(this).apply {
                text = shortName(place.name)
                setTextColor(Color.rgb(35, 76, 43))
                textSize = 14f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                maxLines = 1
            }
            val subtitle = TextView(this).apply {
                text = secondaryName(place.name)
                setTextColor(Color.rgb(91, 125, 94))
                textSize = 11f
                maxLines = 1
            }
            textColumn.addView(title)
            textColumn.addView(subtitle)
            row.addView(textColumn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val arrow = TextView(this).apply {
                text = "›"
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(53, 116, 60))
                textSize = 26f
            }
            row.addView(arrow, LinearLayout.LayoutParams(dp(28), dp(38)))
            searchResultsPanel.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)))
        }
        searchResultsPanel.visibility = View.VISIBLE
    }

    private fun hideSearchResults() {
        searchResultsPanel.visibility = View.GONE
    }

    private fun selectDestination(place: SearchPlace) {
        hideKeyboard()
        hideSearchResults()
        topPanel.visibility = View.GONE
        destination = place
        routePoints = emptyList()
        routeDistanceM = 0.0
        routeDurationS = 0.0
        routeBuilding = false
        navigationOverlay.setRoute(emptyList())
        navigationOverlay.setDestination(LatLng(place.lat, place.lon))
        map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(place.lat, place.lon), 14.5))
        updateUiState()
        buildRoute()
    }

    private fun clearDestination() {
        destination = null
        routePoints = emptyList()
        routeDistanceM = 0.0
        routeDurationS = 0.0
        routeBuilding = false
        followNavigation = false
        navigationOverlay.setDestination(null)
        navigationOverlay.setRoute(emptyList())
        searchInput.text?.clear()
        updateUiState()
    }

    private fun buildRoute() {
        val to = destination ?: return
        val from = currentLocation
        if (from == null) {
            centerOnLastLocation()
            return
        }
        if (routeBuilding) return

        routeBuilding = true
        routePoints = emptyList()
        routeDistanceM = 0.0
        routeDurationS = 0.0
        navigationOverlay.setRoute(emptyList())
        updateUiState()

        thread {
            try {
                val url = URL(
                    "https://router.project-osrm.org/route/v1/driving/${from.longitude},${from.latitude};${to.lon},${to.lat}?overview=full&geometries=geojson&steps=false"
                )
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15_000
                    readTimeout = 15_000
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "WalkTravelTimege/0.5.5 (Android)")
                }
                val root = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
                val route = root.getJSONArray("routes").getJSONObject(0)
                val coordinates = route.getJSONObject("geometry").getJSONArray("coordinates")
                val points = ArrayList<LatLng>(coordinates.length())
                for (i in 0 until coordinates.length()) {
                    val pair = coordinates.getJSONArray(i)
                    points += LatLng(pair.getDouble(1), pair.getDouble(0))
                }
                val distanceMeters = route.optDouble("distance", 0.0)
                val durationSeconds = route.optDouble("duration", 0.0)

                runOnUiThread {
                    routeBuilding = false
                    routeDistanceM = distanceMeters
                    routeDurationS = durationSeconds
                    routePoints = points
                    navigationOverlay.setRoute(points)
                    updateUiState()
                    fitRoute(points)
                }
            } catch (_: Exception) {
                runOnUiThread {
                    routeBuilding = false
                    routePoints = emptyList()
                    routeDistanceM = 0.0
                    routeDurationS = 0.0
                    navigationOverlay.setRoute(emptyList())
                    updateUiState()
                    Toast.makeText(this, "Маршрут временно недоступен", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun fitRoute(points: List<LatLng>) {
        if (points.isEmpty()) return
        val lats = points.map { it.latitude }
        val lons = points.map { it.longitude }
        val bounds = org.maplibre.android.geometry.LatLngBounds.Builder()
            .include(LatLng(lats.minOrNull() ?: return, lons.minOrNull() ?: return))
            .include(LatLng(lats.maxOrNull() ?: return, lons.maxOrNull() ?: return))
            .build()
        map?.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, dp(70)))
    }

    private fun routeSummaryText(): String {
        if (routeDistanceM <= 0.0) return "Маршрут построен"
        val distanceText = formatDistance(routeDistanceM)
        val walkingMinutes = ((routeDistanceM / 1.35) / 60.0).roundToInt().coerceAtLeast(1)
        val timeText = if (walkingMinutes < 60) {
            "≈$walkingMinutes мин"
        } else {
            val hours = walkingMinutes / 60
            val minutes = walkingMinutes % 60
            if (minutes == 0) "≈$hours ч" else "≈$hours ч $minutes мин"
        }
        return "$distanceText · $timeText"
    }

    private fun formatDistance(distanceM: Double): String = if (distanceM < 1000.0) {
        "${distanceM.roundToInt()} м"
    } else {
        String.format(Locale.getDefault(), "%.1f км", distanceM / 1000.0)
    }

    private fun updateCompass() {
        if (!::compassArrow.isInitialized) return
        val bearing = map?.cameraPosition?.bearing ?: 0.0
        compassArrow.rotation = (-bearing).toFloat()
    }

    private fun resetNorth() {
        val readyMap = map ?: return
        val current = readyMap.cameraPosition
        readyMap.animateCamera(
            CameraUpdateFactory.newCameraPosition(
                CameraPosition.Builder()
                    .target(current.target)
                    .zoom(current.zoom)
                    .tilt(current.tilt)
                    .bearing(0.0)
                    .build()
            )
        )
    }

    private fun shortName(name: String): String = name.substringBefore(',').take(42)

    private fun secondaryName(name: String): String {
        val parts = name.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        return parts.drop(1).take(2).joinToString(", ").ifBlank { "Найденное место" }
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(searchInput.windowToken, 0)
        searchInput.clearFocus()
    }

    private fun layeredRoundRect(
        outerColors: IntArray,
        innerColors: IntArray,
        radiusDp: Int,
        insetDp: Int,
        strokeColor: Int
    ): Drawable {
        val outer = GradientDrawable(GradientDrawable.Orientation.TL_BR, outerColors).apply {
            cornerRadius = dp(radiusDp).toFloat()
            setStroke(dp(1), strokeColor)
        }
        val inner = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, innerColors).apply {
            cornerRadius = dp((radiusDp - insetDp).coerceAtLeast(1)).toFloat()
            setStroke(dp(1), Color.argb(125, 255, 255, 255))
        }
        return LayerDrawable(arrayOf(outer, inner)).apply {
            setLayerInset(1, dp(insetDp), dp(insetDp), dp(insetDp), dp(insetDp))
        }
    }

    private fun layeredOval(
        outerColors: IntArray,
        innerColors: IntArray,
        insetDp: Int,
        strokeColor: Int
    ): Drawable {
        val outer = GradientDrawable(GradientDrawable.Orientation.TL_BR, outerColors).apply {
            shape = GradientDrawable.OVAL
            setStroke(dp(1), strokeColor)
        }
        val inner = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, innerColors).apply {
            shape = GradientDrawable.OVAL
            setStroke(dp(1), Color.argb(140, 255, 255, 255))
        }
        return LayerDrawable(arrayOf(outer, inner)).apply {
            setLayerInset(1, dp(insetDp), dp(insetDp), dp(insetDp), dp(insetDp))
        }
    }

    private fun sidePanelBackground(): Drawable = layeredRoundRect(
        outerColors = intArrayOf(Color.rgb(27, 90, 35), Color.rgb(84, 158, 57), Color.rgb(24, 78, 33)),
        innerColors = intArrayOf(Color.rgb(105, 178, 75), Color.rgb(49, 117, 48), Color.rgb(30, 86, 38)),
        radiusDp = 34,
        insetDp = 2,
        strokeColor = Color.rgb(174, 231, 122)
    )

    private fun compactPanelBackground(): Drawable = layeredRoundRect(
        outerColors = intArrayOf(Color.rgb(70, 135, 63), Color.rgb(39, 100, 45)),
        innerColors = intArrayOf(Color.argb(252, 246, 250, 241), Color.argb(248, 226, 240, 220)),
        radiusDp = 24,
        insetDp = 2,
        strokeColor = Color.argb(225, 212, 244, 185)
    )

    private fun progressCardBackground(): Drawable = layeredRoundRect(
        outerColors = intArrayOf(Color.rgb(35, 103, 38), Color.rgb(83, 166, 49), Color.rgb(28, 84, 34)),
        innerColors = intArrayOf(Color.rgb(80, 157, 55), Color.rgb(37, 105, 42)),
        radiusDp = 18,
        insetDp = 2,
        strokeColor = Color.argb(235, 190, 242, 125)
    )

    private fun searchFieldBackground(): Drawable = layeredRoundRect(
        outerColors = intArrayOf(Color.rgb(198, 214, 191), Color.rgb(119, 151, 111)),
        innerColors = intArrayOf(Color.rgb(255, 255, 250), Color.rgb(236, 245, 231), Color.rgb(220, 235, 215)),
        radiusDp = 22,
        insetDp = 2,
        strokeColor = Color.argb(215, 238, 249, 230)
    )

    private fun roundGlassButtonBackground(): Drawable = layeredOval(
        outerColors = intArrayOf(Color.rgb(46, 111, 45), Color.rgb(143, 190, 91), Color.rgb(35, 88, 39)),
        innerColors = intArrayOf(Color.rgb(255, 255, 247), Color.rgb(239, 247, 224), Color.rgb(206, 229, 188)),
        insetDp = 3,
        strokeColor = Color.argb(245, 194, 233, 142)
    )

    private fun locateButtonBackground(): Drawable = layeredOval(
        outerColors = intArrayOf(Color.rgb(55, 119, 49), Color.rgb(137, 181, 88), Color.rgb(43, 98, 45)),
        innerColors = intArrayOf(Color.rgb(255, 255, 249), Color.rgb(237, 246, 231), Color.rgb(214, 231, 207)),
        insetDp = 3,
        strokeColor = Color.argb(235, 211, 245, 180)
    )

    private fun primaryButtonBackground(): Drawable = layeredRoundRect(
        outerColors = intArrayOf(Color.rgb(30, 93, 31), Color.rgb(101, 194, 38), Color.rgb(26, 80, 31)),
        innerColors = intArrayOf(Color.rgb(143, 224, 57), Color.rgb(63, 159, 37), Color.rgb(35, 113, 40)),
        radiusDp = 25,
        insetDp = 3,
        strokeColor = Color.argb(240, 195, 244, 108)
    )

    private fun lightGlassCardBackground(): Drawable = layeredRoundRect(
        outerColors = intArrayOf(Color.rgb(174, 203, 163), Color.rgb(110, 151, 104)),
        innerColors = intArrayOf(Color.argb(250, 255, 255, 250), Color.argb(247, 233, 244, 228)),
        radiusDp = 22,
        insetDp = 2,
        strokeColor = Color.argb(210, 235, 250, 226)
    )

    private fun destinationBadgeBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(115, 212, 54), Color.rgb(34, 126, 45))
    ).apply {
        shape = GradientDrawable.OVAL
        setStroke(dp(1), Color.argb(200, 230, 255, 217))
    }

    private fun searchBadgeBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(139, 220, 78), Color.rgb(47, 139, 51))
    ).apply {
        shape = GradientDrawable.OVAL
        setStroke(dp(1), Color.argb(170, 239, 255, 228))
    }

    private fun searchRowBackground() = GradientDrawable().apply {
        setColor(Color.TRANSPARENT)
        setStroke(0, Color.TRANSPARENT)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    private fun registerTrackingReceiver() {
        val filter = IntentFilter().apply {
            addAction(TrackingService.ACTION_LOCATION_UPDATE)
            addAction(TrackingService.ACTION_TRACKING_STOPPED)
        }
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_LOCATION && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            if (pendingStartAfterPermission) startWalk() else centerOnLastLocation()
            pendingStartAfterPermission = false
        }
    }

    override fun onStart() {
        super.onStart()
        mapView.onStart()
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
        tracking = database.activeWalk() != null
        updateUiState()
        refreshClouds()
    }

    override fun onPause() {
        mapView.onPause()
        super.onPause()
    }

    override fun onStop() {
        mapView.onStop()
        super.onStop()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView.onLowMemory()
    }

    override fun onDestroy() {
        unregisterReceiver(receiver)
        mapView.onDestroy()
        database.close()
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        mapView.onSaveInstanceState(outState)
    }

    companion object {
        private const val REQUEST_LOCATION = 7001
        private const val MENU_MAP_NORMAL = 7101
        private const val MENU_MAP_LIGHT = 7102
        private const val MENU_BACKUP_EXPORT = 7103
        private const val MENU_BACKUP_IMPORT = 7104
        private val MAP_STYLES = listOf(
            "Обычная" to "https://tiles.openfreemap.org/styles/liberty",
            "Светлая" to "https://tiles.openfreemap.org/styles/bright"
        )
    }
}
