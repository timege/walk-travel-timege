package com.lifeinmist.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.location.LocationServices
import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private lateinit var mapView: MapView
    private lateinit var cloudOverlay: FogOverlay
    private lateinit var navigationOverlay: NavigationOverlay
    private lateinit var database: MistDatabase
    private val progressExecutor = java.util.concurrent.Executors.newSingleThreadExecutor()
    // These three fields are accessed only by progressExecutor.
    private var progressReader: MistDatabase? = null
    private var progressCursor = 0L
    private val progressPoints = ArrayList<TrackPoint>()
    // Request flags are accessed only on the UI thread.
    private var progressLoading = false
    private var progressPending = false
    private var progressReset = false
    private var progressDisposed = false
    private lateinit var discoveryOverlay: DiscoveryOverlay
    private lateinit var discoveryUi: DiscoveryUi
    private lateinit var gpxUi: GpxUi
    private lateinit var gpsStatus: GpsStatusView
    private var routeRequest = 0
    private var importedRoute = false
    private var restoredCamera: CameraPosition? = null
    private data class RetainedMapState(
        val destination: SearchPlace?, val points: List<LatLng>, val segments: List<List<LatLng>>,
        val imported: Boolean, val distanceM: Double, val durationS: Double,
        val location: LatLng?, val camera: CameraPosition?, val follow: Boolean
    )

    private val importPlacesLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) thread {
            val result = runCatching {
                val raw = contentResolver.openInputStream(uri)?.use {
                    String(it.readBytesLimited(2_000_000), Charsets.UTF_8)
                } ?: error(tr("Could not open the file", "Не удалось открыть файл"))
                DiscoveryStore.get(this).install(raw)
            }
            runOnUiThread {
                if (!isFinishing && !isDestroyed) {
                    discoveryOverlay.invalidate()
                    Toast.makeText(this, result.fold({ tr("Places imported: $it", "Загружено мест: $it") }, {
                        tr("Could not import places. Check the file format.", "Не удалось загрузить места. Проверьте формат файла.")
                    }), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private lateinit var sidePanel: LinearLayout
    private lateinit var topPanel: LinearLayout
    private lateinit var searchRow: LinearLayout
    private lateinit var searchInput: EditText
    private lateinit var statusText: TextView
    private lateinit var searchResultsPanel: LinearLayout
    private lateinit var destinationCard: LinearLayout
    private lateinit var destinationTitle: TextView
    private lateinit var destinationSubtitle: TextView
    private lateinit var startStopButton: Button
    private lateinit var compassArrow: TextView
    private lateinit var centerButton: ImageButton
    private lateinit var compassButton: FrameLayout

    private var map: MapLibreMap? = null
    private var tracking = false
    private var followNavigation = false
    private var currentLocation: LatLng? = null
    private var currentAccuracyM: Float = 0f
    private var destination: SearchPlace? = null
    private var routePoints: List<LatLng> = emptyList()
    private var selectedMapStyle = 0
    private var pendingStartAfterPermission = false
    private var routeBuilding = false
    private var routeDistanceM: Double = 0.0
    private var routeDurationS: Double = 0.0

    private data class SearchPlace(
        val name: String,
        val lat: Double,
        val lon: Double
    )

    private val exportProgressLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        thread {
            try {
                val json = JSONObject(database.exportProgressJson())
                    .put("discoveries", DiscoveryStore.get(this).backup()).toString()
                contentResolver.openOutputStream(uri, "w")?.bufferedWriter()?.use { it.write(json) }
                    ?: error("Cannot open backup file")
                runOnUiThread {
                    Toast.makeText(this, tr("Backup saved", "Резервная копия сохранена"), Toast.LENGTH_LONG).show()
                }
            } catch (_: Exception) {
                runOnUiThread {
                    Toast.makeText(this, tr("Could not save the backup", "Не удалось сохранить копию"), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private val importProgressLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        thread {
            try {
                val json = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: error("Cannot read backup file")
                val discoveries = JSONObject(json).optJSONObject("discoveries")
                discoveries?.let { DiscoveryStore.get(this).validateBackup(it) }
                val restored = database.importProgressJson(json)
                discoveries?.let { DiscoveryStore.get(this).restore(it) }
                runOnUiThread {
                    // Read back from the persistent layer after import instead of trusting
                    // only the import counters. This also exercises the DB self-heal path.
                    val persistedExplored = database.exploredPoints()
                    refreshClouds(reset = true)
                    cloudOverlay.postInvalidateOnAnimation()
                    discoveryOverlay.invalidate()
                    navigationOverlay.postInvalidateOnAnimation()
                    if (persistedExplored.isNotEmpty()) focusOnExploredArea()
                    Toast.makeText(
                        this,
                        if (persistedExplored.isNotEmpty()) {
                            tr("Exploration restored: ${persistedExplored.size} points", "Прогресс восстановлен: ${persistedExplored.size} точек")
                        } else {
                            tr("This backup contains no explored locations", "В копии нет исследованных территорий")
                        },
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (_: Exception) {
                runOnUiThread {
                    Toast.makeText(this, tr("This is not a valid Walk Travel Timege backup", "Это не резервная копия Walk Travel Timege"), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                TrackingService.ACTION_GPS_STATUS -> gpsStatus.update(
                    intent.getFloatExtra(TrackingService.EXTRA_ACCURACY, 0f),
                    intent.getLongExtra(TrackingService.EXTRA_FIX_NANOS, 0L))
                TrackingService.ACTION_LOCATION_UPDATE -> {
                    val lat = intent.getDoubleExtra(TrackingService.EXTRA_LAT, Double.NaN)
                    val lon = intent.getDoubleExtra(TrackingService.EXTRA_LON, Double.NaN)
                    currentAccuracyM = intent.getFloatExtra(TrackingService.EXTRA_ACCURACY, 0f)
                    if (!lat.isNaN() && !lon.isNaN()) {
                        updateCurrentLocation(lat, lon, followNavigation)
                    }
                    refreshClouds()
                    discoveryOverlay.invalidate()
                    val names = intent.getStringArrayExtra("discovered_names") ?: emptyArray<String>()
                    if (names.isNotEmpty()) Toast.makeText(this@MainActivity,
                        tr("New discovery: ${names.joinToString()}", "Новое открытие: ${names.joinToString()}"), Toast.LENGTH_LONG).show()
                }

                TrackingService.ACTION_TRACKING_STOPPED -> {
                    tracking = false
                    followNavigation = false
                    updateUiState()
                    refreshClouds()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        AppLanguage.initialize(this)
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        database = MistDatabase(this)
        tracking = database.activeWalk() != null
        selectedMapStyle = getSharedPreferences("ui", MODE_PRIVATE).getInt("mapStyle", 0)
            .coerceIn(0, MAP_STYLES.lastIndex)

        buildUi(savedInstanceState)
        discoveryUi = DiscoveryUi(this, { currentLocation }, { place, title ->
            selectDestination(SearchPlace(title, place.lat, place.lon))
        }, { place ->
            map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(place.lat, place.lon), 16.0))
        }, { discoveryOverlay.invalidate() }, { importPlacesLauncher.launch(arrayOf("application/json", "text/*")) })
        discoveryOverlay.onPlaceClick = { discoveryUi.showCard(it) }
        gpxUi = GpxUi(this, ::showImportedRoute)
        val retained = lastCustomNonConfigurationInstance as? RetainedMapState
        if (retained == null) gpxUi.restoreRoute() else {
            destination = retained.destination
            routePoints = retained.points
            importedRoute = retained.imported
            routeDistanceM = retained.distanceM
            routeDurationS = retained.durationS
            currentLocation = retained.location
            restoredCamera = retained.camera
            followNavigation = retained.follow
            navigationOverlay.setRouteSegments(retained.segments)
        }
        registerTrackingReceiver()
        initMap()
        updateUiState()
        discoveryUi.sync()
    }

    private fun buildUi(savedInstanceState: Bundle?) {
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(234, 242, 231))
        }

        mapView = MapView(this)
        mapView.onCreate(savedInstanceState)
        root.addView(mapView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        cloudOverlay = FogOverlay(this)
        root.addView(cloudOverlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        navigationOverlay = NavigationOverlay(this)
        root.addView(navigationOverlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        discoveryOverlay = DiscoveryOverlay(this)
        root.addView(discoveryOverlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // Compact vertical exploration menu on the left: search, layers and on-demand progress.
        sidePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(7), dp(8), dp(7), dp(8))
            background = sidePanelBackground()
            elevation = dp(10).toFloat()
        }

        val searchMenuButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_search)
            setColorFilter(Color.rgb(20, 94, 35))
            background = roundGlassButtonBackground()
            setPadding(dp(13), dp(13), dp(13), dp(13))
            contentDescription = tr("Search places", "Поиск мест")
            setOnClickListener { toggleSearchPanel() }
        }
        sidePanel.addView(searchMenuButton, LinearLayout.LayoutParams(dp(54), dp(54)).apply { bottomMargin = dp(6) })

        val layersMenuButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_layers)
            setColorFilter(Color.rgb(20, 94, 35))
            background = roundGlassButtonBackground()
            setPadding(dp(13), dp(13), dp(13), dp(13))
            contentDescription = tr("Maps, tracks and backup", "Карты, треки и резервная копия")
            setOnClickListener { showMapMenu(this) }
        }
        sidePanel.addView(layersMenuButton, LinearLayout.LayoutParams(dp(54), dp(54)).apply { bottomMargin = dp(6) })
        sidePanel.addView(Button(this).apply {
            text = "?"; textSize = 24f; contentDescription = tr("Places and discoveries", "Места и открытия")
            setTextColor(Color.rgb(20, 94, 35)); background = roundGlassButtonBackground()
            setOnClickListener { discoveryUi.showCollection() }
        }, LinearLayout.LayoutParams(dp(54), dp(54)).apply { bottomMargin = dp(6) })

        val statsMenuButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_stats)
            setColorFilter(Color.rgb(20, 94, 35))
            background = roundGlassButtonBackground()
            setPadding(dp(13), dp(13), dp(13), dp(13))
            contentDescription = tr("Exploration progress", "Прогресс исследования")
            setOnClickListener { showStats(this) }
        }
        sidePanel.addView(statsMenuButton, LinearLayout.LayoutParams(dp(54), dp(54)))

        root.addView(
            sidePanel,
            FrameLayout.LayoutParams(dp(74), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START).apply {
                setMargins(dp(12), dp(14), 0, 0)
            }
        )

        // Search is secondary: it appears only after tapping the magnifier in the side menu.
        topPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = compactPanelBackground()
            elevation = dp(11).toFloat()
            visibility = View.GONE
        }
        searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        searchInput = EditText(this).apply {
            hint = tr("Where to?", "Куда отправимся?")
            setHintTextColor(Color.rgb(79, 103, 80))
            setTextColor(Color.rgb(38, 70, 43))
            textSize = 15f
            setSingleLine(true)
            background = searchFieldBackground()
            setPadding(dp(14), 0, dp(10), 0)
            setOnEditorActionListener { _, _, _ ->
                searchPlaces()
                true
            }
        }
        searchRow.addView(searchInput, LinearLayout.LayoutParams(0, dp(46), 1f))

        val executeSearch = ImageButton(this).apply {
            setImageResource(R.drawable.ic_search)
            setColorFilter(Color.rgb(20, 94, 35))
            background = roundGlassButtonBackground()
            setPadding(dp(11), dp(11), dp(11), dp(11))
            contentDescription = tr("Search", "Найти")
            setOnClickListener { searchPlaces() }
        }
        searchRow.addView(executeSearch, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginStart = dp(7) })

        val closeSearch = TextView(this).apply {
            text = "×"
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(48, 92, 53))
            textSize = 25f
            setOnClickListener {
                topPanel.visibility = View.GONE
                hideSearchResults()
                hideKeyboard()
            }
        }
        searchRow.addView(closeSearch, LinearLayout.LayoutParams(dp(36), dp(46)).apply { marginStart = dp(4) })
        topPanel.addView(searchRow)

        statusText = TextView(this).apply {
            setTextColor(Color.rgb(49, 90, 54))
            textSize = 12f
            setPadding(dp(8), dp(6), dp(4), 0)
            visibility = View.GONE
        }
        topPanel.addView(statusText)

        root.addView(
            topPanel,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
                setMargins(dp(98), dp(14), dp(14), 0)
            }
        )

        searchResultsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = lightGlassCardBackground()
            elevation = dp(12).toFloat()
            visibility = View.GONE
        }
        root.addView(
            searchResultsPanel,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
                setMargins(dp(98), dp(76), dp(14), 0)
            }
        )

        destinationCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(8), dp(10))
            background = lightGlassCardBackground()
            elevation = dp(10).toFloat()
            visibility = View.GONE
        }
        val pinBadge = TextView(this).apply {
            text = "●"
            gravity = Gravity.CENTER
            textSize = 20f
            setTextColor(Color.WHITE)
            background = destinationBadgeBackground()
        }
        destinationCard.addView(pinBadge, LinearLayout.LayoutParams(dp(42), dp(42)))

        val destinationTextColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, dp(6), 0)
        }
        destinationTitle = TextView(this).apply {
            setTextColor(Color.rgb(31, 72, 39))
            textSize = 15f
            typeface = AppTypography.emphasis
            maxLines = 1
        }
        destinationSubtitle = TextView(this).apply {
            setTextColor(Color.rgb(70, 132, 71))
            textSize = 12f
            setPadding(0, dp(2), 0, 0)
            maxLines = 1
        }
        destinationTextColumn.addView(destinationTitle)
        destinationTextColumn.addView(destinationSubtitle)
        destinationCard.addView(destinationTextColumn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val closeDestination = TextView(this).apply {
            text = "×"
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(70, 104, 74))
            textSize = 24f
            setOnClickListener { clearDestination() }
        }
        destinationCard.addView(closeDestination, LinearLayout.LayoutParams(dp(36), dp(42)))
        root.addView(
            destinationCard,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
                setMargins(dp(98), dp(14), dp(14), 0)
            }
        )

        centerButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_my_location)
            setColorFilter(Color.rgb(20, 94, 35))
            background = locateButtonBackground()
            setPadding(dp(13), dp(13), dp(13), dp(13))
            contentDescription = tr("My location", "Моё местоположение")
            elevation = dp(8).toFloat()
            setOnClickListener { centerOnLastLocation() }
        }
        root.addView(
            centerButton,
            FrameLayout.LayoutParams(dp(52), dp(52), Gravity.BOTTOM or Gravity.START).apply {
                setMargins(dp(18), 0, 0, dp(20))
            }
        )

        startStopButton = Button(this).apply {
            isAllCaps = false
            typeface = AppTypography.emphasis
            textSize = 16f
            setTextColor(Color.WHITE)
            minWidth = dp(138)
            minHeight = 0
            setPadding(dp(28), 0, dp(28), 0)
            elevation = dp(10).toFloat()
            background = primaryButtonBackground()
            setOnClickListener {
                when {
                    tracking -> stopWalk()
                    destination != null && routePoints.isNotEmpty() -> ensurePermissionAndStart()
                    destination != null && !routeBuilding -> buildRoute()
                    else -> ensurePermissionAndStart()
                }
            }
        }
        root.addView(
            startStopButton,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                setMargins(0, 0, 0, dp(20))
            }
        )

        compassButton = FrameLayout(this).apply {
            background = locateButtonBackground()
            elevation = dp(8).toFloat()
            contentDescription = tr("Compass. Reset north", "Компас. Вернуть север вверх")
            setOnClickListener { resetNorth() }
        }
        compassArrow = TextView(this).apply {
            text = "▲"
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(20, 94, 35))
            textSize = 17f
        }
        compassButton.addView(
            compassArrow,
            FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER).apply { topMargin = -dp(4) }
        )
        val northLabel = TextView(this).apply {
            text = "N"
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(20, 94, 35))
            textSize = 10f
            typeface = AppTypography.emphasis
        }
        compassButton.addView(
            northLabel,
            FrameLayout.LayoutParams(dp(24), dp(18), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(4) }
        )
        root.addView(
            compassButton,
            FrameLayout.LayoutParams(dp(52), dp(52), Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(18), dp(20))
            }
        )

        gpsStatus = GpsStatusView(this)
        root.addView(gpsStatus, FrameLayout.LayoutParams(dp(48),
            dp(48), Gravity.TOP or Gravity.END).apply {
            rightMargin = dp(12); topMargin = dp(14)
        })
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            (gpsStatus.layoutParams as FrameLayout.LayoutParams).apply {
                topMargin = bars.top + dp(14)
                gpsStatus.layoutParams = this
            }

            (sidePanel.layoutParams as FrameLayout.LayoutParams).apply {
                topMargin = bars.top + dp(14)
                sidePanel.layoutParams = this
            }
            (topPanel.layoutParams as FrameLayout.LayoutParams).apply {
                topMargin = bars.top + dp(14)
                rightMargin = dp(72)
                topPanel.layoutParams = this
            }
            (searchResultsPanel.layoutParams as FrameLayout.LayoutParams).apply {
                topMargin = bars.top + dp(76)
                searchResultsPanel.layoutParams = this
            }
            (destinationCard.layoutParams as FrameLayout.LayoutParams).apply {
                topMargin = bars.top + dp(14)
                rightMargin = dp(72)
                destinationCard.layoutParams = this
            }
            (centerButton.layoutParams as FrameLayout.LayoutParams).apply {
                bottomMargin = bars.bottom + dp(18)
                centerButton.layoutParams = this
            }
            (startStopButton.layoutParams as FrameLayout.LayoutParams).apply {
                bottomMargin = bars.bottom + dp(18)
                startStopButton.layoutParams = this
            }
            (compassButton.layoutParams as FrameLayout.LayoutParams).apply {
                bottomMargin = bars.bottom + dp(18)
                compassButton.layoutParams = this
            }
            insets
        }
        ViewCompat.requestApplyInsets(root)
    }

    private fun initMap() {
        mapView.getMapAsync { readyMap ->
            map = readyMap
            cloudOverlay.map = readyMap
            navigationOverlay.map = readyMap
            discoveryOverlay.map = readyMap
            readyMap.addOnMapClickListener { discoveryOverlay.handleMapClick(it) }
            readyMap.uiSettings.isRotateGesturesEnabled = true
            readyMap.uiSettings.isCompassEnabled = false // Our compass is already at bottom right.
            readyMap.uiSettings.isTiltGesturesEnabled = false
            applyMapStyle(initial = true)
            readyMap.addOnCameraMoveListener {
                cloudOverlay.onCameraMove()
                discoveryOverlay.invalidate()
                navigationOverlay.invalidate()
                updateCompass()
            }
            readyMap.addOnCameraIdleListener {
                cloudOverlay.onCameraIdle()
                discoveryOverlay.invalidate()
                navigationOverlay.onCameraIdle()
            }
        }
    }

    private fun applyMapStyle(initial: Boolean = false) {
        val readyMap = map ?: return
        readyMap.setStyle(MAP_STYLES[selectedMapStyle].second) {
            if (initial) {
                readyMap.cameraPosition = restoredCamera ?: CameraPosition.Builder()
                    .target(LatLng(20.0, 0.0))
                    .zoom(2.0)
                    .build()
            }
            refreshClouds()
            navigationOverlay.setCurrentLocation(currentLocation)
            navigationOverlay.setDestination(destination?.let { LatLng(it.lat, it.lon) })
            if (!importedRoute) navigationOverlay.setRoute(routePoints)
            if (initial && restoredCamera == null) {
                if (importedRoute) fitRoute(routePoints) else centerOnLastLocation()
            }
            if (initial && restoredCamera != null && destination != null && routePoints.isEmpty()) buildRoute()
        }
    }

    private fun toggleSearchPanel() {
        if (topPanel.visibility == View.VISIBLE) {
            topPanel.visibility = View.GONE
            hideSearchResults()
            hideKeyboard()
            return
        }
        destinationCard.visibility = View.GONE
        topPanel.visibility = View.VISIBLE
        statusText.visibility = View.GONE
        searchInput.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun showMapMenu(anchor: View) {
        PopupMenu(this, anchor).apply {
            menu.add(0, MENU_MAP_NORMAL, 0, if (selectedMapStyle == 0) tr("✓ Map: standard", "✓ Карта: обычная") else tr("Map: standard", "Карта: обычная"))
            menu.add(0, MENU_MAP_LIGHT, 1, if (selectedMapStyle == 1) tr("✓ Map: light", "✓ Карта: светлая") else tr("Map: light", "Карта: светлая"))
            menu.add(0, MENU_BACKUP_EXPORT, 3, tr("Back up progress", "Сохранить прогресс"))
            menu.add(0, MENU_BACKUP_IMPORT, 4, tr("Restore progress", "Восстановить прогресс"))
            menu.add(0, MENU_GPX_EXPORT, 5, tr("Export GPX", "Экспорт GPX"))
            menu.add(0, MENU_GPX_IMPORT, 6, tr("Import GPX route", "Импорт маршрута GPX"))
            menu.add(0, MENU_ABOUT, 7, tr("About", "О приложении"))
            menu.add(0, MENU_LANGUAGE, 8, tr("Language", "Язык"))
            setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    MENU_MAP_NORMAL -> setMapStyle(0)
                    MENU_MAP_LIGHT -> setMapStyle(1)
                    MENU_BACKUP_EXPORT -> exportProgressBackup()
                    MENU_BACKUP_IMPORT -> importProgressBackup()
                    MENU_GPX_EXPORT -> gpxUi.exportWalk()
                    MENU_GPX_IMPORT -> gpxUi.importRoute()
                    MENU_ABOUT -> showAbout()
                    MENU_LANGUAGE -> showLanguagePicker()
                }
                true
            }
            show()
        }
    }

    private fun showLanguagePicker() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(tr("Language", "Язык"))
            .setSingleChoiceItems(arrayOf("English", "Русский"), if (AppLanguage.isRussian) 1 else 0) { dialog, index ->
                dialog.dismiss()
                if ((index == 1) != AppLanguage.isRussian) {
                    AppLanguage.select(this, index == 1)
                    if (tracking) startService(Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_LANGUAGE))
                    recreate()
                }
            }.setNegativeButton(tr("Cancel", "Отмена"), null).show()
    }

    private fun showAbout() {
        val version = packageManager.getPackageInfo(packageName, 0).versionName
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Walk Travel Timege")
            .setMessage(tr("Walk. Discover. Make the map yours.\n\nVersion $version\n© 2026 Timege\n\nMap data © OpenStreetMap contributors.\nMaps provided by OpenFreeMap, rendered with MapLibre.\n\nPlace guides: normalthai.ru", "Гуляй. Открывай. Создавай свою карту.\n\nВерсия $version\n© 2026 Timege\n\nКартографические данные © участники OpenStreetMap.\nКарты: OpenFreeMap. Отображение: MapLibre.\n\nПутеводитель: normalthai.ru"))
            .setPositiveButton(tr("Close", "Закрыть"), null).show()
    }

    private fun showImportedRoute(track: ImportedGpxRoute) {
        routeRequest++ // Ignore any outstanding online route response.
        importedRoute = true
        routeBuilding = false
        val segments = track.segments
        routePoints = track.points
        val end = routePoints.lastOrNull() ?: return
        destination = SearchPlace(track.name, end.latitude, end.longitude)
        routeDistanceM = track.distanceM
        routeDurationS = 0.0
        navigationOverlay.setRouteSegments(segments)
        navigationOverlay.setDestination(end)
        topPanel.visibility = View.GONE
        hideSearchResults()
        updateUiState()
        if (map != null) fitRoute(routePoints)
    }

    private fun showStats(anchor: View) {
        val walks = database.walks()
        val totalM = walks.sumOf { it.distanceM }
        val lastM = walks.firstOrNull()?.distanceM ?: 0.0

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = statsPopupBackground()
            elevation = dp(14).toFloat()
        }

        card.addView(TextView(this).apply {
            text = tr("Your progress", "Твой прогресс")
            setTextColor(Color.rgb(27, 92, 40))
            textSize = 17f
            typeface = AppTypography.emphasis
        })
        card.addView(TextView(this).apply {
            text = tr("Every walk adds to your world", "Каждая прогулка открывает больше мира")
            setTextColor(Color.rgb(95, 125, 98))
            textSize = 10f
            setPadding(0, dp(1), 0, dp(10))
        })

        addStatRow(card, tr("Total distance", "Всего пройдено"), formatDistance(totalM))
        addStatRow(card, tr("Latest walk", "Последняя прогулка"), formatDistance(lastM))
        addStatRow(card, tr("Walks", "Прогулок"), walks.size.toString())

        val popup = PopupWindow(card, dp(230), ViewGroup.LayoutParams.WRAP_CONTENT, true).apply {
            isOutsideTouchable = true
            isFocusable = true
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            elevation = dp(14).toFloat()
        }
        val panelLocation = IntArray(2)
        sidePanel.getLocationOnScreen(panelLocation)
        popup.showAtLocation(
            sidePanel,
            Gravity.NO_GRAVITY,
            panelLocation[0],
            panelLocation[1] + sidePanel.height + dp(10)
        )
    }

    private fun addStatRow(parent: LinearLayout, label: String, value: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(7), 0, dp(7))
        }
        row.addView(TextView(this).apply {
            text = label
            setTextColor(Color.rgb(73, 105, 77))
            textSize = 13f
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply {
            text = value
            setTextColor(Color.rgb(22, 91, 37))
            textSize = 14f
            typeface = AppTypography.emphasis
        })
        parent.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun setMapStyle(index: Int) {
        if (index !in MAP_STYLES.indices || index == selectedMapStyle) return
        selectedMapStyle = index
        getSharedPreferences("ui", MODE_PRIVATE).edit().putInt("mapStyle", selectedMapStyle).apply()
        applyMapStyle()
    }

    private fun exportProgressBackup() {
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        exportProgressLauncher.launch("walk-travel-timege-progress-$date.json")
    }

    private fun importProgressBackup() {
        importProgressLauncher.launch(arrayOf("application/json", "text/plain", "application/octet-stream"))
    }

    private fun ensurePermissionAndStart() {
        val fineGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fineGranted) {
            pendingStartAfterPermission = true
            val permissions = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
            ActivityCompat.requestPermissions(this, permissions.toTypedArray(), REQUEST_LOCATION)
            return
        }
        startWalk()
    }

    private fun startWalk() {
        tracking = true
        followNavigation = destination != null
        topPanel.visibility = View.GONE
        hideSearchResults()
        updateUiState()
        val intent = Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_START)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopWalk() {
        startService(Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_STOP))
        tracking = false
        followNavigation = false
        updateUiState()
    }

    private fun updateUiState() {
        val hasDestination = destination != null
        val routeReady = routePoints.size > 1 || (importedRoute && routePoints.isNotEmpty())

        if (tracking) {
            startStopButton.text = tr("Finish", "Завершить")
            startStopButton.isEnabled = true
            startStopButton.alpha = 1f
            startStopButton.background = primaryButtonBackground()
            destinationCard.visibility = if (hasDestination) View.VISIBLE else View.GONE
            if (hasDestination) {
                destinationTitle.text = shortName(destination!!.name)
                destinationSubtitle.text = if (routeReady) routeSummaryText() else tr("Route active", "Маршрут активен")
            }
            return
        }

        if (hasDestination) {
            topPanel.visibility = View.GONE
            hideSearchResults()
            destinationCard.visibility = View.VISIBLE
            destinationTitle.text = shortName(destination!!.name)
            destinationSubtitle.text = when {
                routeBuilding -> tr("Finding a route…", "Строим маршрут…")
                routeReady -> routeSummaryText()
                else -> tr("Choose an action", "Выберите действие")
            }
            startStopButton.text = when {
                routeBuilding -> tr("Planning…", "Строим…")
                routeReady -> tr("Let's go", "В путь")
                else -> tr("Plan route", "Построить маршрут")
            }
            startStopButton.isEnabled = !routeBuilding
            startStopButton.alpha = if (routeBuilding) 0.72f else 1f
            startStopButton.background = primaryButtonBackground()
        } else {
            destinationCard.visibility = View.GONE
            startStopButton.text = tr("Start", "Начать")
            startStopButton.isEnabled = true
            startStopButton.alpha = 1f
            startStopButton.background = primaryButtonBackground()
        }
    }

    private fun updateCurrentLocation(lat: Double, lon: Double, follow: Boolean = false) {
        val position = LatLng(lat, lon)
        currentLocation = position
        cloudOverlay.setCurrentLocation(position)
        navigationOverlay.setCurrentLocation(position)
        if (follow) map?.animateCamera(CameraUpdateFactory.newLatLngZoom(position, 16.2))
    }

    private fun refreshClouds(reset: Boolean = false) {
        if (progressDisposed) return
        progressReset = progressReset || reset
        if (progressLoading) {
            progressPending = true
            return
        }
        progressLoading = true
        val resetNow = progressReset
        progressReset = false
        progressExecutor.execute {
            val result = runCatching {
                val reader = progressReader ?: MistDatabase(applicationContext).also { progressReader = it }
                if (resetNow) {
                    progressCursor = 0L
                    progressPoints.clear()
                }
                val batch = reader.exploredAfter(progressCursor)
                progressCursor = batch.lastId
                progressPoints.addAll(batch.points)
                // No copy or geometry update for a rejected/unchanged GPS fix.
                if (resetNow || batch.points.isNotEmpty()) progressPoints.toList() else null
            }
            runOnUiThread {
                progressLoading = false
                if (!progressDisposed) {
                    result.exceptionOrNull()?.let {
                        android.util.Log.w("WTT", "Progress refresh failed; keeping visible progress", it)
                    }
                    if (!progressReset) result.getOrNull()?.let { explored ->
                        cloudOverlay.setTrackPoints(explored)
                        navigationOverlay.setExploredTrack(explored)
                    }
                    cloudOverlay.setCurrentLocation(currentLocation)
                    if (progressPending || progressReset) {
                        progressPending = false
                        refreshClouds()
                    }
                }
            }
        }
    }

    private fun focusOnExploredArea() {
        val points = database.exploredPoints()
        val readyMap = map ?: return
        if (points.isEmpty()) return
        if (points.size == 1) {
            val p = points.first()
            readyMap.animateCamera(
                CameraUpdateFactory.newLatLngZoom(LatLng(p.latitude, p.longitude), 16.0)
            )
            return
        }

        val builder = org.maplibre.android.geometry.LatLngBounds.Builder()
        points.forEach { builder.include(LatLng(it.latitude, it.longitude)) }
        try {
            readyMap.animateCamera(CameraUpdateFactory.newLatLngBounds(builder.build(), dp(54)))
        } catch (_: Exception) {
            val p = points.last()
            readyMap.animateCamera(
                CameraUpdateFactory.newLatLngZoom(LatLng(p.latitude, p.longitude), 15.0)
            )
        }
    }

    private fun centerOnLastLocation() {
        val fineGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

        if (!fineGranted && !coarseGranted) {
            pendingStartAfterPermission = false
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                REQUEST_LOCATION
            )
            return
        }

        LocationServices.getFusedLocationProviderClient(this).lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                currentAccuracyM = location.accuracy
                gpsStatus.update(if (location.hasAccuracy()) location.accuracy else 0f, location.elapsedRealtimeNanos)
                updateCurrentLocation(location.latitude, location.longitude)
                map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(location.latitude, location.longitude), 16.2))
                if (destination != null && routePoints.isEmpty() && !routeBuilding) buildRoute()
            }
        }
    }

    private fun searchPlaces() {
        val query = searchInput.text.toString().trim()
        if (query.length < 2) {
            Toast.makeText(this, tr("Enter a place name", "Введите название места"), Toast.LENGTH_SHORT).show()
            return
        }

        hideKeyboard()
        statusText.visibility = View.VISIBLE
        statusText.text = tr("Searching places…", "Ищем место…")
        hideSearchResults()

        thread {
            try {
                val encoded = URLEncoder.encode(query, "UTF-8")
                val url = URL("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=5&addressdetails=1&q=$encoded")
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 12_000
                    readTimeout = 12_000
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "WalkTravelTimege/0.6.6 (Android)")
                    setRequestProperty("Accept-Language", AppLanguage.locale.language)
                }
                val text = connection.inputStream.bufferedReader().use { it.readText() }
                val json = JSONArray(text)
                val places = ArrayList<SearchPlace>()
                for (i in 0 until json.length()) {
                    val obj = json.getJSONObject(i)
                    places += SearchPlace(
                        name = obj.optString("display_name", query),
                        lat = obj.getString("lat").toDouble(),
                        lon = obj.getString("lon").toDouble()
                    )
                }
                runOnUiThread { showSearchResults(places) }
            } catch (_: Exception) {
                runOnUiThread {
                    statusText.visibility = View.VISIBLE
                    statusText.text = tr("Search failed", "Поиск не удался")
                    Toast.makeText(this, tr("Check your connection and try again", "Проверьте интернет и попробуйте ещё раз"), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun showSearchResults(places: List<SearchPlace>) {
        if (places.isEmpty()) {
            statusText.visibility = View.VISIBLE
            statusText.text = tr("No places found", "Ничего не найдено")
            return
        }

        searchResultsPanel.removeAllViews()
        statusText.visibility = View.GONE

        places.forEachIndexed { index, place ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(9), dp(8), dp(9))
                background = if (index == places.lastIndex) null else searchRowBackground()
                setOnClickListener { selectDestination(place) }
            }

            val badge = TextView(this).apply {
                text = "●"
                gravity = Gravity.CENTER
                textSize = 16f
                setTextColor(Color.WHITE)
                background = searchBadgeBackground()
            }
            row.addView(badge, LinearLayout.LayoutParams(dp(38), dp(38)))

            val textColumn = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), 0, dp(8), 0)
            }
            val title = TextView(this).apply {
                text = shortName(place.name)
                setTextColor(Color.rgb(35, 76, 43))
                textSize = 14f
                typeface = AppTypography.emphasis
                maxLines = 1
            }
            val subtitle = TextView(this).apply {
                text = secondaryName(place.name)
                setTextColor(Color.rgb(91, 125, 94))
                textSize = 11f
                maxLines = 1
            }
            textColumn.addView(title)
            textColumn.addView(subtitle)
            row.addView(textColumn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val arrow = TextView(this).apply {
                text = "›"
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(53, 116, 60))
                textSize = 26f
            }
            row.addView(arrow, LinearLayout.LayoutParams(dp(28), dp(38)))
            searchResultsPanel.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)))
        }
        searchResultsPanel.visibility = View.VISIBLE
    }

    private fun hideSearchResults() {
        searchResultsPanel.visibility = View.GONE
    }

    private fun selectDestination(place: SearchPlace) {
        routeRequest++
        importedRoute = false
        gpxUi.clearRoute()
        hideKeyboard()
        hideSearchResults()
        topPanel.visibility = View.GONE
        destination = place
        routePoints = emptyList()
        routeDistanceM = 0.0
        routeDurationS = 0.0
        routeBuilding = false
        navigationOverlay.setRoute(emptyList())
        navigationOverlay.setDestination(LatLng(place.lat, place.lon))
        map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(place.lat, place.lon), 14.5))
        updateUiState()
        buildRoute()
    }

    private fun clearDestination() {
        routeRequest++
        importedRoute = false
        gpxUi.clearRoute()
        destination = null
        routePoints = emptyList()
        routeDistanceM = 0.0
        routeDurationS = 0.0
        routeBuilding = false
        followNavigation = false
        navigationOverlay.setDestination(null)
        navigationOverlay.setRoute(emptyList())
        searchInput.text?.clear()
        updateUiState()
    }

    private fun buildRoute() {
        if (importedRoute) return
        val to = destination ?: return
        val from = currentLocation
        if (from == null) {
            centerOnLastLocation()
            return
        }
        if (routeBuilding) return

        routeBuilding = true
        routePoints = emptyList()
        routeDistanceM = 0.0
        routeDurationS = 0.0
        navigationOverlay.setRoute(emptyList())
        updateUiState()

        val request = ++routeRequest
        thread {
            try {
                val url = URL(
                    "https://router.project-osrm.org/route/v1/driving/${from.longitude},${from.latitude};${to.lon},${to.lat}?overview=full&geometries=geojson&steps=false"
                )
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15_000
                    readTimeout = 15_000
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "WalkTravelTimege/0.6.6 (Android)")
                }
                val root = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
                val route = root.getJSONArray("routes").getJSONObject(0)
                val coordinates = route.getJSONObject("geometry").getJSONArray("coordinates")
                val points = ArrayList<LatLng>(coordinates.length())
                for (i in 0 until coordinates.length()) {
                    val pair = coordinates.getJSONArray(i)
                    points += LatLng(pair.getDouble(1), pair.getDouble(0))
                }
                val distanceMeters = route.optDouble("distance", 0.0)
                val durationSeconds = route.optDouble("duration", 0.0)

                runOnUiThread {
                    if (isDestroyed || isFinishing || request != routeRequest) return@runOnUiThread
                    routeBuilding = false
                    routeDistanceM = distanceMeters
                    routeDurationS = durationSeconds
                    routePoints = points
                    navigationOverlay.setRoute(points)
                    updateUiState()
                    fitRoute(points)
                }
            } catch (_: Exception) {
                runOnUiThread {
                    if (isDestroyed || isFinishing || request != routeRequest) return@runOnUiThread
                    routeBuilding = false
                    routePoints = emptyList()
                    routeDistanceM = 0.0
                    routeDurationS = 0.0
                    navigationOverlay.setRoute(emptyList())
                    updateUiState()
                    Toast.makeText(this, tr("Route temporarily unavailable", "Маршрут временно недоступен"), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun fitRoute(points: List<LatLng>) {
        if (points.isEmpty()) return
        if (points.all { it == points.first() }) {
            map?.animateCamera(CameraUpdateFactory.newLatLngZoom(points.first(), 16.0))
            return
        }
        val lats = points.map { it.latitude }
        val lons = points.map { it.longitude }
        val bounds = org.maplibre.android.geometry.LatLngBounds.Builder()
            .include(LatLng(lats.minOrNull() ?: return, lons.minOrNull() ?: return))
            .include(LatLng(lats.maxOrNull() ?: return, lons.maxOrNull() ?: return))
            .build()
        map?.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, dp(70)))
    }

    private fun routeSummaryText(): String {
        if (importedRoute) return tr("GPX route · ${formatDistance(routeDistanceM)}", "Маршрут GPX · ${formatDistance(routeDistanceM)}")
        if (routeDistanceM <= 0.0) return tr("Route ready", "Маршрут построен")
        val distanceText = formatDistance(routeDistanceM)
        val walkingMinutes = ((routeDistanceM / 1.35) / 60.0).roundToInt().coerceAtLeast(1)
        val timeText = if (walkingMinutes < 60) {
            tr("≈$walkingMinutes min", "≈$walkingMinutes мин")
        } else {
            val hours = walkingMinutes / 60
            val minutes = walkingMinutes % 60
            if (minutes == 0) tr("≈$hours h", "≈$hours ч") else tr("≈$hours h $minutes min", "≈$hours ч $minutes мин")
        }
        return "$distanceText · $timeText"
    }

    private fun formatDistance(distanceM: Double): String = if (distanceM < 1000.0) {
        tr("${distanceM.roundToInt()} m", "${distanceM.roundToInt()} м")
    } else {
        String.format(AppLanguage.locale, tr("%.1f km", "%.1f км"), distanceM / 1000.0)
    }

    private fun updateCompass() {
        if (!::compassArrow.isInitialized) return
        val bearing = map?.cameraPosition?.bearing ?: 0.0
        compassArrow.rotation = (-bearing).toFloat()
    }

    private fun resetNorth() {
        val readyMap = map ?: return
        val current = readyMap.cameraPosition
        readyMap.animateCamera(
            CameraUpdateFactory.newCameraPosition(
                CameraPosition.Builder()
                    .target(current.target)
                    .zoom(current.zoom)
                    .tilt(current.tilt)
                    .bearing(0.0)
                    .build()
            )
        )
    }

    private fun shortName(name: String): String = name.substringBefore(',').take(42)

    private fun secondaryName(name: String): String {
        val parts = name.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        return parts.drop(1).take(2).joinToString(", ").ifBlank { tr("Search result", "Найденное место") }
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(searchInput.windowToken, 0)
        searchInput.clearFocus()
    }

    private fun layeredRoundRect(
        outerColors: IntArray,
        innerColors: IntArray,
        radiusDp: Int,
        insetDp: Int,
        strokeColor: Int
    ): Drawable {
        val outer = GradientDrawable(GradientDrawable.Orientation.TL_BR, outerColors).apply {
            cornerRadius = dp(radiusDp).toFloat()
            setStroke(dp(1), strokeColor)
        }
        val inner = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, innerColors).apply {
            cornerRadius = dp((radiusDp - insetDp).coerceAtLeast(1)).toFloat()
            setStroke(dp(1), Color.argb(125, 255, 255, 255))
        }
        return LayerDrawable(arrayOf(outer, inner)).apply {
            setLayerInset(1, dp(insetDp), dp(insetDp), dp(insetDp), dp(insetDp))
        }
    }

    private fun layeredOval(
        outerColors: IntArray,
        innerColors: IntArray,
        insetDp: Int,
        strokeColor: Int
    ): Drawable {
        val outer = GradientDrawable(GradientDrawable.Orientation.TL_BR, outerColors).apply {
            shape = GradientDrawable.OVAL
            setStroke(dp(1), strokeColor)
        }
        val inner = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, innerColors).apply {
            shape = GradientDrawable.OVAL
            setStroke(dp(1), Color.argb(140, 255, 255, 255))
        }
        return LayerDrawable(arrayOf(outer, inner)).apply {
            setLayerInset(1, dp(insetDp), dp(insetDp), dp(insetDp), dp(insetDp))
        }
    }

    private fun sidePanelBackground(): Drawable = layeredRoundRect(
        outerColors = intArrayOf(Color.rgb(27, 90, 35), Color.rgb(84, 158, 57), Color.rgb(24, 78, 33)),
        innerColors = intArrayOf(Color.rgb(105, 178, 75), Color.rgb(49, 117, 48), Color.rgb(30, 86, 38)),
        radiusDp = 34,
        insetDp = 2,
        strokeColor = Color.rgb(174, 231, 122)
    )

    private fun compactPanelBackground(): Drawable = layeredRoundRect(
        outerColors = intArrayOf(Color.rgb(70, 135, 63), Color.rgb(39, 100, 45)),
        innerColors = intArrayOf(Color.argb(252, 246, 250, 241), Color.argb(248, 226, 240, 220)),
        radiusDp = 24,
        insetDp = 2,
        strokeColor = Color.argb(225, 212, 244, 185)
    )

    private fun statsPopupBackground(): Drawable = layeredRoundRect(
        outerColors = intArrayOf(Color.rgb(67, 139, 58), Color.rgb(28, 93, 40)),
        innerColors = intArrayOf(Color.rgb(252, 255, 248), Color.rgb(232, 244, 226), Color.rgb(218, 236, 211)),
        radiusDp = 18,
        insetDp = 2,
        strokeColor = Color.rgb(170, 220, 133)
    )

    private fun progressCardBackground(): Drawable = layeredRoundRect(
        outerColors = intArrayOf(Color.rgb(35, 103, 38), Color.rgb(83, 166, 49), Color.rgb(28, 84, 34)),
        innerColors = intArrayOf(Color.rgb(80, 157, 55), Color.rgb(37, 105, 42)),
        radiusDp = 18,
        insetDp = 2,
        strokeColor = Color.argb(235, 190, 242, 125)
    )

    private fun searchFieldBackground(): Drawable = layeredRoundRect(
        outerColors = intArrayOf(Color.rgb(198, 214, 191), Color.rgb(119, 151, 111)),
        innerColors = intArrayOf(Color.rgb(255, 255, 250), Color.rgb(236, 245, 231), Color.rgb(220, 235, 215)),
        radiusDp = 22,
        insetDp = 2,
        strokeColor = Color.argb(215, 238, 249, 230)
    )

    private fun roundGlassButtonBackground(): Drawable = layeredOval(
        outerColors = intArrayOf(Color.rgb(46, 111, 45), Color.rgb(143, 190, 91), Color.rgb(35, 88, 39)),
        innerColors = intArrayOf(Color.rgb(255, 255, 247), Color.rgb(239, 247, 224), Color.rgb(206, 229, 188)),
        insetDp = 3,
        strokeColor = Color.argb(245, 194, 233, 142)
    )

    private fun locateButtonBackground(): Drawable = layeredOval(
        outerColors = intArrayOf(Color.rgb(55, 119, 49), Color.rgb(137, 181, 88), Color.rgb(43, 98, 45)),
        innerColors = intArrayOf(Color.rgb(255, 255, 249), Color.rgb(237, 246, 231), Color.rgb(214, 231, 207)),
        insetDp = 3,
        strokeColor = Color.argb(235, 211, 245, 180)
    )

    private fun primaryButtonBackground(): Drawable = layeredRoundRect(
        outerColors = intArrayOf(Color.rgb(30, 93, 31), Color.rgb(101, 194, 38), Color.rgb(26, 80, 31)),
        innerColors = intArrayOf(Color.rgb(143, 224, 57), Color.rgb(63, 159, 37), Color.rgb(35, 113, 40)),
        radiusDp = 25,
        insetDp = 3,
        strokeColor = Color.argb(240, 195, 244, 108)
    )

    private fun lightGlassCardBackground(): Drawable = layeredRoundRect(
        outerColors = intArrayOf(Color.rgb(174, 203, 163), Color.rgb(110, 151, 104)),
        innerColors = intArrayOf(Color.argb(250, 255, 255, 250), Color.argb(247, 233, 244, 228)),
        radiusDp = 22,
        insetDp = 2,
        strokeColor = Color.argb(210, 235, 250, 226)
    )

    private fun destinationBadgeBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(115, 212, 54), Color.rgb(34, 126, 45))
    ).apply {
        shape = GradientDrawable.OVAL
        setStroke(dp(1), Color.argb(200, 230, 255, 217))
    }

    private fun searchBadgeBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(139, 220, 78), Color.rgb(47, 139, 51))
    ).apply {
        shape = GradientDrawable.OVAL
        setStroke(dp(1), Color.argb(170, 239, 255, 228))
    }

    private fun searchRowBackground() = GradientDrawable().apply {
        setColor(Color.TRANSPARENT)
        setStroke(0, Color.TRANSPARENT)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    private fun registerTrackingReceiver() {
        val filter = IntentFilter().apply {
            addAction(TrackingService.ACTION_LOCATION_UPDATE)
            addAction(TrackingService.ACTION_GPS_STATUS)
            addAction(TrackingService.ACTION_TRACKING_STOPPED)
        }
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_LOCATION && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            if (pendingStartAfterPermission) startWalk() else centerOnLastLocation()
            pendingStartAfterPermission = false
        }
    }

    override fun onStart() {
        super.onStart()
        mapView.onStart()
    }

    override fun onResume() {
        super.onResume()
        gpsStatus.resumeUpdates()
        mapView.onResume()
        tracking = database.activeWalk() != null
        updateUiState()
        refreshClouds()
        discoveryOverlay.invalidate()
    }

    override fun onPause() {
        gpsStatus.pauseUpdates()
        mapView.onPause()
        super.onPause()
    }

    override fun onStop() {
        mapView.onStop()
        super.onStop()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView.onLowMemory()
    }

    override fun onDestroy() {
        gpxUi.close()
        progressDisposed = true
        // Close after any queued read; never close a database being used by the worker.
        progressExecutor.execute { progressReader?.close(); progressReader = null }
        progressExecutor.shutdown()
        unregisterReceiver(receiver)
        mapView.onDestroy()
        database.close()
        super.onDestroy()
    }

    override fun onRetainCustomNonConfigurationInstance(): Any = RetainedMapState(
        destination, routePoints, navigationOverlay.routeSegments(), importedRoute,
        routeDistanceM, routeDurationS, currentLocation, map?.cameraPosition, followNavigation
    )

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        mapView.onSaveInstanceState(outState)
    }

    companion object {
        private const val REQUEST_LOCATION = 7001
        private const val MENU_MAP_NORMAL = 7101
        private const val MENU_MAP_LIGHT = 7102
        private const val MENU_BACKUP_EXPORT = 7103
        private const val MENU_BACKUP_IMPORT = 7104
        private const val MENU_GPX_EXPORT = 7105
        private const val MENU_GPX_IMPORT = 7106
        private const val MENU_ABOUT = 7107
        private const val MENU_LANGUAGE = 7108
        private val MAP_STYLES = listOf(
            "Standard" to "https://tiles.openfreemap.org/styles/liberty",
            "Light" to "https://tiles.openfreemap.org/styles/bright"
        )
    }
}
