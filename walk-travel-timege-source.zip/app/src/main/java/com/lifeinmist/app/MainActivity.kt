package com.lifeinmist.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.MapLibre
import org.maplibre.android.annotations.IconFactory
import org.maplibre.android.annotations.Marker
import org.maplibre.android.annotations.MarkerOptions
import org.maplibre.android.annotations.Polyline
import org.maplibre.android.annotations.PolylineOptions
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private lateinit var mapView: MapView
    private lateinit var cloudOverlay: FogOverlay
    private lateinit var database: MistDatabase
    private lateinit var startStopButton: Button
    private lateinit var statusText: TextView
    private lateinit var statsText: TextView
    private lateinit var searchInput: EditText
    private lateinit var layerButton: ImageButton

    private var map: MapLibreMap? = null
    private var locationMarker: Marker? = null
    private var destinationMarker: Marker? = null
    private var routePolyline: Polyline? = null
    private var tracking = false
    private var followNavigation = false
    private var currentLocation: LatLng? = null
    private var destination: SearchPlace? = null
    private var routePoints: List<LatLng> = emptyList()
    private var selectedMapStyle = 0
    private var pendingStartAfterPermission = false

    private data class SearchPlace(
        val name: String,
        val lat: Double,
        val lon: Double
    )

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                TrackingService.ACTION_LOCATION_UPDATE -> {
                    val lat = intent.getDoubleExtra(TrackingService.EXTRA_LAT, Double.NaN)
                    val lon = intent.getDoubleExtra(TrackingService.EXTRA_LON, Double.NaN)
                    val accuracy = intent.getFloatExtra(TrackingService.EXTRA_ACCURACY, 0f)
                    val distance = intent.getDoubleExtra(TrackingService.EXTRA_DISTANCE, 0.0)
                    if (!lat.isNaN() && !lon.isNaN()) updateCurrentLocation(lat, lon, followNavigation)
                    statsText.text = "${formatDistance(distance)}  •  GPS ±${accuracy.roundToInt()} м"
                    refreshClouds()
                }

                TrackingService.ACTION_TRACKING_STOPPED -> {
                    tracking = false
                    followNavigation = false
                    updateTrackingUi()
                    refreshClouds()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        database = MistDatabase(this)
        tracking = database.activeWalk() != null

        buildUi(savedInstanceState)
        registerTrackingReceiver()
        initMap()
        updateTrackingUi()
    }

    private fun buildUi(savedInstanceState: Bundle?) {
        val root = FrameLayout(this)

        mapView = MapView(this)
        mapView.onCreate(savedInstanceState)
        root.addView(
            mapView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        cloudOverlay = FogOverlay(this)
        root.addView(
            cloudOverlay,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        val topPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = glassPanelBackground()
            elevation = dp(8).toFloat()
        }

        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        searchInput = EditText(this).apply {
            hint = "Куда едем? Например, Красная площадь"
            setHintTextColor(Color.rgb(102, 116, 132))
            setTextColor(Color.rgb(25, 36, 48))
            textSize = 15f
            setSingleLine(true)
            background = searchFieldBackground()
            setPadding(dp(14), 0, dp(12), 0)
            setOnEditorActionListener { _, _, _ ->
                searchPlaces()
                true
            }
        }
        searchRow.addView(searchInput, LinearLayout.LayoutParams(0, dp(48), 1f))

        val searchButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_search)
            setColorFilter(Color.WHITE)
            background = smallGlassButtonBackground()
            setPadding(dp(12), dp(12), dp(12), dp(12))
            contentDescription = "Найти место"
            setOnClickListener { searchPlaces() }
        }
        searchRow.addView(searchButton, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(8) })

        layerButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_layers)
            setColorFilter(Color.WHITE)
            background = smallGlassButtonBackground()
            setPadding(dp(12), dp(12), dp(12), dp(12))
            contentDescription = "Сменить карту"
            setOnClickListener { cycleMapStyle() }
        }
        searchRow.addView(layerButton, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(8) })

        topPanel.addView(searchRow)

        statusText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 17f
            setPadding(dp(4), dp(10), dp(4), 0)
        }
        statsText = TextView(this).apply {
            setTextColor(Color.rgb(205, 216, 226))
            textSize = 13f
            setPadding(dp(4), dp(2), dp(4), 0)
        }
        topPanel.addView(statusText)
        topPanel.addView(statsText)

        root.addView(
            topPanel,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
                setMargins(dp(14), dp(16), dp(14), 0)
            }
        )

        val centerButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_person_marker)
            background = smallGlassButtonBackground()
            setPadding(dp(11), dp(11), dp(11), dp(11))
            contentDescription = "Показать меня"
            elevation = dp(8).toFloat()
            setOnClickListener { centerOnLastLocation() }
        }
        root.addView(
            centerButton,
            FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM or Gravity.START).apply {
                setMargins(dp(18), 0, 0, dp(24))
            }
        )

        startStopButton = Button(this).apply {
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            compoundDrawablePadding = dp(10)
            setPadding(dp(20), 0, dp(22), 0)
            elevation = dp(10).toFloat()
            setOnClickListener {
                if (tracking) stopWalk() else ensurePermissionAndStart()
            }
        }
        root.addView(
            startStopButton,
            FrameLayout.LayoutParams(dp(230), dp(60), Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(18), dp(24))
            }
        )

        setContentView(root)
    }

    private fun initMap() {
        mapView.getMapAsync { readyMap ->
            map = readyMap
            cloudOverlay.map = readyMap
            readyMap.uiSettings.isRotateGesturesEnabled = true
            readyMap.uiSettings.isTiltGesturesEnabled = false
            applyMapStyle(initial = true)
            readyMap.addOnCameraMoveListener { cloudOverlay.invalidate() }
            readyMap.addOnCameraIdleListener { cloudOverlay.invalidate() }
        }
    }

    private fun applyMapStyle(initial: Boolean = false) {
        val readyMap = map ?: return
        readyMap.setStyle(MAP_STYLES[selectedMapStyle].second) {
            if (initial) {
                readyMap.cameraPosition = CameraPosition.Builder()
                    .target(LatLng(20.0, 0.0))
                    .zoom(2.0)
                    .build()
            }
            refreshClouds()
            redrawAnnotations()
            if (initial) centerOnLastLocation()
        }
    }

    private fun cycleMapStyle() {
        selectedMapStyle = (selectedMapStyle + 1) % MAP_STYLES.size
        Toast.makeText(this, "Карта: ${MAP_STYLES[selectedMapStyle].first}", Toast.LENGTH_SHORT).show()
        applyMapStyle()
    }

    private fun redrawAnnotations() {
        locationMarker = null
        destinationMarker = null
        routePolyline = null
        currentLocation?.let { updateCurrentLocation(it.latitude, it.longitude, false) }
        destination?.let { addDestinationMarker(it) }
        drawRoute()
    }

    private fun ensurePermissionAndStart() {
        val fineGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fineGranted) {
            pendingStartAfterPermission = true
            val permissions = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
            ActivityCompat.requestPermissions(this, permissions.toTypedArray(), REQUEST_LOCATION)
            return
        }
        startWalk()
    }

    private fun startWalk() {
        tracking = true
        followNavigation = destination != null
        updateTrackingUi()
        val intent = Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_START)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopWalk() {
        startService(Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_STOP))
        tracking = false
        followNavigation = false
        updateTrackingUi()
    }

    private fun updateTrackingUi() {
        if (tracking) {
            statusText.text = if (destination != null) "Навигация включена" else "Открываем мир"
            startStopButton.text = "Завершить"
            startStopButton.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_walk, 0, 0, 0)
            startStopButton.background = stopButtonBackground()
            database.activeWalk()?.let {
                statsText.text = "${formatDistance(it.distanceM)}  •  всё открытое сохраняется"
            }
        } else {
            statusText.text = destination?.let { "Цель: ${shortName(it.name)}" } ?: "Walk Travel Timege"
            startStopButton.text = if (destination != null) "Поехали" else "Начать"
            startStopButton.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_walk, 0, 0, 0)
            startStopButton.background = primaryButtonBackground()
            statsText.text = if (destination != null) "Маршрут готов • нажмите «Поехали»" else "Всё открытое остаётся на карте навсегда"
        }
    }

    private fun updateCurrentLocation(lat: Double, lon: Double, follow: Boolean = false) {
        val currentMap = map ?: return
        val position = LatLng(lat, lon)
        currentLocation = position
        val existing = locationMarker
        if (existing == null) {
            val personIcon = IconFactory.getInstance(this).fromResource(R.drawable.ic_person_marker)
            locationMarker = currentMap.addMarker(
                MarkerOptions().position(position).title("Вы здесь").icon(personIcon)
            )
        } else {
            existing.position = position
        }

        if (follow) {
            currentMap.animateCamera(CameraUpdateFactory.newLatLngZoom(position, 16.2))
        }
    }

    private fun refreshClouds() {
        cloudOverlay.setTrackPoints(database.trackPoints())
    }

    private fun centerOnLastLocation() {
        val fineGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fineGranted && !coarseGranted) {
            pendingStartAfterPermission = false
            val permissions = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            ActivityCompat.requestPermissions(this, permissions.toTypedArray(), REQUEST_LOCATION)
            return
        }

        LocationServices.getFusedLocationProviderClient(this).lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                updateCurrentLocation(location.latitude, location.longitude)
                map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(location.latitude, location.longitude), 16.2))
                if (destination != null && routePoints.isEmpty()) buildRoute()
            }
        }
    }

    private fun searchPlaces() {
        val query = searchInput.text.toString().trim()
        if (query.length < 2) {
            Toast.makeText(this, "Введите название места", Toast.LENGTH_SHORT).show()
            return
        }
        hideKeyboard()
        statusText.text = "Ищем место…"
        statsText.text = query

        thread {
            try {
                val encoded = URLEncoder.encode(query, "UTF-8")
                val url = URL("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=5&addressdetails=1&q=$encoded")
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 12_000
                    readTimeout = 12_000
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "WalkTravelTimege/0.4 (Android)")
                    setRequestProperty("Accept-Language", "ru,en;q=0.8")
                }
                val text = connection.inputStream.bufferedReader().use { it.readText() }
                val json = JSONArray(text)
                val places = ArrayList<SearchPlace>()
                for (i in 0 until json.length()) {
                    val obj = json.getJSONObject(i)
                    places += SearchPlace(
                        name = obj.optString("display_name", query),
                        lat = obj.getString("lat").toDouble(),
                        lon = obj.getString("lon").toDouble()
                    )
                }
                runOnUiThread { showSearchResults(places) }
            } catch (e: Exception) {
                runOnUiThread {
                    statusText.text = "Поиск не удался"
                    statsText.text = "Проверьте интернет и попробуйте ещё раз"
                    Toast.makeText(this, "Не удалось выполнить поиск", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun showSearchResults(places: List<SearchPlace>) {
        if (places.isEmpty()) {
            statusText.text = "Ничего не найдено"
            statsText.text = "Попробуйте другое название"
            return
        }
        val names = places.map { shortName(it.name) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Выберите место")
            .setItems(names) { _, which -> selectDestination(places[which]) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun selectDestination(place: SearchPlace) {
        destination = place
        routePoints = emptyList()
        routePolyline?.let { map?.removePolyline(it) }
        routePolyline = null
        destinationMarker?.let { map?.removeMarker(it) }
        destinationMarker = null
        addDestinationMarker(place)
        map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(place.lat, place.lon), 14.5))
        statusText.text = "Цель: ${shortName(place.name)}"
        statsText.text = "Строим маршрут…"
        updateTrackingUi()
        buildRoute()
    }

    private fun addDestinationMarker(place: SearchPlace) {
        val currentMap = map ?: return
        destinationMarker = currentMap.addMarker(
            MarkerOptions().position(LatLng(place.lat, place.lon)).title(shortName(place.name))
        )
    }

    private fun buildRoute() {
        val from = currentLocation
        val to = destination
        if (from == null || to == null) {
            centerOnLastLocation()
            return
        }

        thread {
            try {
                val url = URL(
                    "https://router.project-osrm.org/route/v1/driving/${from.longitude},${from.latitude};${to.lon},${to.lat}?overview=full&geometries=geojson&steps=false"
                )
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15_000
                    readTimeout = 15_000
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "WalkTravelTimege/0.4 (Android)")
                }
                val root = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
                val route = root.getJSONArray("routes").getJSONObject(0)
                val coordinates = route.getJSONObject("geometry").getJSONArray("coordinates")
                val points = ArrayList<LatLng>(coordinates.length())
                for (i in 0 until coordinates.length()) {
                    val pair = coordinates.getJSONArray(i)
                    points += LatLng(pair.getDouble(1), pair.getDouble(0))
                }
                val distanceM = route.optDouble("distance", 0.0)
                val durationS = route.optDouble("duration", 0.0)
                runOnUiThread {
                    routePoints = points
                    drawRoute()
                    statusText.text = "Цель: ${shortName(to.name)}"
                    statsText.text = "${formatDistance(distanceM)}  •  ~${formatDuration(durationS)}"
                    updateTrackingUi()
                    fitRoute(points)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    routePoints = emptyList()
                    statsText.text = "Не удалось построить маршрут"
                    Toast.makeText(this, "Маршрут временно недоступен", Toast.LENGTH_SHORT).show()
                    updateTrackingUi()
                }
            }
        }
    }

    private fun drawRoute() {
        val currentMap = map ?: return
        routePolyline?.let { currentMap.removePolyline(it) }
        routePolyline = null
        if (routePoints.size < 2) return
        routePolyline = currentMap.addPolyline(
            PolylineOptions()
                .addAll(routePoints)
                .color(Color.rgb(68, 169, 255))
                .width(7f)
        )
    }

    private fun fitRoute(points: List<LatLng>) {
        if (points.isEmpty()) return
        val lats = points.map { it.latitude }
        val lons = points.map { it.longitude }
        val bounds = org.maplibre.android.geometry.LatLngBounds.Builder()
            .include(LatLng(lats.minOrNull() ?: return, lons.minOrNull() ?: return))
            .include(LatLng(lats.maxOrNull() ?: return, lons.maxOrNull() ?: return))
            .build()
        map?.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, dp(70)))
    }

    private fun formatDistance(meters: Double): String =
        if (meters < 1000) "${meters.roundToInt()} м" else String.format(Locale.getDefault(), "%.2f км", meters / 1000.0)

    private fun formatDuration(seconds: Double): String {
        val mins = (seconds / 60.0).roundToInt().coerceAtLeast(1)
        return if (mins < 60) "$mins мин" else "${mins / 60} ч ${mins % 60} мин"
    }

    private fun shortName(name: String): String = name.substringBefore(',').take(42)

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(searchInput.windowToken, 0)
        searchInput.clearFocus()
    }

    private fun glassPanelBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.argb(240, 24, 34, 45), Color.argb(232, 46, 63, 79))
    ).apply {
        cornerRadius = dp(25).toFloat()
        setStroke(dp(1), Color.argb(62, 255, 255, 255))
    }

    private fun searchFieldBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.argb(198, 255, 255, 255), Color.argb(176, 222, 234, 244))
    ).apply {
        cornerRadius = dp(18).toFloat()
        setStroke(dp(1), Color.argb(65, 255, 255, 255))
    }

    private fun smallGlassButtonBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.argb(240, 68, 91, 111), Color.argb(230, 31, 43, 56))
    ).apply {
        shape = GradientDrawable.OVAL
        setStroke(dp(1), Color.argb(96, 255, 255, 255))
    }

    private fun primaryButtonBackground() = GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT,
        intArrayOf(Color.rgb(34, 139, 255), Color.rgb(113, 204, 255))
    ).apply {
        cornerRadius = dp(28).toFloat()
        setStroke(dp(1), Color.argb(105, 255, 255, 255))
    }

    private fun stopButtonBackground() = GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT,
        intArrayOf(Color.rgb(230, 73, 92), Color.rgb(255, 131, 112))
    ).apply {
        cornerRadius = dp(28).toFloat()
        setStroke(dp(1), Color.argb(100, 255, 255, 255))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    private fun registerTrackingReceiver() {
        val filter = IntentFilter().apply {
            addAction(TrackingService.ACTION_LOCATION_UPDATE)
            addAction(TrackingService.ACTION_TRACKING_STOPPED)
        }
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_LOCATION && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            if (pendingStartAfterPermission) startWalk() else centerOnLastLocation()
            pendingStartAfterPermission = false
        }
    }

    override fun onStart() { super.onStart(); mapView.onStart() }
    override fun onResume() {
        super.onResume()
        mapView.onResume()
        tracking = database.activeWalk() != null
        updateTrackingUi()
        refreshClouds()
    }
    override fun onPause() { mapView.onPause(); super.onPause() }
    override fun onStop() { mapView.onStop(); super.onStop() }
    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }
    override fun onDestroy() {
        unregisterReceiver(receiver)
        mapView.onDestroy()
        database.close()
        super.onDestroy()
    }
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        mapView.onSaveInstanceState(outState)
    }

    companion object {
        private const val REQUEST_LOCATION = 7001
        private val MAP_STYLES = listOf(
            "Обычная" to "https://tiles.openfreemap.org/styles/liberty",
            "Светлая" to "https://tiles.openfreemap.org/styles/bright"
        )
    }
}
