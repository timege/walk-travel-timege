package com.lifeinmist.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import org.maplibre.android.MapLibre
import org.maplibre.android.annotations.Marker
import org.maplibre.android.annotations.MarkerOptions
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private lateinit var mapView: MapView
    private lateinit var fogOverlay: FogOverlay
    private lateinit var database: MistDatabase
    private lateinit var startStopButton: Button
    private lateinit var statusText: TextView
    private lateinit var statsText: TextView

    private var map: MapLibreMap? = null
    private var locationMarker: Marker? = null
    private var tracking = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                TrackingService.ACTION_LOCATION_UPDATE -> {
                    val lat = intent.getDoubleExtra(TrackingService.EXTRA_LAT, Double.NaN)
                    val lon = intent.getDoubleExtra(TrackingService.EXTRA_LON, Double.NaN)
                    val accuracy = intent.getFloatExtra(TrackingService.EXTRA_ACCURACY, 0f)
                    val distance = intent.getDoubleExtra(TrackingService.EXTRA_DISTANCE, 0.0)
                    if (!lat.isNaN() && !lon.isNaN()) updateCurrentLocation(lat, lon)
                    statsText.text = "${formatDistance(distance)}  •  GPS ±${accuracy.roundToInt()} м"
                    refreshFog()
                }

                TrackingService.ACTION_TRACKING_STOPPED -> {
                    tracking = false
                    updateTrackingUi()
                    refreshFog()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        database = MistDatabase(this)
        tracking = database.activeWalk() != null

        buildUi(savedInstanceState)
        registerTrackingReceiver()
        initMap()
        updateTrackingUi()
    }

    private fun buildUi(savedInstanceState: Bundle?) {
        val root = FrameLayout(this)

        mapView = MapView(this)
        mapView.onCreate(savedInstanceState)
        root.addView(mapView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        fogOverlay = FogOverlay(this)
        root.addView(fogOverlay, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        val topCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            background = glassPanelBackground()
            elevation = dp(8).toFloat()
        }
        statusText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
        }
        statsText = TextView(this).apply {
            setTextColor(Color.rgb(205, 216, 226))
            textSize = 13f
            text = "Открытая карта сохраняется навсегда"
        }
        topCard.addView(statusText)
        topCard.addView(statsText)
        root.addView(topCard, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP
        ).apply {
            setMargins(dp(16), dp(18), dp(16), 0)
        })

        // No history button: the app has one persistent explored world map.
        val centerButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_my_location)
            setColorFilter(Color.WHITE)
            background = smallGlassButtonBackground()
            setPadding(dp(15), dp(15), dp(15), dp(15))
            contentDescription = "Показать моё местоположение"
            elevation = dp(8).toFloat()
            setOnClickListener { centerOnLastLocation() }
        }
        root.addView(centerButton, FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM or Gravity.START).apply {
            setMargins(dp(18), 0, 0, dp(24))
        })

        startStopButton = Button(this).apply {
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            compoundDrawablePadding = dp(10)
            setPadding(dp(20), 0, dp(22), 0)
            elevation = dp(10).toFloat()
            setOnClickListener {
                if (tracking) stopWalk() else ensurePermissionAndStart()
            }
        }
        root.addView(startStopButton, FrameLayout.LayoutParams(dp(230), dp(60), Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(18), dp(24))
        })

        setContentView(root)
    }

    private fun initMap() {
        mapView.getMapAsync { readyMap ->
            map = readyMap
            fogOverlay.map = readyMap
            readyMap.uiSettings.isRotateGesturesEnabled = true
            readyMap.uiSettings.isTiltGesturesEnabled = false
            readyMap.setStyle(MAP_STYLE_URL) {
                readyMap.cameraPosition = CameraPosition.Builder()
                    .target(LatLng(20.0, 0.0))
                    .zoom(2.0)
                    .build()
                // Every point from every previous recording session is loaded here.
                // The explored world therefore survives restarts and new recordings.
                refreshFog()
                centerOnLastLocation()
            }
            readyMap.addOnCameraMoveListener { fogOverlay.invalidate() }
            readyMap.addOnCameraIdleListener { fogOverlay.invalidate() }
        }
    }

    private fun ensurePermissionAndStart() {
        val fineGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fineGranted) {
            val permissions = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
            ActivityCompat.requestPermissions(this, permissions.toTypedArray(), REQUEST_LOCATION)
            return
        }
        startWalk()
    }

    private fun startWalk() {
        tracking = true
        updateTrackingUi()
        val intent = Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_START)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopWalk() {
        startService(Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_STOP))
        tracking = false
        updateTrackingUi()
    }

    private fun updateTrackingUi() {
        if (tracking) {
            statusText.text = "Карта открывается"
            startStopButton.text = "Завершить"
            startStopButton.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_walk, 0, 0, 0)
            startStopButton.background = stopButtonBackground()
            database.activeWalk()?.let {
                statsText.text = "${formatDistance(it.distanceM)}  •  открываем новые места"
            }
        } else {
            statusText.text = "Walk Travel Timege"
            startStopButton.text = "Начать"
            startStopButton.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_walk, 0, 0, 0)
            startStopButton.background = primaryButtonBackground()
            statsText.text = "Всё открытое остаётся на карте навсегда"
        }
    }

    private fun updateCurrentLocation(lat: Double, lon: Double) {
        val currentMap = map ?: return
        val position = LatLng(lat, lon)
        val existing = locationMarker
        if (existing == null) {
            locationMarker = currentMap.addMarker(
                MarkerOptions().position(position).title("Вы здесь")
            )
            currentMap.animateCamera(
                org.maplibre.android.camera.CameraUpdateFactory.newLatLngZoom(position, 16.5)
            )
        } else {
            existing.position = position
        }
    }

    private fun refreshFog() {
        // trackPoints() intentionally returns ALL saved points, not only the active session.
        fogOverlay.setTrackPoints(database.trackPoints())
    }

    private fun centerOnLastLocation() {
        val fineGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fineGranted && !coarseGranted) return

        LocationServices.getFusedLocationProviderClient(this).lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                updateCurrentLocation(location.latitude, location.longitude)
                map?.animateCamera(
                    org.maplibre.android.camera.CameraUpdateFactory.newLatLngZoom(
                        LatLng(location.latitude, location.longitude), 16.5
                    )
                )
            }
        }
    }

    private fun registerTrackingReceiver() {
        val filter = IntentFilter().apply {
            addAction(TrackingService.ACTION_LOCATION_UPDATE)
            addAction(TrackingService.ACTION_TRACKING_STOPPED)
        }
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_LOCATION) {
            val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (granted) startWalk()
            else AlertDialog.Builder(this)
                .setTitle("Нужна геолокация")
                .setMessage("Без точной геолокации приложение не сможет открывать карту по маршруту.")
                .setPositiveButton("ОК", null)
                .show()
        }
    }

    private fun formatDistance(meters: Double): String =
        if (meters < 1000.0) "${meters.roundToInt()} м" else String.format(Locale.getDefault(), "%.2f км", meters / 1000.0)

    private fun glassPanelBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.argb(236, 17, 24, 34), Color.argb(224, 31, 43, 56))
    ).apply {
        cornerRadius = dp(24).toFloat()
        setStroke(dp(1), Color.argb(52, 255, 255, 255))
    }

    private fun smallGlassButtonBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.argb(238, 31, 44, 58), Color.argb(226, 16, 24, 34))
    ).apply {
        shape = GradientDrawable.OVAL
        setStroke(dp(1), Color.argb(80, 255, 255, 255))
    }

    private fun primaryButtonBackground() = GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT,
        intArrayOf(Color.rgb(24, 137, 255), Color.rgb(88, 190, 255))
    ).apply {
        cornerRadius = dp(24).toFloat()
        setStroke(dp(1), Color.argb(90, 255, 255, 255))
    }

    private fun stopButtonBackground() = GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT,
        intArrayOf(Color.rgb(234, 72, 86), Color.rgb(255, 115, 105))
    ).apply {
        cornerRadius = dp(24).toFloat()
        setStroke(dp(1), Color.argb(90, 255, 255, 255))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    override fun onStart() { super.onStart(); mapView.onStart() }
    override fun onResume() {
        super.onResume()
        mapView.onResume()
        tracking = database.activeWalk() != null
        updateTrackingUi()
        refreshFog()
    }
    override fun onPause() { mapView.onPause(); super.onPause() }
    override fun onStop() { mapView.onStop(); super.onStop() }
    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }
    override fun onDestroy() {
        unregisterReceiver(receiver)
        mapView.onDestroy()
        database.close()
        super.onDestroy()
    }
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        mapView.onSaveInstanceState(outState)
    }

    companion object {
        private const val REQUEST_LOCATION = 7001
        private const val MAP_STYLE_URL = "https://tiles.openfreemap.org/styles/liberty"
    }
}
