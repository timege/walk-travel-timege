package com.lifeinmist.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.location.LocationServices
import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private lateinit var mapView: MapView
    private lateinit var cloudOverlay: FogOverlay
    private lateinit var navigationOverlay: NavigationOverlay
    private lateinit var database: MistDatabase

    private lateinit var topPanel: LinearLayout
    private lateinit var searchRow: LinearLayout
    private lateinit var searchInput: EditText
    private lateinit var statusText: TextView
    private lateinit var searchResultsPanel: LinearLayout
    private lateinit var destinationCard: LinearLayout
    private lateinit var destinationTitle: TextView
    private lateinit var destinationSubtitle: TextView
    private lateinit var startStopButton: Button
    private lateinit var compassArrow: TextView
    private var topInsetPx: Int = 0
    private var routeDistanceM: Double = 0.0
    private var routeDurationS: Double = 0.0

    private var map: MapLibreMap? = null
    private var tracking = false
    private var followNavigation = false
    private var currentLocation: LatLng? = null
    private var currentAccuracyM: Float = 0f
    private var destination: SearchPlace? = null
    private var routePoints: List<LatLng> = emptyList()
    private var selectedMapStyle = 0
    private var pendingStartAfterPermission = false
    private var routeBuilding = false

    private data class SearchPlace(
        val name: String,
        val lat: Double,
        val lon: Double
    )


    private val exportProgressLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        thread {
            try {
                val json = database.exportProgressJson()
                contentResolver.openOutputStream(uri, "w")?.bufferedWriter()?.use { writer ->
                    writer.write(json)
                } ?: error("Cannot open backup file")
                runOnUiThread {
                    Toast.makeText(this, "Резервная копия сохранена", Toast.LENGTH_LONG).show()
                }
            } catch (_: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Не удалось сохранить копию", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private val importProgressLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        thread {
            try {
                val json = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: error("Cannot read backup file")
                val restored = database.importProgressJson(json)
                runOnUiThread {
                    refreshClouds()
                    Toast.makeText(
                        this,
                        if (restored > 0) "Прогресс восстановлен: $restored точек" else "Весь прогресс уже есть на карте",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (_: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Это не резервная копия Walk Travel Timege", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                TrackingService.ACTION_LOCATION_UPDATE -> {
                    val lat = intent.getDoubleExtra(TrackingService.EXTRA_LAT, Double.NaN)
                    val lon = intent.getDoubleExtra(TrackingService.EXTRA_LON, Double.NaN)
                    currentAccuracyM = intent.getFloatExtra(TrackingService.EXTRA_ACCURACY, 0f)
                    if (!lat.isNaN() && !lon.isNaN()) {
                        updateCurrentLocation(lat, lon, followNavigation)
                    }
                    refreshClouds()
                }

                TrackingService.ACTION_TRACKING_STOPPED -> {
                    tracking = false
                    followNavigation = false
                    updateUiState()
                    refreshClouds()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        database = MistDatabase(this)
        tracking = database.activeWalk() != null
        selectedMapStyle = getSharedPreferences("ui", MODE_PRIVATE).getInt("mapStyle", 0)
            .coerceIn(0, MAP_STYLES.lastIndex)

        buildUi(savedInstanceState)
        registerTrackingReceiver()
        initMap()
        updateUiState()
    }

    private fun buildUi(savedInstanceState: Bundle?) {
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(226, 236, 244))
        }

        mapView = MapView(this)
        mapView.onCreate(savedInstanceState)
        root.addView(
            mapView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        cloudOverlay = FogOverlay(this)
        root.addView(
            cloudOverlay,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        navigationOverlay = NavigationOverlay(this)
        root.addView(
            navigationOverlay,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        topPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = glassPanelBackground()
            elevation = dp(8).toFloat()
        }

        searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        searchInput = EditText(this).apply {
            hint = "Куда едем? Например, Красная площадь"
            setHintTextColor(Color.rgb(91, 111, 132))
            setTextColor(Color.rgb(35, 54, 72))
            textSize = 14.5f
            setSingleLine(true)
            background = searchFieldBackground()
            setPadding(dp(15), 0, dp(12), 0)
            setOnEditorActionListener { _, _, _ ->
                searchPlaces()
                true
            }
        }
        searchRow.addView(searchInput, LinearLayout.LayoutParams(0, dp(46), 1f))

        val searchButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_search)
            setColorFilter(Color.WHITE)
            background = roundGlassButtonBackground()
            setPadding(dp(12), dp(12), dp(12), dp(12))
            contentDescription = "Найти место"
            setOnClickListener { searchPlaces() }
        }
        searchRow.addView(
            searchButton,
            LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginStart = dp(7) }
        )

        val layerButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_layers)
            setColorFilter(Color.WHITE)
            background = roundGlassButtonBackground()
            setPadding(dp(12), dp(12), dp(12), dp(12))
            contentDescription = "Сменить карту"
            setOnClickListener { showMapMenu(this) }
        }
        searchRow.addView(
            layerButton,
            LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginStart = dp(7) }
        )

        topPanel.addView(searchRow)

        statusText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 22f
            setPadding(dp(5), dp(10), dp(5), 0)
            typeface = android.graphics.Typeface.create("sans", android.graphics.Typeface.NORMAL)
        }
        topPanel.addView(statusText)

        val topPanelParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP
        ).apply {
            setMargins(dp(14), dp(16), dp(14), 0)
        }
        root.addView(topPanel, topPanelParams)

        searchResultsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = lightGlassCardBackground()
            elevation = dp(11).toFloat()
            visibility = View.GONE
        }
        val searchResultsParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP
        ).apply {
            setMargins(dp(28), dp(84), dp(28), 0)
        }
        root.addView(searchResultsPanel, searchResultsParams)

        destinationCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(10), dp(12))
            background = lightGlassCardBackground()
            elevation = dp(10).toFloat()
            visibility = View.GONE
        }

        val pinBadge = TextView(this).apply {
            text = "●"
            gravity = Gravity.CENTER
            textSize = 22f
            setTextColor(Color.WHITE)
            background = destinationBadgeBackground()
        }
        destinationCard.addView(pinBadge, LinearLayout.LayoutParams(dp(48), dp(48)))

        val destinationTextColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(8), 0)
        }
        destinationTitle = TextView(this).apply {
            setTextColor(Color.rgb(28, 49, 71))
            textSize = 17f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 1
        }
        destinationSubtitle = TextView(this).apply {
            setTextColor(Color.rgb(66, 125, 182))
            textSize = 13f
            setPadding(0, dp(3), 0, 0)
            maxLines = 1
        }
        destinationTextColumn.addView(destinationTitle)
        destinationTextColumn.addView(destinationSubtitle)
        destinationCard.addView(destinationTextColumn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val closeDestination = TextView(this).apply {
            text = "×"
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(71, 100, 126))
            textSize = 25f
            setOnClickListener { clearDestination() }
        }
        destinationCard.addView(closeDestination, LinearLayout.LayoutParams(dp(40), dp(48)))

        val destinationCardParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP
        ).apply {
            setMargins(dp(14), dp(16), dp(14), 0)
        }
        root.addView(destinationCard, destinationCardParams)

        val centerButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_my_location)
            setColorFilter(Color.rgb(57, 90, 120))
            background = locateButtonBackground()
            setPadding(dp(13), dp(13), dp(13), dp(13))
            contentDescription = "Показать меня"
            elevation = dp(8).toFloat()
            setOnClickListener { centerOnLastLocation() }
        }
        root.addView(
            centerButton,
            FrameLayout.LayoutParams(dp(50), dp(50), Gravity.BOTTOM or Gravity.START).apply {
                setMargins(dp(18), 0, 0, dp(22))
            }
        )

        startStopButton = Button(this).apply {
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            minWidth = dp(128)
            minHeight = 0
            setPadding(dp(28), 0, dp(28), 0)
            elevation = dp(10).toFloat()
            background = primaryButtonBackground()
            setOnClickListener {
                when {
                    tracking -> stopWalk()
                    destination != null && routePoints.isNotEmpty() -> ensurePermissionAndStart()
                    destination != null && !routeBuilding -> buildRoute()
                    else -> ensurePermissionAndStart()
                }
            }
        }
        root.addView(
            startStopButton,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                dp(48),
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply {
                setMargins(0, 0, 0, dp(22))
            }
        )

        val compassButton = FrameLayout(this).apply {
            background = locateButtonBackground()
            elevation = dp(7).toFloat()
            contentDescription = "Компас. Вернуть север вверх"
            setOnClickListener { resetNorth() }
        }
        compassArrow = TextView(this).apply {
            text = "▲"
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(57, 90, 120))
            textSize = 17f
        }
        compassButton.addView(
            compassArrow,
            FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER).apply {
                topMargin = -dp(3)
            }
        )
        val northLabel = TextView(this).apply {
            text = "N"
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(57, 90, 120))
            textSize = 10f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        compassButton.addView(
            northLabel,
            FrameLayout.LayoutParams(dp(24), dp(18), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = dp(4)
            }
        )
        root.addView(
            compassButton,
            FrameLayout.LayoutParams(dp(46), dp(46), Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(18), dp(84))
            }
        )

        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            topInsetPx = bars.top

            (topPanel.layoutParams as FrameLayout.LayoutParams).apply {
                topMargin = dp(16) + topInsetPx
                topPanel.layoutParams = this
            }
            (destinationCard.layoutParams as FrameLayout.LayoutParams).apply {
                topMargin = dp(16) + topInsetPx
                destinationCard.layoutParams = this
            }
            (searchResultsPanel.layoutParams as FrameLayout.LayoutParams).apply {
                topMargin = dp(84) + topInsetPx
                searchResultsPanel.layoutParams = this
            }
            insets
        }
        ViewCompat.requestApplyInsets(root)
    }

    private fun initMap() {
        mapView.getMapAsync { readyMap ->
            map = readyMap
            cloudOverlay.map = readyMap
            navigationOverlay.map = readyMap
            readyMap.uiSettings.isRotateGesturesEnabled = true
            readyMap.uiSettings.isTiltGesturesEnabled = false
            applyMapStyle(initial = true)
            readyMap.addOnCameraMoveListener {
                cloudOverlay.invalidate()
                navigationOverlay.invalidate()
                updateCompass()
            }
            readyMap.addOnCameraIdleListener {
                cloudOverlay.invalidate()
                navigationOverlay.invalidate()
            }
        }
    }

    private fun applyMapStyle(initial: Boolean = false) {
        val readyMap = map ?: return
        readyMap.setStyle(MAP_STYLES[selectedMapStyle].second) {
            if (initial) {
                readyMap.cameraPosition = CameraPosition.Builder()
                    .target(LatLng(20.0, 0.0))
                    .zoom(2.0)
                    .build()
            }
            refreshClouds()
            navigationOverlay.setCurrentLocation(currentLocation)
            navigationOverlay.setDestination(destination?.let { LatLng(it.lat, it.lon) })
            navigationOverlay.setRoute(routePoints)
            if (initial) centerOnLastLocation()
        }
    }

    private fun showMapMenu(anchor: View) {
        PopupMenu(this, anchor).apply {
            menu.add(0, MENU_MAP_NORMAL, 0, if (selectedMapStyle == 0) "✓ Карта: обычная" else "Карта: обычная")
            menu.add(0, MENU_MAP_LIGHT, 1, if (selectedMapStyle == 1) "✓ Карта: светлая" else "Карта: светлая")
            menu.add(0, MENU_BACKUP_EXPORT, 3, "Сохранить прогресс")
            menu.add(0, MENU_BACKUP_IMPORT, 4, "Восстановить прогресс")
            setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    MENU_MAP_NORMAL -> setMapStyle(0)
                    MENU_MAP_LIGHT -> setMapStyle(1)
                    MENU_BACKUP_EXPORT -> exportProgressBackup()
                    MENU_BACKUP_IMPORT -> importProgressBackup()
                }
                true
            }
            show()
        }
    }

    private fun setMapStyle(index: Int) {
        if (index !in MAP_STYLES.indices || index == selectedMapStyle) return
        selectedMapStyle = index
        getSharedPreferences("ui", MODE_PRIVATE).edit().putInt("mapStyle", selectedMapStyle).apply()
        applyMapStyle()
    }

    private fun exportProgressBackup() {
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        exportProgressLauncher.launch("walk-travel-timege-progress-$date.json")
    }

    private fun importProgressBackup() {
        importProgressLauncher.launch(arrayOf("application/json", "text/plain", "application/octet-stream"))
    }

    private fun cycleMapStyle() {
        selectedMapStyle = (selectedMapStyle + 1) % MAP_STYLES.size
        getSharedPreferences("ui", MODE_PRIVATE).edit().putInt("mapStyle", selectedMapStyle).apply()
        Toast.makeText(this, "Карта: ${MAP_STYLES[selectedMapStyle].first}", Toast.LENGTH_SHORT).show()
        applyMapStyle()
    }

    private fun ensurePermissionAndStart() {
        val fineGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (!fineGranted) {
            pendingStartAfterPermission = true
            val permissions = mutableListOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
            if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
            ActivityCompat.requestPermissions(this, permissions.toTypedArray(), REQUEST_LOCATION)
            return
        }
        startWalk()
    }

    private fun startWalk() {
        tracking = true
        followNavigation = destination != null
        hideSearchResults()
        updateUiState()
        val intent = Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_START)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopWalk() {
        startService(Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_STOP))
        tracking = false
        followNavigation = false
        updateUiState()
    }

    private fun updateUiState() {
        val hasDestination = destination != null
        val routeReady = routePoints.size > 1

        if (tracking) {
            destinationCard.visibility = View.GONE
            topPanel.visibility = View.VISIBLE
            searchRow.visibility = View.VISIBLE
            statusText.visibility = View.VISIBLE
            statusText.text = "Прогулка идёт"
            startStopButton.text = "Завершить"
            startStopButton.isEnabled = true
            startStopButton.alpha = 1f
            startStopButton.background = primaryButtonBackground()
            return
        }

        if (hasDestination) {
            hideSearchResults()
            topPanel.visibility = View.GONE
            destinationCard.visibility = View.VISIBLE
            destinationTitle.text = shortName(destination!!.name)
            destinationSubtitle.text = when {
                routeBuilding -> "Строим маршрут…"
                routeReady -> routeSummaryText()
                else -> "Выберите действие"
            }

            startStopButton.text = when {
                routeBuilding -> "Строим…"
                routeReady -> "В путь"
                else -> "Построить маршрут"
            }
            startStopButton.isEnabled = !routeBuilding
            startStopButton.alpha = if (routeBuilding) 0.72f else 1f
            startStopButton.background = primaryButtonBackground()
            return
        }

        destinationCard.visibility = View.GONE
        topPanel.visibility = View.VISIBLE
        searchRow.visibility = View.VISIBLE
        statusText.visibility = View.GONE
        statusText.text = ""
        startStopButton.text = "Начать"
        startStopButton.isEnabled = true
        startStopButton.alpha = 1f
        startStopButton.background = primaryButtonBackground()
    }

    private fun updateCurrentLocation(lat: Double, lon: Double, follow: Boolean = false) {
        val position = LatLng(lat, lon)
        currentLocation = position
        cloudOverlay.setCurrentLocation(position)
        navigationOverlay.setCurrentLocation(position)

        if (follow) {
            map?.animateCamera(CameraUpdateFactory.newLatLngZoom(position, 16.2))
        }
    }

    private fun refreshClouds() {
        cloudOverlay.setTrackPoints(database.trackPoints())
        cloudOverlay.setCurrentLocation(currentLocation)
    }

    private fun centerOnLastLocation() {
        val fineGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (!fineGranted && !coarseGranted) {
            pendingStartAfterPermission = false
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                REQUEST_LOCATION
            )
            return
        }

        LocationServices.getFusedLocationProviderClient(this).lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                currentAccuracyM = location.accuracy
                updateCurrentLocation(location.latitude, location.longitude)
                map?.animateCamera(
                    CameraUpdateFactory.newLatLngZoom(
                        LatLng(location.latitude, location.longitude),
                        16.2
                    )
                )
                if (destination != null && routePoints.isEmpty() && !routeBuilding) buildRoute()
            }
        }
    }

    private fun searchPlaces() {
        val query = searchInput.text.toString().trim()
        if (query.length < 2) {
            Toast.makeText(this, "Введите название места", Toast.LENGTH_SHORT).show()
            return
        }

        hideKeyboard()
        statusText.visibility = View.VISIBLE
        statusText.text = "Ищем место…"
        hideSearchResults()

        thread {
            try {
                val encoded = URLEncoder.encode(query, "UTF-8")
                val url = URL(
                    "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=5&addressdetails=1&q=$encoded"
                )
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 12_000
                    readTimeout = 12_000
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "WalkTravelTimege/0.5 (Android)")
                    setRequestProperty("Accept-Language", "ru,en;q=0.8")
                }
                val text = connection.inputStream.bufferedReader().use { it.readText() }
                val json = JSONArray(text)
                val places = ArrayList<SearchPlace>()
                for (i in 0 until json.length()) {
                    val obj = json.getJSONObject(i)
                    places += SearchPlace(
                        name = obj.optString("display_name", query),
                        lat = obj.getString("lat").toDouble(),
                        lon = obj.getString("lon").toDouble()
                    )
                }
                runOnUiThread { showSearchResults(places) }
            } catch (_: Exception) {
                runOnUiThread {
                    statusText.visibility = View.VISIBLE
                    statusText.text = "Поиск не удался"
                    Toast.makeText(this, "Проверьте интернет и попробуйте ещё раз", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun showSearchResults(places: List<SearchPlace>) {
        if (places.isEmpty()) {
            statusText.visibility = View.VISIBLE
            statusText.text = "Ничего не найдено"
            return
        }

        searchResultsPanel.removeAllViews()
        statusText.visibility = View.GONE

        places.forEachIndexed { index, place ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(9), dp(8), dp(9))
                background = if (index == places.lastIndex) null else searchRowBackground()
                setOnClickListener { selectDestination(place) }
            }

            val badge = TextView(this).apply {
                text = "●"
                gravity = Gravity.CENTER
                textSize = 16f
                setTextColor(Color.WHITE)
                background = searchBadgeBackground()
            }
            row.addView(badge, LinearLayout.LayoutParams(dp(40), dp(40)))

            val textColumn = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), 0, dp(8), 0)
            }
            val title = TextView(this).apply {
                text = shortName(place.name)
                setTextColor(Color.rgb(34, 56, 80))
                textSize = 15f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                maxLines = 1
            }
            val subtitle = TextView(this).apply {
                text = secondaryName(place.name)
                setTextColor(Color.rgb(98, 126, 151))
                textSize = 12f
                maxLines = 1
            }
            textColumn.addView(title)
            textColumn.addView(subtitle)
            row.addView(textColumn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val arrow = TextView(this).apply {
                text = "›"
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(67, 116, 162))
                textSize = 28f
            }
            row.addView(arrow, LinearLayout.LayoutParams(dp(30), dp(40)))

            searchResultsPanel.addView(
                row,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60))
            )
        }

        searchResultsPanel.visibility = View.VISIBLE
    }

    private fun hideSearchResults() {
        searchResultsPanel.visibility = View.GONE
        if (::statusText.isInitialized && topPanel.visibility == View.VISIBLE) {
            statusText.visibility = View.VISIBLE
        }
    }

    private fun selectDestination(place: SearchPlace) {
        hideKeyboard()
        hideSearchResults()
        destination = place
        routePoints = emptyList()
        routeDistanceM = 0.0
        routeDurationS = 0.0
        routeBuilding = false
        navigationOverlay.setRoute(emptyList())
        navigationOverlay.setDestination(LatLng(place.lat, place.lon))
        map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(place.lat, place.lon), 14.5))
        updateUiState()
        buildRoute()
    }

    private fun clearDestination() {
        destination = null
        routePoints = emptyList()
        routeDistanceM = 0.0
        routeDurationS = 0.0
        routeBuilding = false
        followNavigation = false
        navigationOverlay.setDestination(null)
        navigationOverlay.setRoute(emptyList())
        searchInput.text?.clear()
        updateUiState()
    }

    private fun buildRoute() {
        val to = destination ?: return
        val from = currentLocation
        if (from == null) {
            centerOnLastLocation()
            return
        }
        if (routeBuilding) return

        routeBuilding = true
        routePoints = emptyList()
        routeDistanceM = 0.0
        routeDurationS = 0.0
        navigationOverlay.setRoute(emptyList())
        updateUiState()

        thread {
            try {
                val url = URL(
                    "https://router.project-osrm.org/route/v1/driving/${from.longitude},${from.latitude};${to.lon},${to.lat}?overview=full&geometries=geojson&steps=false"
                )
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15_000
                    readTimeout = 15_000
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "WalkTravelTimege/0.5 (Android)")
                }
                val root = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
                val route = root.getJSONArray("routes").getJSONObject(0)
                val coordinates = route.getJSONObject("geometry").getJSONArray("coordinates")
                val points = ArrayList<LatLng>(coordinates.length())
                for (i in 0 until coordinates.length()) {
                    val pair = coordinates.getJSONArray(i)
                    points += LatLng(pair.getDouble(1), pair.getDouble(0))
                }
                val distanceMeters = route.optDouble("distance", 0.0)
                val durationSeconds = route.optDouble("duration", 0.0)

                runOnUiThread {
                    routeBuilding = false
                    routeDistanceM = distanceMeters
                    routeDurationS = durationSeconds
                    routePoints = points
                    navigationOverlay.setRoute(points)
                    updateUiState()
                    fitRoute(points)
                }
            } catch (_: Exception) {
                runOnUiThread {
                    routeBuilding = false
                    routePoints = emptyList()
                    routeDistanceM = 0.0
                    routeDurationS = 0.0
                    navigationOverlay.setRoute(emptyList())
                    updateUiState()
                    Toast.makeText(this, "Маршрут временно недоступен", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun fitRoute(points: List<LatLng>) {
        if (points.isEmpty()) return
        val lats = points.map { it.latitude }
        val lons = points.map { it.longitude }
        val bounds = org.maplibre.android.geometry.LatLngBounds.Builder()
            .include(LatLng(lats.minOrNull() ?: return, lons.minOrNull() ?: return))
            .include(LatLng(lats.maxOrNull() ?: return, lons.maxOrNull() ?: return))
            .build()
        map?.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, dp(70)))
    }

    private fun routeSummaryText(): String {
        if (routeDistanceM <= 0.0) return "Маршрут построен"
        val distanceText = if (routeDistanceM < 1000.0) {
            "${routeDistanceM.roundToInt()} м"
        } else {
            String.format(Locale.getDefault(), "%.1f км", routeDistanceM / 1000.0)
        }
        val walkingMinutes = ((routeDistanceM / 1.35) / 60.0).roundToInt().coerceAtLeast(1)
        val timeText = if (walkingMinutes < 60) {
            "≈$walkingMinutes мин"
        } else {
            val hours = walkingMinutes / 60
            val minutes = walkingMinutes % 60
            if (minutes == 0) "≈$hours ч" else "≈$hours ч $minutes мин"
        }
        return "Маршрут построен · $distanceText · $timeText"
    }

    private fun updateCompass() {
        if (!::compassArrow.isInitialized) return
        val bearing = map?.cameraPosition?.bearing ?: 0.0
        compassArrow.rotation = (-bearing).toFloat()
    }

    private fun resetNorth() {
        val readyMap = map ?: return
        val current = readyMap.cameraPosition
        readyMap.animateCamera(
            CameraUpdateFactory.newCameraPosition(
                CameraPosition.Builder()
                    .target(current.target)
                    .zoom(current.zoom)
                    .tilt(current.tilt)
                    .bearing(0.0)
                    .build()
            )
        )
    }

    private fun shortName(name: String): String = name.substringBefore(',').take(42)

    private fun secondaryName(name: String): String {
        val parts = name.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        return parts.drop(1).take(2).joinToString(", ").ifBlank { "Найденное место" }
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(searchInput.windowToken, 0)
        searchInput.clearFocus()
    }

    private fun glassPanelBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(
            Color.argb(236, 69, 95, 119),
            Color.argb(230, 55, 78, 100),
            Color.argb(226, 76, 102, 126)
        )
    ).apply {
        cornerRadius = dp(28).toFloat()
        setStroke(dp(1), Color.argb(105, 235, 245, 253))
    }

    private fun searchFieldBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(
            Color.argb(238, 243, 248, 252),
            Color.argb(224, 216, 230, 241)
        )
    ).apply {
        cornerRadius = dp(20).toFloat()
        setStroke(dp(1), Color.argb(150, 255, 255, 255))
    }

    private fun roundGlassButtonBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(
            Color.argb(235, 91, 119, 145),
            Color.argb(228, 55, 77, 98)
        )
    ).apply {
        shape = GradientDrawable.OVAL
        setStroke(dp(1), Color.argb(125, 235, 245, 253))
    }

    private fun locateButtonBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(
            Color.argb(246, 247, 251, 254),
            Color.argb(238, 221, 234, 244)
        )
    ).apply {
        shape = GradientDrawable.OVAL
        setStroke(dp(1), Color.argb(185, 255, 255, 255))
    }

    private fun primaryButtonBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(
            Color.rgb(64, 112, 154),
            Color.rgb(72, 129, 176),
            Color.rgb(82, 143, 190)
        )
    ).apply {
        cornerRadius = dp(24).toFloat()
        setStroke(dp(1), Color.argb(175, 220, 239, 252))
    }

    private fun lightGlassCardBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(
            Color.argb(245, 247, 250, 253),
            Color.argb(236, 226, 237, 246)
        )
    ).apply {
        cornerRadius = dp(24).toFloat()
        setStroke(dp(1), Color.argb(180, 255, 255, 255))
    }

    private fun destinationBadgeBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(80, 146, 202), Color.rgb(53, 108, 158))
    ).apply {
        shape = GradientDrawable.OVAL
        setStroke(dp(1), Color.argb(170, 255, 255, 255))
    }

    private fun searchBadgeBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(104, 168, 217), Color.rgb(66, 126, 180))
    ).apply {
        shape = GradientDrawable.OVAL
    }

    private fun searchRowBackground() = GradientDrawable().apply {
        setColor(Color.TRANSPARENT)
        setStroke(0, Color.TRANSPARENT)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    private fun registerTrackingReceiver() {
        val filter = IntentFilter().apply {
            addAction(TrackingService.ACTION_LOCATION_UPDATE)
            addAction(TrackingService.ACTION_TRACKING_STOPPED)
        }
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_LOCATION && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            if (pendingStartAfterPermission) startWalk() else centerOnLastLocation()
            pendingStartAfterPermission = false
        }
    }

    override fun onStart() {
        super.onStart()
        mapView.onStart()
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
        tracking = database.activeWalk() != null
        updateUiState()
        refreshClouds()
    }

    override fun onPause() {
        mapView.onPause()
        super.onPause()
    }

    override fun onStop() {
        mapView.onStop()
        super.onStop()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView.onLowMemory()
    }

    override fun onDestroy() {
        unregisterReceiver(receiver)
        mapView.onDestroy()
        database.close()
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        mapView.onSaveInstanceState(outState)
    }

    companion object {
        private const val REQUEST_LOCATION = 7001
        private const val MENU_MAP_NORMAL = 7101
        private const val MENU_MAP_LIGHT = 7102
        private const val MENU_BACKUP_EXPORT = 7103
        private const val MENU_BACKUP_IMPORT = 7104
        private val MAP_STYLES = listOf(
            "Обычная" to "https://tiles.openfreemap.org/styles/liberty",
            "Светлая" to "https://tiles.openfreemap.org/styles/bright"
        )
    }
}
