package com.lifeinmist.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.IBinder
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

class TrackingService : Service() {
    private lateinit var fusedLocation: FusedLocationProviderClient
    private lateinit var database: MistDatabase
    private var walkId: Long = -1L

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val location = result.lastLocation ?: return
            if (location.accuracy > 80f) return
            if (walkId <= 0) return

            val distance = database.appendLocation(walkId, location)
            sendBroadcast(
                Intent(ACTION_LOCATION_UPDATE)
                    .setPackage(packageName)
                    .putExtra(EXTRA_LAT, location.latitude)
                    .putExtra(EXTRA_LON, location.longitude)
                    .putExtra(EXTRA_ACCURACY, location.accuracy)
                    .putExtra(EXTRA_DISTANCE, distance)
            )
        }
    }

    override fun onCreate() {
        super.onCreate()
        fusedLocation = LocationServices.getFusedLocationProviderClient(this)
        database = MistDatabase(this)
        ensureNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopTracking()
            else -> startTracking()
        }
        return START_STICKY
    }

    private fun startTracking() {
        walkId = database.activeWalk()?.id ?: database.startWalk()
        startForeground(NOTIFICATION_ID, buildNotification())

        val fine = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (fine != PackageManager.PERMISSION_GRANTED && coarse != PackageManager.PERMISSION_GRANTED) {
            stopTracking()
            return
        }

        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 3_000L)
            .setMinUpdateIntervalMillis(1_500L)
            .setMinUpdateDistanceMeters(3f)
            .build()
        fusedLocation.requestLocationUpdates(request, callback, mainLooper)
    }

    private fun stopTracking() {
        fusedLocation.removeLocationUpdates(callback)
        if (walkId <= 0) walkId = database.activeWalk()?.id ?: -1L
        if (walkId > 0) database.finishWalk(walkId)
        sendBroadcast(Intent(ACTION_TRACKING_STOPPED).setPackage(packageName))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification() = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_menu_mylocation)
        .setContentTitle("Walk Travel Timege")
        .setContentText("Прогулка записывается — карта открывается по маршруту")
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setContentIntent(
            PendingIntent.getActivity(
                this,
                0,
                Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        )
        .build()

    private fun ensureNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "Активная прогулка",
                NotificationManager.IMPORTANCE_LOW
            )
        )
    }

    override fun onDestroy() {
        fusedLocation.removeLocationUpdates(callback)
        database.close()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.lifeinmist.app.START_TRACKING"
        const val ACTION_STOP = "com.lifeinmist.app.STOP_TRACKING"
        const val ACTION_LOCATION_UPDATE = "com.lifeinmist.app.LOCATION_UPDATE"
        const val ACTION_TRACKING_STOPPED = "com.lifeinmist.app.TRACKING_STOPPED"
        const val EXTRA_LAT = "lat"
        const val EXTRA_LON = "lon"
        const val EXTRA_ACCURACY = "accuracy"
        const val EXTRA_DISTANCE = "distance"
        private const val CHANNEL_ID = "walking"
        private const val NOTIFICATION_ID = 1101
    }
}
