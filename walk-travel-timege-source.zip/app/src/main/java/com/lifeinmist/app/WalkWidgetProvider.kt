package com.lifeinmist.app

import android.Manifest
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.view.View
import android.widget.RemoteViews
import androidx.core.content.ContextCompat
import java.util.Calendar

/** Home-screen companion: today's distance, discoveries in the last seven days, and one-tap tracking. */
class WalkWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        update(context, manager, appWidgetIds)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TOGGLE_WALK) {
            toggleWalk(context)
            updateAll(context)
        }
    }

    private fun toggleWalk(context: Context) {
        val database = MistDatabase(context)
        val active = try { database.activeWalk() != null } finally { database.close() }
        if (active) {
            context.startService(Intent(context, TrackingService::class.java).setAction(TrackingService.ACTION_STOP))
            return
        }

        val locationGranted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val notificationsGranted = Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(
            context, Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED

        if (!locationGranted || !notificationsGranted) {
            openAppForStart(context)
            return
        }

        try {
            ContextCompat.startForegroundService(
                context,
                Intent(context, TrackingService::class.java).setAction(TrackingService.ACTION_START)
            )
        } catch (_: RuntimeException) {
            // A launcher/OEM may impose stricter background-start rules. Keep the button useful.
            openAppForStart(context)
        }
    }

    private fun openAppForStart(context: Context) {
        context.startActivity(Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(MainActivity.EXTRA_WIDGET_START, true)
        })
    }

    companion object {
        private const val ACTION_TOGGLE_WALK = "com.lifeinmist.app.WIDGET_TOGGLE_WALK"
        private const val OPEN_REQUEST = 3201
        private const val TOGGLE_REQUEST = 3202

        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, WalkWidgetProvider::class.java))
            update(context, manager, ids)
        }

        private fun update(context: Context, manager: AppWidgetManager, ids: IntArray) {
            if (ids.isEmpty()) return
            AppLanguage.initialize(context)
            val now = System.currentTimeMillis()
            val startToday = Calendar.getInstance().apply {
                timeInMillis = now
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val startSevenDays = Calendar.getInstance().apply {
                timeInMillis = startToday
                add(Calendar.DAY_OF_YEAR, -6)
            }.timeInMillis

            val database = MistDatabase(context)
            val todayMeters: Double
            val tracking: Boolean
            try {
                todayMeters = database.distanceForWalksStartedBetween(startToday, now)
                tracking = database.activeWalk() != null
            } finally {
                database.close()
            }
            val discoveries = if (MainActivity.PLACES_UI_ENABLED) {
                DiscoveryStore.get(context).openedBetween(startSevenDays, now).size
            } else 0

            ids.forEach { id ->
                val views = RemoteViews(context.packageName, R.layout.widget_walk).apply {
                    setTextViewText(R.id.widget_today_value, formatDistance(todayMeters))
                    setTextViewText(R.id.widget_today_label, tr("Today", "Сегодня"))
                    setViewVisibility(R.id.widget_week_group, if (MainActivity.PLACES_UI_ENABLED) View.VISIBLE else View.GONE)
                    setTextViewText(R.id.widget_week_value, discoveries.toString())
                    setTextViewText(R.id.widget_week_label, tr("Opened · 7 days", "Открыто · 7 дней"))
                    setTextViewText(R.id.widget_action, if (tracking) tr("Finish", "Завершить") else tr("Start walk", "Начать"))
                    setTextViewText(R.id.widget_status, if (tracking) tr("Walk recording", "Прогулка записывается") else tr("Walk Travel Timege", "Walk Travel Timege"))

                    val openIntent = PendingIntent.getActivity(
                        context,
                        OPEN_REQUEST,
                        Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    )
                    setOnClickPendingIntent(R.id.widget_root, openIntent)

                    val toggleIntent = PendingIntent.getBroadcast(
                        context,
                        TOGGLE_REQUEST,
                        Intent(context, WalkWidgetProvider::class.java).setAction(ACTION_TOGGLE_WALK),
                        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    )
                    setOnClickPendingIntent(R.id.widget_action, toggleIntent)
                }
                manager.updateAppWidget(id, views)
            }
        }

        private fun formatDistance(meters: Double): String = if (meters < 1000.0) {
            tr("${meters.toInt()} m", "${meters.toInt()} м")
        } else {
            String.format(AppLanguage.locale, tr("%.1f km", "%.1f км"), meters / 1000.0)
        }
    }
}
