package com.lifeinmist.app

import android.content.Context
import android.location.Location
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class DiscoveryPlace(
    val id: String, val name: String, val lat: Double, val lon: Double,
    val category: String, val hint: String, val description: String,
    val region: String, val radius: Double, val article: String, val photo: String
) {
    fun json(): JSONObject = JSONObject().put("id", id).put("name", name)
        .put("lat", lat).put("lon", lon).put("category", category).put("hint", hint)
        .put("description", description).put("region", region).put("radius_m", radius)
        .put("article_url", article).put("photo_url", photo)

    fun distance(lat: Double, lon: Double): Float {
        val result = FloatArray(1)
        Location.distanceBetween(lat, lon, this.lat, this.lon, result)
        return result[0]
    }
}

/** Shared by the activity and tracking service. No location is sent to the server. */
class DiscoveryStore private constructor(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("discoveries", Context.MODE_PRIVATE)
    private var catalog = parseCatalog(prefs.getString("catalog", null) ?: "{\"version\":1,\"places\":[]}")
    private var found = JSONObject(prefs.getString("found", "{}") ?: "{}")

    @Synchronized fun places(): List<DiscoveryPlace> = catalog.toList()
    @Synchronized fun openedAt(id: String): Long = found.optLong(id, 0)

    @Synchronized fun install(raw: String): Int {
        val incoming = parseCatalog(raw)
        // Keep discovered cards even if a publisher later removes them from the feed.
        val ids = incoming.map { it.id }.toSet()
        catalog = incoming + catalog.filter { openedAt(it.id) > 0 && it.id !in ids }
        persist()
        return incoming.size
    }

    @Synchronized fun discover(location: Location): List<DiscoveryPlace> {
        if (!location.hasAccuracy() || !location.hasSpeed() || location.isFromMockProvider) return emptyList()
        val age = (SystemClock.elapsedRealtimeNanos() - location.elapsedRealtimeNanos) / 1e9
        val unlocked = catalog.filter {
            openedAt(it.id) == 0L && DiscoveryRules.canDiscover(
                it.distance(location.latitude, location.longitude).toDouble(), it.radius,
                location.accuracy.toDouble(), age, location.speed.toDouble())
        }
        if (unlocked.isNotEmpty()) {
            unlocked.forEach { found.put(it.id, System.currentTimeMillis()) }
            persist()
        }
        return unlocked
    }

    @Synchronized fun backup(): JSONObject = JSONObject().put("catalog", catalogJson())
        .put("found", JSONObject(found.toString()))

    fun validateBackup(data: JSONObject) {
        parseCatalog(data.getJSONObject("catalog").toString())
        val values = data.getJSONObject("found")
        values.keys().forEach { require(values.getLong(it) > 0) }
    }

    @Synchronized fun restore(data: JSONObject) {
        validateBackup(data)
        val saved = parseCatalog(data.getJSONObject("catalog").toString())
        val existing = catalog.map { it.id }.toSet()
        catalog = catalog + saved.filter { it.id !in existing }
        val values = data.getJSONObject("found")
        values.keys().forEach { id ->
            val date = values.getLong(id)
            val old = openedAt(id)
            found.put(id, if (old > 0) minOf(old, date) else date)
        }
        persist()
    }

    private fun catalogJson(): JSONObject = JSONObject().put("version", 1)
        .put("places", JSONArray().also { array -> catalog.forEach { array.put(it.json()) } })

    private fun persist() {
        prefs.edit().putString("catalog", catalogJson().toString())
            .putString("found", found.toString()).apply()
    }

    companion object {
        // Contract for the forthcoming WordPress plugin; not assumed to be live yet.
        const val FEED_URL = "https://normalthai.ru/wp-json/wtt/v1/places"
        @Volatile private var instance: DiscoveryStore? = null
        fun get(context: Context): DiscoveryStore = instance ?: synchronized(this) {
            instance ?: DiscoveryStore(context).also { instance = it }
        }

        fun parseCatalog(raw: String): List<DiscoveryPlace> {
            require(raw.length <= 2_000_000) { "The place collection is too large" }
            val root = JSONObject(raw)
            require(root.getInt("version") == 1) { "Unsupported place collection format" }
            val array = root.getJSONArray("places")
            require(array.length() <= 2000) { "Too many places" }
            val ids = HashSet<String>()
            return (0 until array.length()).map { index ->
                val p = array.getJSONObject(index)
                val id = p.getString("id")
                val name = p.getString("name").trim()
                val lat = p.getDouble("lat")
                val lon = p.getDouble("lon")
                val radius = p.optDouble("radius_m", 100.0)
                require(id.matches(Regex("[A-Za-z0-9_-]{1,80}")) && ids.add(id)) { "Invalid or duplicate place ID" }
                require(name.isNotEmpty() && name.length <= 200)
                require(lat.isFinite() && lat in -85.0..85.0 && lon.isFinite() && lon in -180.0..180.0)
                require(radius.isFinite() && radius in 25.0..500.0)
                fun field(key: String, fallback: String = ""): String = p.optString(key, fallback).also {
                    require(it.length <= 10000)
                }
                val article = field("article_url")
                val photo = field("photo_url")
                require(listOf(article, photo).all { it.isEmpty() || allowedUrl(it) })
                DiscoveryPlace(id, name, lat, lon, field("category", "Place to discover"),
                    field("hint", "Walk here to discover what's waiting"), field("description"),
                    field("region", "Places"), radius, article, photo)
            }
        }

        fun allowedUrl(value: String): Boolean = try {
            val url = URL(value)
            url.protocol == "https" && url.host in setOf("normalthai.ru", "www.normalthai.ru") &&
                url.userInfo == null && url.port in listOf(-1, 443)
        } catch (_: Exception) { false }

        fun download(value: String, limit: Int): ByteArray {
            require(allowedUrl(value))
            val connection = URL(value).openConnection() as HttpURLConnection
            try {
                connection.connectTimeout = 10000
                connection.readTimeout = 15000
                connection.instanceFollowRedirects = false
                require(connection.responseCode == 200) { "The place collection is currently unavailable" }
                return connection.inputStream.use {
                    val bytes = it.readBytesLimited(limit)
                    bytes
                }
            } finally { connection.disconnect() }
        }
    }
}

internal fun java.io.InputStream.readBytesLimited(limit: Int): ByteArray {
    val output = java.io.ByteArrayOutputStream()
    val buffer = ByteArray(8192)
    while (true) {
        val count = read(buffer)
        if (count < 0) break
        require(output.size() + count <= limit) { "The file is too large" }
        output.write(buffer, 0, count)
    }
    return output.toByteArray()
}
