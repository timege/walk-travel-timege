package com.lifeinmist.app

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.maplibre.android.geometry.LatLng
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class DiscoveryUi(
    private val activity: AppCompatActivity,
    private val location: () -> LatLng?,
    private val chooseGoal: (DiscoveryPlace, String) -> Unit,
    private val showOnMap: (DiscoveryPlace) -> Unit,
    private val refresh: () -> Unit,
    private val importFile: () -> Unit
) {
    private val store = DiscoveryStore.get(activity)
    private var updating = false
    private val prefs = activity.getSharedPreferences("discovery_sync", 0)

    fun sync(manual: Boolean = false) {
        if (updating) return
        if (!manual && System.currentTimeMillis() - prefs.getLong("attempt", 0) < 6 * 60 * 60 * 1000) return
        updating = true
        prefs.edit().putLong("attempt", System.currentTimeMillis()).apply()
        thread(name = "places-sync") {
            val result = runCatching {
                store.install(String(DiscoveryStore.download(DiscoveryStore.FEED_URL, 2_000_000), Charsets.UTF_8))
            }
            activity.runOnUiThread {
                updating = false
                if (!alive()) return@runOnUiThread
                refresh()
                if (manual) Toast.makeText(activity,
                    result.fold({ "Подборка обновлена: $it мест" }, {
                        "Не удалось обновить места. Сохранённая подборка доступна; подключение сайта может быть ещё не настроено."
                    }), Toast.LENGTH_LONG).show()
            }
        }
    }

    fun showCollection(onlyOpened: Boolean = false) {
        val places = store.places()
        val content = column()
        val scroll = ScrollView(activity).apply { addView(content) }
        val dialog = AlertDialog.Builder(activity).setTitle(if (onlyOpened) "Мои открытия" else "Интересные места")
            .setView(scroll).setNegativeButton("Закрыть", null).create()
        val opened = places.count { store.openedAt(it.id) > 0 }
        text(content, "Открыто $opened из ${places.size}")
        if (places.isEmpty()) text(content, "Мест пока нет. Подборки появятся после подключения путеводителя. Можно загрузить подборку из файла.")
        if (onlyOpened && opened == 0 && places.isNotEmpty()) text(content, "Начните прогулку и подойдите к загадочной точке — она появится здесь.")
        if (!onlyOpened) button(content, "Мои открытия") { dialog.dismiss(); showCollection(true) }
        val visible = places.filter { !onlyOpened || store.openedAt(it.id) > 0 }
        for ((region, group) in visible.groupBy { it.region }) {
            val allRegion = places.filter { it.region == region }
            text(content, "$region · ${allRegion.count { store.openedAt(it.id) > 0 }} из ${allRegion.size}")
            group.sortedBy { place -> location()?.let { place.distance(it.latitude, it.longitude) } ?: Float.MAX_VALUE }
                .forEach { place ->
                    val title = if (store.openedAt(place.id) > 0) "✓ ${place.name}" else "? ${place.category}"
                    button(content, title) { dialog.dismiss(); showCard(place) }
                }
        }
        button(content, "Обновить с сайта") { dialog.dismiss(); sync(true) }
        button(content, "Загрузить подборку из файла") { dialog.dismiss(); importFile() }
        dialog.show()
    }

    fun showCard(place: DiscoveryPlace) {
        val date = store.openedAt(place.id)
        val unlocked = date > 0
        val content = column()
        val dialog = AlertDialog.Builder(activity)
            .setTitle(if (unlocked) place.name else "Неизвестное место")
            .setView(ScrollView(activity).apply { addView(content) })
            .setNegativeButton("Закрыть", null).create()
        text(content, "${place.category} · ${place.region}")
        location()?.let {
            val distance = place.distance(it.latitude, it.longitude)
            val label = if (distance >= 1000) String.format(Locale.getDefault(), "%.1f км", distance / 1000) else "${distance.toInt()} м"
            text(content, "$label по прямой")
        }
        if (unlocked) {
            text(content, "Открыто ${SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(date))}")
            text(content, place.description)
            if (place.photo.isNotEmpty()) {
                val photo = ImageView(activity).apply {
                    adjustViewBounds = true
                    contentDescription = place.name
                    maxHeight = dp(230)
                }
                content.addView(photo, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                val photoStatus = text(content, "Загрузка фото…")
                thread(name = "place-photo") {
                    val bitmap = runCatching {
                        val bytes = DiscoveryStore.download(place.photo, 4_000_000)
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                        require(bounds.outWidth > 0 && bounds.outHeight > 0)
                        val opts = BitmapFactory.Options()
                        while (maxOf(bounds.outWidth, bounds.outHeight) / opts.inSampleSize.coerceAtLeast(1) > 1200) {
                            opts.inSampleSize = opts.inSampleSize.coerceAtLeast(1) * 2
                        }
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                    }.getOrNull()
                    activity.runOnUiThread {
                        if (alive() && dialog.isShowing) {
                            photo.setImageBitmap(bitmap)
                            photoStatus.text = if (bitmap == null) "Фото недоступно без подключения" else ""
                        }
                    }
                }
            }
            if (place.article.isNotEmpty()) button(content, "Подробнее на normalthai.ru") {
                runCatching { activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(place.article))) }
                    .onFailure { Toast.makeText(activity, "Не удалось открыть браузер", Toast.LENGTH_SHORT).show() }
            }
        } else {
            text(content, place.hint)
            text(content, "Начните запись прогулки и подойдите ближе ${place.radius.toInt()} м. Для открытия нужен точный GPS; при слабом сигнале подойдите ближе или дождитесь уточнения позиции.")
        }
        button(content, "Показать на карте") { dialog.dismiss(); showOnMap(place) }
        button(content, "Выбрать целью прогулки") {
            dialog.dismiss()
            chooseGoal(place, if (unlocked) place.name else place.category)
        }
        dialog.show()
    }

    private fun alive() = !activity.isFinishing && !activity.isDestroyed
    private fun dp(n: Int) = (n * activity.resources.displayMetrics.density).toInt()
    private fun column() = LinearLayout(activity).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(12))
    }
    private fun text(parent: LinearLayout, value: String): TextView = TextView(activity).apply {
        text = value; textSize = 16f; setPadding(0, dp(8), 0, dp(8)); parent.addView(this)
    }
    private fun button(parent: LinearLayout, title: String, action: () -> Unit) {
        parent.addView(Button(activity).apply { text = title; isAllCaps = false; setOnClickListener { action() } })
    }
}
