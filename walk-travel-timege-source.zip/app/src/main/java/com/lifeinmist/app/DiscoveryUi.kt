package com.lifeinmist.app

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.maplibre.android.geometry.LatLng
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class DiscoveryUi(
    private val activity: AppCompatActivity,
    private val location: () -> LatLng?,
    private val chooseGoal: (DiscoveryPlace, String) -> Unit,
    private val showOnMap: (DiscoveryPlace) -> Unit,
    private val refresh: () -> Unit,
    private val importFile: () -> Unit
) {
    private val store = DiscoveryStore.get(activity)
    private var updating = false
    private val prefs = activity.getSharedPreferences("discovery_sync", 0)

    fun sync(manual: Boolean = false) {
        if (!MainActivity.PLACES_UI_ENABLED) return
        if (updating) return
        if (!manual && System.currentTimeMillis() - prefs.getLong("attempt", 0) < 6 * 60 * 60 * 1000) return
        updating = true
        prefs.edit().putLong("attempt", System.currentTimeMillis()).apply()
        thread(name = "places-sync") {
            val result = runCatching {
                store.install(String(DiscoveryStore.download(DiscoveryStore.FEED_URL, 2_000_000), Charsets.UTF_8))
            }
            activity.runOnUiThread {
                updating = false
                if (!alive()) return@runOnUiThread
                refresh()
                if (manual) Toast.makeText(activity,
                    result.fold({ tr("Places updated: $it", "Подборка обновлена: $it мест") }, {
                        tr("Could not update places. Your saved collection is still available.", "Не удалось обновить места. Сохранённая подборка доступна.")
                    }), Toast.LENGTH_LONG).show()
            }
        }
    }

    fun showCollection(onlyOpened: Boolean = false) {
        if (!MainActivity.PLACES_UI_ENABLED) return
        val places = store.places()
        val content = column()
        val scroll = ScrollView(activity).apply { addView(content) }
        val dialog = AlertDialog.Builder(activity)
            .setCustomTitle(titleView(if (onlyOpened) tr("My discoveries", "Мои открытия") else tr("Discover places", "Интересные места")))
            .setView(scroll).setNegativeButton(tr("Close", "Закрыть"), null).create()
        val opened = places.count { store.openedAt(it.id) > 0 }
        progressChip(content, opened, places.size)
        if (places.isEmpty()) text(content, tr("No places yet. Refresh the collection or import a places file.", "Мест пока нет. Обновите подборку или загрузите её из файла."))
        if (onlyOpened && opened == 0 && places.isNotEmpty()) text(content, tr("Start a walk and visit a mystery spot. Your discoveries will appear here.", "Начните прогулку и подойдите к загадочной точке — ваши открытия появятся здесь."))
        if (!onlyOpened) secondaryButton(content, tr("My discoveries", "Мои открытия")) { dialog.dismiss(); showCollection(true) }
        val visible = places.filter { !onlyOpened || store.openedAt(it.id) > 0 }
        for ((region, group) in visible.groupBy { it.region }) {
            val allRegion = places.filter { it.region == region }
            sectionHeader(content, tr("$region · ${allRegion.count { store.openedAt(it.id) > 0 }} of ${allRegion.size}", "$region · ${allRegion.count { store.openedAt(it.id) > 0 }} из ${allRegion.size}"))
            group.sortedBy { place -> location()?.let { place.distance(it.latitude, it.longitude) } ?: Float.MAX_VALUE }
                .forEach { place ->
                    val unlockedHere = store.openedAt(place.id) > 0
                    val title = if (unlockedHere) "✓  ${place.name}" else place.name
                    placeRowButton(content, title, unlockedHere) { dialog.dismiss(); showCard(place) }
                }
        }
        actionButton(content, tr("Refresh places", "Обновить места")) { dialog.dismiss(); sync(true) }
        actionButton(content, tr("Import places", "Загрузить подборку")) { dialog.dismiss(); importFile() }
        if (places.isNotEmpty()) {
    actionButton(content, tr("Remove all places", "Удалить все интересные места")) {
        dialog.dismiss()
        confirmClearAll()
    }
}
        dialog.show()
        roundCard(dialog)
        tintNegativeButton(dialog)
    }

    private fun confirmClearAll() {
    val dialog = AlertDialog.Builder(activity)
        .setCustomTitle(titleView(tr("Remove all places?", "Удалить все интересные места?")))
        .setMessage(tr(
            "This removes all imported places and their discovery history. Walks, explored map data and GPX routes will not be affected.",
            "Будут удалены все интересные места и история их открытий. Прогулки, открытая карта и GPX-маршруты останутся без изменений."
        ))
        .setNegativeButton(tr("Cancel", "Отмена"), null)
        .setPositiveButton(tr("Remove", "Удалить")) { _, _ ->
            store.clearAllPlaces()
            refresh()
            Toast.makeText(activity, tr("All places removed", "Все интересные места удалены"), Toast.LENGTH_SHORT).show()
        }
        .create()
    dialog.show()
    roundCard(dialog)
    tintNegativeButton(dialog)
}

    fun showCard(place: DiscoveryPlace) {
        if (!MainActivity.PLACES_UI_ENABLED) return
        val date = store.openedAt(place.id)
        val unlocked = date > 0
        val content = column()
        val dialog = AlertDialog.Builder(activity)
            .setCustomTitle(titleView(place.name))
            .setView(ScrollView(activity).apply { addView(content) })
            .setNegativeButton(tr("Close", "Закрыть"), null).create()
        metaText(content, "${place.category} · ${place.region}")
        location()?.let {
            val distance = place.distance(it.latitude, it.longitude)
            val label = if (distance >= 1000) String.format(AppLanguage.locale, tr("%.1f km", "%.1f км"), distance / 1000) else tr("${distance.toInt()} m", "${distance.toInt()} м")
            metaText(content, tr("$label away · straight-line distance", "$label по прямой"))
        }
        if (unlocked) {
            metaText(content, tr("Discovered ${SimpleDateFormat("d MMM yyyy", AppLanguage.locale).format(Date(date))}", "Открыто ${SimpleDateFormat("d MMM yyyy", AppLanguage.locale).format(Date(date))}"))
            text(content, place.description)
            if (place.photo.isNotEmpty()) {
                val photo = ImageView(activity).apply {
                    adjustViewBounds = true
                    contentDescription = place.name
                    maxHeight = dp(230)
                    clipToOutline = true
                    outlineProvider = object : ViewOutlineProvider() {
                        override fun getOutline(view: View, outline: Outline) {
                            outline.setRoundRect(0, 0, view.width, view.height, dp(14).toFloat())
                        }
                    }
                }
                content.addView(photo, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = dp(4); bottomMargin = dp(8)
                })
                val photoStatus = metaText(content, tr("Loading photo…", "Загрузка фото…"))
                thread(name = "place-photo") {
                    val bitmap = runCatching {
                        val bytes = DiscoveryStore.download(place.photo, 4_000_000)
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                        require(bounds.outWidth > 0 && bounds.outHeight > 0)
                        val opts = BitmapFactory.Options()
                        while (maxOf(bounds.outWidth, bounds.outHeight) / opts.inSampleSize.coerceAtLeast(1) > 1200) {
                            opts.inSampleSize = opts.inSampleSize.coerceAtLeast(1) * 2
                        }
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                    }.getOrNull()
                    activity.runOnUiThread {
                        if (alive() && dialog.isShowing) {
                            photo.setImageBitmap(bitmap)
                            photoStatus.text = if (bitmap == null) tr("Photo unavailable. Check your connection.", "Фото недоступно. Проверьте подключение.") else ""
                        }
                    }
                }
            }
            if (place.article.isNotEmpty()) secondaryButton(content, tr("Read more on normalthai.ru", "Подробнее на normalthai.ru")) {
                runCatching { activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(place.article))) }
                    .onFailure { Toast.makeText(activity, tr("Could not open the browser", "Не удалось открыть браузер"), Toast.LENGTH_SHORT).show() }
            }
        } else {
            text(content, place.hint)
            metaText(content, tr("Start recording a walk and get within ${place.radius.toInt()} m. A precise GPS fix is needed to unlock this place. If the signal is weak, move closer or wait for it to improve.", "Начните запись прогулки и подойдите ближе ${place.radius.toInt()} м. Для открытия нужен точный GPS. При слабом сигнале подойдите ближе или дождитесь уточнения позиции."))
        }
        secondaryButton(content, tr("Show on map", "Показать на карте")) { dialog.dismiss(); showOnMap(place) }
        primaryButton(content, tr("Walk here", "Выбрать целью прогулки")) {
            dialog.dismiss()
            chooseGoal(place, place.name)
        }
        dialog.show()
        roundCard(dialog)
        tintNegativeButton(dialog)
    }

    // --- Shared "skeuomorphic" styling, matching the palette used for the map toolbar/buttons. ---

    private object Palette {
        val darkGreenText = Color.rgb(20, 94, 35)
        val midGreenText = Color.rgb(27, 92, 40)
        val softGreenText = Color.rgb(73, 105, 77)
        val panelBackground = Color.rgb(246, 250, 241)
    }

    private fun roundCard(dialog: AlertDialog) {
        val window = dialog.window ?: return
        val decor = window.decorView
        val insets = Rect()
        decor.background?.getPadding(insets)
        val radius = dp(24).toFloat()
        val background = GradientDrawable().apply {
            setColor(Palette.panelBackground)
            cornerRadius = radius
        }
        window.setBackgroundDrawable(InsetDrawable(background, insets.left, insets.top, insets.right, insets.bottom))
        decor.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(insets.left, insets.top,
                    view.width - insets.right, view.height - insets.bottom, radius)
            }
        }
        decor.clipToOutline = true
    }

    private fun tintNegativeButton(dialog: AlertDialog) {
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.apply {
            setTextColor(Palette.darkGreenText)
            typeface = AppTypography.emphasis
        }
    }

    private fun titleView(title: String): View = TextView(activity).apply {
        text = title
        textSize = 20f
        typeface = AppTypography.emphasis
        setTextColor(Palette.darkGreenText)
        setPadding(dp(20), dp(18), dp(20), dp(4))
    }

    /** Small lime-edged pill showing "opened X of Y", instead of a plain line of text. */
    private fun progressChip(parent: LinearLayout, opened: Int, total: Int) {
        val chip = TextView(activity).apply {
            text = tr("Discovered $opened of $total", "Открыто $opened из $total")
            textSize = 14f
            typeface = AppTypography.emphasis
            setTextColor(Palette.midGreenText)
            setPadding(dp(14), dp(6), dp(14), dp(6))
            background = layeredRoundRect(
                outerColors = intArrayOf(Color.rgb(198, 214, 191), Color.rgb(119, 151, 111)),
                innerColors = intArrayOf(Color.rgb(255, 255, 250), Color.rgb(224, 240, 210)),
                radiusDp = 14, insetDp = 2, strokeColor = Color.argb(215, 238, 249, 230)
            )
        }
        parent.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(4); bottomMargin = dp(10)
        })
    }

    private fun layeredRoundRect(
        outerColors: IntArray,
        innerColors: IntArray,
        radiusDp: Int,
        insetDp: Int,
        strokeColor: Int
    ): Drawable {
        val outer = GradientDrawable(GradientDrawable.Orientation.TL_BR, outerColors).apply {
            cornerRadius = dp(radiusDp).toFloat()
            setStroke(dp(1), strokeColor)
        }
        val inner = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, innerColors).apply {
            cornerRadius = dp((radiusDp - insetDp).coerceAtLeast(1)).toFloat()
            setStroke(dp(1), Color.argb(120, 255, 255, 255))
        }
        return LayerDrawable(arrayOf(outer, inner)).apply {
            setLayerInset(1, dp(insetDp), dp(insetDp), dp(insetDp), dp(insetDp))
        }
    }

    private fun withRipple(base: Drawable): Drawable =
        RippleDrawable(ColorStateList.valueOf(Color.argb(70, 255, 255, 255)), base, ColorDrawable(Color.WHITE))

    private fun placeRowBackground(unlocked: Boolean): Drawable = layeredRoundRect(
        outerColors = if (unlocked) intArrayOf(Color.rgb(101, 194, 38), Color.rgb(35, 113, 40))
        else intArrayOf(Color.rgb(174, 203, 163), Color.rgb(119, 151, 111)),
        innerColors = if (unlocked) intArrayOf(Color.rgb(233, 250, 214), Color.rgb(206, 232, 188))
        else intArrayOf(Color.rgb(255, 255, 250), Color.rgb(236, 245, 231)),
        radiusDp = 16, insetDp = 2,
        strokeColor = if (unlocked) Color.argb(230, 195, 244, 108) else Color.argb(180, 225, 240, 215)
    )

    private fun secondaryButtonBackground(): Drawable = layeredRoundRect(
        outerColors = intArrayOf(Color.rgb(174, 203, 163), Color.rgb(110, 151, 104)),
        innerColors = intArrayOf(Color.rgb(255, 255, 250), Color.rgb(236, 245, 231)),
        radiusDp = 20, insetDp = 2,
        strokeColor = Color.argb(210, 235, 250, 226)
    )

    private fun actionButtonBackground(): Drawable = layeredRoundRect(
        outerColors = intArrayOf(Color.rgb(67, 139, 58), Color.rgb(24, 78, 33)),
        innerColors = intArrayOf(Color.rgb(105, 178, 75), Color.rgb(37, 105, 42)),
        radiusDp = 20, insetDp = 2,
        strokeColor = Color.rgb(170, 220, 133)
    )

    private fun primaryButtonBackground(): Drawable = layeredRoundRect(
        outerColors = intArrayOf(Color.rgb(30, 93, 31), Color.rgb(101, 194, 38), Color.rgb(26, 80, 31)),
        innerColors = intArrayOf(Color.rgb(143, 224, 57), Color.rgb(63, 159, 37), Color.rgb(35, 113, 40)),
        radiusDp = 22, insetDp = 3,
        strokeColor = Color.argb(240, 195, 244, 108)
    )

    private fun alive() = !activity.isFinishing && !activity.isDestroyed
    private fun dp(n: Int) = (n * activity.resources.displayMetrics.density).toInt()
    private fun column() = LinearLayout(activity).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(14))
    }

    private fun sectionHeader(parent: LinearLayout, value: String): TextView = TextView(activity).apply {
        text = value; textSize = 13f
        typeface = AppTypography.emphasis
        setTextColor(Palette.midGreenText)
        setPadding(dp(2), dp(14), dp(2), dp(6))
        parent.addView(this)
    }

    private fun text(parent: LinearLayout, value: String): TextView = TextView(activity).apply {
        text = value; textSize = 16f
        setTextColor(Color.rgb(45, 58, 46))
        setPadding(0, dp(6), 0, dp(6)); parent.addView(this)
    }

    private fun metaText(parent: LinearLayout, value: String): TextView = TextView(activity).apply {
        text = value; textSize = 13.5f
        setTextColor(Palette.softGreenText)
        setPadding(0, dp(2), 0, dp(6)); parent.addView(this)
    }

    /** Rows inside the place list: left-aligned card, tinted lime/green once unlocked. */
    private fun placeRowButton(parent: LinearLayout, title: String, unlocked: Boolean, action: () -> Unit) {
        val row = TextView(activity).apply {
            text = title
            textSize = 15.5f
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            setTextColor(if (unlocked) Palette.darkGreenText else Color.rgb(58, 78, 60))
            if (unlocked) typeface = AppTypography.emphasis
            setPadding(dp(16), dp(13), dp(16), dp(13))
            isClickable = true
            isFocusable = true
            background = withRipple(placeRowBackground(unlocked))
            setOnClickListener { action() }
        }
        parent.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(6)
        })
    }

    /** Lighter, cream pill for secondary/utility actions ("show on map", "load from file"...). */
    private fun secondaryButton(parent: LinearLayout, title: String, action: () -> Unit) {
        pillButton(parent, title, secondaryButtonBackground(), Palette.midGreenText, action)
    }

    /** Mid-weight green pill for standalone utility actions at the bottom of a list. */
    private fun actionButton(parent: LinearLayout, title: String, action: () -> Unit) {
        pillButton(parent, title, actionButtonBackground(), Color.rgb(240, 250, 232), action)
    }

    /** The strongest, most saturated pill — the single main call-to-action on a card. */
    private fun primaryButton(parent: LinearLayout, title: String, action: () -> Unit) {
        pillButton(parent, title, primaryButtonBackground(), Color.WHITE, action)
    }

    private fun pillButton(parent: LinearLayout, title: String, background: Drawable, textColor: Int, action: () -> Unit) {
        val button = TextView(activity).apply {
            text = title
            textSize = 15.5f
            gravity = Gravity.CENTER
            typeface = AppTypography.emphasis
            setTextColor(textColor)
            setPadding(dp(18), dp(13), dp(18), dp(13))
            isClickable = true
            isFocusable = true
            this.background = withRipple(background)
            setOnClickListener { action() }
        }
        parent.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(8)
        })
    }
}
