package com.lifeinmist.app

import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap

/** Keep exact track geometry; project through MapLibre once per rebuild, not per frame. */
internal class ProjectedPaths {
    private var segments: List<List<LatLng>> = emptyList()
    private val paths = ArrayList<Path>()
    private val transformed = Path()
    private val matrix = Matrix()
    private var anchor: LatLng? = null
    private var zoom = 0.0
    private var bearing = 0.0
    private var dirty = true

    fun setSegments(value: List<List<LatLng>>) {
        segments = value
        dirty = true
    }

    fun invalidate() { dirty = true }

    fun draw(canvas: Canvas, map: MapLibreMap, outline: Paint, line: Paint) {
        if (segments.isEmpty()) return
        // Rare re-anchor keeps float precision after very large zoom changes.
        if (kotlin.math.abs(map.cameraPosition.zoom - zoom) > 3.0) dirty = true
        if (dirty) {
            val camera = map.cameraPosition
            val target = camera.target ?: return
            val origin = map.projection.toScreenLocation(target)
            paths.clear()
            for (segment in segments) {
                if (segment.size < 2) continue
                val path = Path()
                segment.forEachIndexed { index, point ->
                    val p = map.projection.toScreenLocation(point)
                    if (index == 0) path.moveTo(p.x - origin.x, p.y - origin.y)
                    else path.lineTo(p.x - origin.x, p.y - origin.y)
                }
                paths.add(path)
            }
            anchor = LatLng(target.latitude, target.longitude)
            zoom = camera.zoom
            bearing = camera.bearing
            dirty = false
        }
        val center = map.projection.toScreenLocation(anchor ?: return)
        val camera = map.cameraPosition
        val scale = FogTransform.scale(camera.zoom, zoom).toFloat()
        matrix.setScale(scale, scale)
        matrix.postRotate(FogTransform.rotation(camera.bearing, bearing).toFloat())
        matrix.postTranslate(center.x, center.y)
        for (path in paths) {
            transformed.rewind()
            path.transform(matrix, transformed)
            // Transform geometry, not canvas: line width and glow stay constant in pixels.
            canvas.drawPath(transformed, outline)
            canvas.drawPath(transformed, line)
        }
    }
}
