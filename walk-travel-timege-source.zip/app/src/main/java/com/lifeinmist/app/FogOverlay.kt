package com.lifeinmist.app

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import kotlin.math.abs

/**
 * Permanent cloud layer for unexplored territory.
 * All persisted track points permanently cut a corridor through the clouds.
 */
class FogOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) {
            field = value
            invalidate()
        }

    private var track: List<TrackPoint> = emptyList()
    private var currentLocation: LatLng? = null

    private val veilPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        // Dense pale veil: the underlying map is barely visible until explored.
        color = Color.argb(218, 239, 244, 241)
        style = Paint.Style.FILL
    }

    private val cloudShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(44, 112, 128, 118)
        style = Paint.Style.FILL
        maskFilter = BlurMaskFilter(34f, BlurMaskFilter.Blur.NORMAL)
    }

    private val featherPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        maskFilter = BlurMaskFilter(30f, BlurMaskFilter.Blur.NORMAL)
    }

    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    init {
        isClickable = false
        isFocusable = false
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun setTrackPoints(points: List<TrackPoint>) {
        track = points
        invalidate()
    }

    fun setCurrentLocation(location: LatLng?) {
        currentLocation = location
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        val layer = canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), veilPaint)
        drawCloudField(canvas)

        map?.let { currentMap ->
            if (track.isNotEmpty()) drawExploredRoutes(canvas, currentMap)
            currentLocation?.let { drawTemporaryOpening(canvas, currentMap, it) }
        }

        canvas.restoreToCount(layer)
    }

    private fun drawCloudField(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val base = (w / 5.5f).coerceAtLeast(72f)

        // Dense staggered grid: clouds cover the whole screen rather than isolated patches.
        val rows = 8
        val cols = 5
        for (row in 0..rows) {
            val y = (row.toFloat() / rows.toFloat()) * h
            val offset = if (row % 2 == 0) -0.06f else 0.07f
            for (col in -1..cols) {
                val x = ((col.toFloat() / cols.toFloat()) + offset) * w
                val scale = 0.88f + (((row * 7 + col * 5).let { if (it < 0) -it else it }) % 5) * 0.065f
                drawCloudCluster(canvas, x, y, base * scale, row * 11 + col)
            }
        }
    }

    private fun drawCloudCluster(canvas: Canvas, cx: Float, cy: Float, radius: Float, variant: Int) {
        canvas.drawCircle(cx + radius * 0.08f, cy + radius * 0.25f, radius * 1.2f, cloudShadowPaint)

        val puffs = arrayOf(
            floatArrayOf(0.00f, 0.11f, 1.00f),
            floatArrayOf(-0.68f, 0.18f, 0.76f),
            floatArrayOf(0.66f, 0.15f, 0.80f),
            floatArrayOf(-0.34f, -0.43f, 0.72f),
            floatArrayOf(0.24f, -0.52f, 0.79f),
            floatArrayOf(0.75f, -0.24f, 0.60f),
            floatArrayOf(-0.82f, -0.18f, 0.56f)
        )
        puffs.forEachIndexed { i, puff ->
            drawCloudPuff(
                canvas,
                cx + radius * puff[0],
                cy + radius * puff[1],
                radius * puff[2],
                variant + i
            )
        }
    }

    private fun drawCloudPuff(canvas: Canvas, cx: Float, cy: Float, radius: Float, variant: Int) {
        val center = when (kotlin.math.abs(variant) % 5) {
            0 -> Color.argb(252, 255, 255, 255)
            1 -> Color.argb(248, 247, 250, 249)
            2 -> Color.argb(245, 235, 240, 239)
            3 -> Color.argb(249, 252, 253, 251)
            else -> Color.argb(246, 241, 245, 243)
        }
        val edge = when (kotlin.math.abs(variant) % 4) {
            0 -> Color.argb(150, 196, 208, 202)
            1 -> Color.argb(138, 216, 225, 220)
            2 -> Color.argb(146, 205, 216, 210)
            else -> Color.argb(136, 228, 233, 229)
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                cx - radius * 0.20f,
                cy - radius * 0.23f,
                radius,
                intArrayOf(center, center, edge, Color.TRANSPARENT),
                floatArrayOf(0f, 0.48f, 0.84f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawCircle(cx, cy, radius, paint)
    }

    private fun drawExploredRoutes(canvas: Canvas, currentMap: MapLibreMap) {
        val grouped = track.groupBy { it.walkId }
        for (walkPoints in grouped.values) {
            if (walkPoints.isEmpty()) continue

            val path = Path()
            var started = false
            var representativeRadiusPx = 22f

            for (point in walkPoints) {
                val screen = currentMap.projection.toScreenLocation(LatLng(point.latitude, point.longitude))
                if (!started) {
                    path.moveTo(screen.x, screen.y)
                    representativeRadiusPx = radiusMetersToPixels(
                        currentMap,
                        point.latitude,
                        point.longitude,
                        REVEAL_RADIUS_M
                    )
                    started = true
                } else {
                    path.lineTo(screen.x, screen.y)
                }
            }
            if (!started) continue

            val coreWidth = (representativeRadiusPx * 2f).coerceIn(14f, 1100f)
            featherPaint.strokeWidth = (coreWidth + 54f).coerceAtMost(1160f)
            clearPaint.strokeWidth = coreWidth
            canvas.drawPath(path, featherPaint)
            canvas.drawPath(path, clearPaint)

            if (walkPoints.size == 1) {
                val only = walkPoints.first()
                val center = currentMap.projection.toScreenLocation(LatLng(only.latitude, only.longitude))
                clearCircle(canvas, center.x, center.y, representativeRadiusPx)
            }
        }
    }

    private fun drawTemporaryOpening(canvas: Canvas, currentMap: MapLibreMap, location: LatLng) {
        val center = currentMap.projection.toScreenLocation(location)
        val radius = radiusMetersToPixels(
            currentMap,
            location.latitude,
            location.longitude,
            CURRENT_OPENING_RADIUS_M
        ).coerceAtLeast(30f)
        clearCircle(canvas, center.x, center.y, radius)
    }

    private fun clearCircle(canvas: Canvas, x: Float, y: Float, radius: Float) {
        val soft = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.WHITE
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
            maskFilter = BlurMaskFilter(30f, BlurMaskFilter.Blur.NORMAL)
        }
        val clear = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.WHITE
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
        canvas.drawCircle(x, y, radius + 26f, soft)
        canvas.drawCircle(x, y, radius, clear)
    }

    private fun radiusMetersToPixels(map: MapLibreMap, lat: Double, lon: Double, radiusM: Double): Float {
        val center = map.projection.toScreenLocation(LatLng(lat, lon))
        val latitudeDelta = radiusM / 111_320.0
        val north = map.projection.toScreenLocation(LatLng(lat + latitudeDelta, lon))
        return abs(center.y - north.y).coerceIn(6f, 560f)
    }

    companion object {
        private const val REVEAL_RADIUS_M = 28.0
        private const val CURRENT_OPENING_RADIUS_M = 42.0
    }
}
