package com.lifeinmist.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sin

/**
 * Permanent explored-world cloud mask.
 *
 * v0.6.1 changes the clouds from a screen-fixed texture to geo-anchored cloud layers.
 * That means the cloud masses now pan together with the map and scale up/down when the
 * user zooms, which makes them feel like part of the world instead of a static overlay.
 */
class FogOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) {
            field = value
            invalidate()
        }

    private var track: List<TrackPoint> = emptyList()
    private var currentLocation: LatLng? = null
    private val animationStartMs = SystemClock.uptimeMillis()

    private data class CloudLayerSpec(
        val stepX: Double,
        val stepY: Double,
        val sizeWorld: Double,
        val offsetX: Double,
        val offsetY: Double,
        val alpha: Int,
        val driftX: Double,
        val driftY: Double,
        val rotationRange: Float,
        val minZoom: Double
    )

    // Five geographic scales. At street zoom all five are visible; at distant zooms the
    // smallest layers are culled for performance while the large cloud banks remain.
    private val layerSpecs = listOf(
        CloudLayerSpec(0.00105, 0.00076, 0.00135, 0.00031, 0.00017, 92, 0.000020, 0.000010, 12f, 0.0),
        CloudLayerSpec(0.00052, 0.00039, 0.00068, 0.00013, 0.00009, 118, 0.000014, 0.000010, 16f, 8.0),
        CloudLayerSpec(0.00024, 0.00019, 0.00032, 0.00007, 0.00004, 146, 0.000010, 0.000008, 18f, 10.0),
        CloudLayerSpec(0.000095, 0.000078, 0.00013, 0.00003, 0.00002, 176, 0.000007, 0.000006, 22f, 12.0),
        CloudLayerSpec(0.000014, 0.000012, 0.000018, 0.000005, 0.000004, 208, 0.0000025, 0.0000020, 24f, 14.0)
    )

    private val cloudSprites: List<Bitmap> by lazy {
        listOf(
            R.drawable.cloud_sprite_1,
            R.drawable.cloud_sprite_2,
            R.drawable.cloud_sprite_3,
            R.drawable.cloud_sprite_4,
            R.drawable.cloud_sprite_5,
            R.drawable.cloud_sprite_6,
            R.drawable.cloud_sprite_7,
            R.drawable.cloud_sprite_8
        ).map { BitmapFactory.decodeResource(resources, it) }
    }

    private val skyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(214, 200, 216, 228)
        style = Paint.Style.FILL
    }

    private val layerPaints = layerSpecs.map { spec ->
        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = spec.alpha }
    }

    private val featherPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        maskFilter = BlurMaskFilter(38f, BlurMaskFilter.Blur.NORMAL)
    }

    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val softCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        maskFilter = BlurMaskFilter(38f, BlurMaskFilter.Blur.NORMAL)
    }

    private val clearCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val animationTick = object : Runnable {
        override fun run() {
            if (!isAttachedToWindow) return
            invalidate()
            postDelayed(this, 165L)
        }
    }

    init {
        isClickable = false
        isFocusable = false
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        removeCallbacks(animationTick)
        post(animationTick)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(animationTick)
        super.onDetachedFromWindow()
    }

    fun setTrackPoints(points: List<TrackPoint>) {
        track = points
        invalidate()
    }

    fun setCurrentLocation(location: LatLng?) {
        currentLocation = location
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        val layer = canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), skyPaint)

        val currentMap = map
        if (currentMap != null) {
            drawCloudField(canvas, currentMap)
            if (track.isNotEmpty()) drawExploredRoutes(canvas, currentMap)
            currentLocation?.let { drawTemporaryOpening(canvas, currentMap, it) }
        } else {
            // Fallback if the map is not ready yet.
            drawFallbackMist(canvas)
        }

        canvas.restoreToCount(layer)
    }

    private fun drawCloudField(canvas: Canvas, currentMap: MapLibreMap) {
        if (cloudSprites.isEmpty()) return
        val seconds = (SystemClock.uptimeMillis() - animationStartMs) / 1000f
        val center = currentMap.cameraPosition.target
        val centerX = lonToWorldX(center.longitude)
        val centerY = latToWorldY(center.latitude)

        val zoom = currentMap.cameraPosition.zoom
        layerSpecs.forEachIndexed { layerIndex, spec ->
            if (zoom < spec.minZoom) return@forEachIndexed
            val stepPxX = max(36f, worldDeltaToPixelsX(currentMap, centerX, centerY, spec.stepX))
            val stepPxY = max(32f, worldDeltaToPixelsY(currentMap, centerX, centerY, spec.stepY))
            val cols = (ceil(width / stepPxX.toDouble()).toInt() + 8).coerceAtLeast(8)
            val rows = (ceil(height / stepPxY.toDouble()).toInt() + 8).coerceAtLeast(8)

            val driftX = spec.driftX * sin(seconds * (0.020f + layerIndex * 0.006f)).toDouble()
            val driftY = spec.driftY * cos(seconds * (0.017f + layerIndex * 0.005f)).toDouble()
            val paint = layerPaints[layerIndex]

            val baseCol = floor((centerX - spec.offsetX - driftX) / spec.stepX).toInt()
            val baseRow = floor((centerY - spec.offsetY - driftY) / spec.stepY).toInt()

            val rowStart = baseRow - rows / 2
            val rowEnd = baseRow + rows / 2
            val colStart = baseCol - cols / 2
            val colEnd = baseCol + cols / 2

            for (row in rowStart..rowEnd) {
                val rowShift = if (row % 2 == 0) 0.0 else spec.stepX * 0.42
                val worldY = spec.offsetY + row * spec.stepY + driftY
                if (worldY < -0.15 || worldY > 1.15) continue

                for (col in colStart..colEnd) {
                    val hash = stableHash(layerIndex, row, col)
                    val spriteIndex = hash % cloudSprites.size
                    val sprite = cloudSprites[spriteIndex]
                    val variation = 0.84 + ((hash shr 4) % 19) / 100.0
                    val rotation = (((hash shr 9) % 1000) / 1000f - 0.5f) * 2f * spec.rotationRange
                    val worldX = spec.offsetX + col * spec.stepX + rowShift + driftX
                    val normalizedX = wrapWorldX(worldX)
                    val sizeWorld = spec.sizeWorld * variation
                    drawGeoCloudSprite(
                        canvas = canvas,
                        currentMap = currentMap,
                        bitmap = sprite,
                        worldX = normalizedX,
                        worldY = worldY.coerceIn(-0.05, 1.05),
                        widthWorld = sizeWorld,
                        rotation = rotation,
                        paint = paint
                    )
                }
            }
        }
    }

    private fun drawGeoCloudSprite(
        canvas: Canvas,
        currentMap: MapLibreMap,
        bitmap: Bitmap,
        worldX: Double,
        worldY: Double,
        widthWorld: Double,
        rotation: Float,
        paint: Paint
    ) {
        if (bitmap.width <= 0 || bitmap.height <= 0) return

        val lat = worldYToLat(worldY)
        val lon = worldXToLon(worldX)
        val screen = currentMap.projection.toScreenLocation(LatLng(lat, lon))

        val screenWidth = worldDeltaToPixelsX(currentMap, worldX, worldY, widthWorld).coerceAtLeast(28f)
        val aspect = bitmap.height.toFloat() / bitmap.width.toFloat()
        val screenHeight = (screenWidth * aspect).coerceAtLeast(18f)

        val left = screen.x - screenWidth / 2f
        val top = screen.y - screenHeight / 2f
        val cx = screen.x
        val cy = screen.y

        canvas.save()
        canvas.rotate(rotation, cx, cy)
        canvas.drawBitmap(bitmap, null, RectF(left, top, left + screenWidth, top + screenHeight), paint)
        canvas.restore()
    }

    private fun drawExploredRoutes(canvas: Canvas, currentMap: MapLibreMap) {
        val grouped = track.groupBy { it.walkId }
        for (walkPoints in grouped.values) {
            if (walkPoints.isEmpty()) continue

            val path = Path()
            var started = false
            var representativeRadiusPx = 22f

            for (point in walkPoints) {
                val screen = currentMap.projection.toScreenLocation(LatLng(point.latitude, point.longitude))
                if (!started) {
                    path.moveTo(screen.x, screen.y)
                    representativeRadiusPx = radiusMetersToPixels(
                        currentMap,
                        point.latitude,
                        point.longitude,
                        REVEAL_RADIUS_M
                    )
                    started = true
                } else {
                    path.lineTo(screen.x, screen.y)
                }
            }
            if (!started) continue

            val coreWidth = (representativeRadiusPx * 2f).coerceIn(18f, 1100f)
            featherPaint.strokeWidth = (coreWidth + 78f).coerceAtMost(1180f)
            clearPaint.strokeWidth = coreWidth
            canvas.drawPath(path, featherPaint)
            canvas.drawPath(path, clearPaint)

            if (walkPoints.size == 1) {
                val only = walkPoints.first()
                val center = currentMap.projection.toScreenLocation(LatLng(only.latitude, only.longitude))
                clearCircle(canvas, center.x, center.y, representativeRadiusPx)
            }
        }
    }

    private fun drawTemporaryOpening(canvas: Canvas, currentMap: MapLibreMap, location: LatLng) {
        val center = currentMap.projection.toScreenLocation(location)
        val radius = radiusMetersToPixels(
            currentMap,
            location.latitude,
            location.longitude,
            CURRENT_OPENING_RADIUS_M
        ).coerceAtLeast(34f)
        clearCircle(canvas, center.x, center.y, radius)
    }

    private fun clearCircle(canvas: Canvas, x: Float, y: Float, radius: Float) {
        canvas.drawCircle(x, y, radius + 38f, softCirclePaint)
        canvas.drawCircle(x, y, radius, clearCirclePaint)
    }

    private fun radiusMetersToPixels(map: MapLibreMap, lat: Double, lon: Double, radiusM: Double): Float {
        val center = map.projection.toScreenLocation(LatLng(lat, lon))
        val latitudeDelta = radiusM / 111_320.0
        val north = map.projection.toScreenLocation(LatLng(lat + latitudeDelta, lon))
        return abs(center.y - north.y).coerceIn(6f, 560f)
    }

    private fun worldDeltaToPixelsX(map: MapLibreMap, worldX: Double, worldY: Double, deltaWorld: Double): Float {
        val lat = worldYToLat(worldY)
        val p1 = map.projection.toScreenLocation(LatLng(lat, worldXToLon(worldX)))
        val p2 = map.projection.toScreenLocation(LatLng(lat, worldXToLon(wrapWorldX(worldX + deltaWorld))))
        val delta = abs(p2.x - p1.x)
        return if (delta.isFinite()) delta else 0f
    }

    private fun worldDeltaToPixelsY(map: MapLibreMap, worldX: Double, worldY: Double, deltaWorld: Double): Float {
        val lon = worldXToLon(worldX)
        val p1 = map.projection.toScreenLocation(LatLng(worldYToLat(worldY), lon))
        val p2 = map.projection.toScreenLocation(LatLng(worldYToLat((worldY + deltaWorld).coerceIn(0.001, 0.999)), lon))
        val delta = abs(p2.y - p1.y)
        return if (delta.isFinite()) delta else 0f
    }

    private fun drawFallbackMist(canvas: Canvas) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(148, 235, 241, 245) }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
    }

    private fun stableHash(a: Int, b: Int, c: Int): Int {
        var x = a * 73428767 + b * 912931 + c * 19349663
        x = x xor (x shl 13)
        x = x xor (x ushr 17)
        x = x xor (x shl 5)
        return x and Int.MAX_VALUE
    }

    private fun lonToWorldX(lon: Double): Double = (lon + 180.0) / 360.0

    private fun latToWorldY(lat: Double): Double {
        val clamped = lat.coerceIn(-85.0, 85.0)
        val sinLat = sin(clamped * PI / 180.0)
        return 0.5 - ln((1.0 + sinLat) / (1.0 - sinLat)) / (4.0 * PI)
    }

    private fun worldXToLon(worldX: Double): Double = wrapWorldX(worldX) * 360.0 - 180.0

    private fun worldYToLat(worldY: Double): Double {
        val y = 0.5 - worldY.coerceIn(0.000001, 0.999999)
        val n = 2.0 * PI * y
        return Math.toDegrees(2.0 * kotlin.math.atan(exp(n)) - PI / 2.0)
    }

    private fun wrapWorldX(value: Double): Double {
        var x = value % 1.0
        if (x < 0.0) x += 1.0
        return x
    }

    companion object {
        private const val REVEAL_RADIUS_M = 30.0
        private const val CURRENT_OPENING_RADIUS_M = 44.0
    }
}
