package com.lifeinmist.app

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import kotlin.math.abs

class FogOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) { field = value; invalidate() }

    private var track: List<TrackPoint> = emptyList()

    private val veilPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(208, 242, 247, 251)
        style = Paint.Style.FILL
    }
    private val cloudPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        maskFilter = BlurMaskFilter(38f, BlurMaskFilter.Blur.NORMAL)
    }
    private val cloudShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(40, 175, 190, 203)
        style = Paint.Style.FILL
        maskFilter = BlurMaskFilter(42f, BlurMaskFilter.Blur.NORMAL)
    }
    private val featherPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        maskFilter = BlurMaskFilter(30f, BlurMaskFilter.Blur.NORMAL)
    }
    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    init {
        isClickable = false
        isFocusable = false
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun setTrackPoints(points: List<TrackPoint>) {
        track = points
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        val layer = canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)

        // Closed world = bright cloud cover. The map remains only faintly visible underneath.
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), veilPaint)
        drawCloudField(canvas)

        map?.let { currentMap ->
            if (track.isNotEmpty()) drawExploredRoutes(canvas, currentMap)
        }
        canvas.restoreToCount(layer)
    }

    private fun drawCloudField(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val base = (w.coerceAtMost(h) / 4.2f).coerceAtLeast(90f)

        // Deterministic overlapping puffs: organic clouds rather than a flat fog sheet.
        val anchors = arrayOf(
            floatArrayOf(-0.03f, 0.08f, 1.25f), floatArrayOf(0.20f, 0.03f, 1.05f),
            floatArrayOf(0.48f, 0.10f, 1.18f), floatArrayOf(0.79f, 0.04f, 1.28f),
            floatArrayOf(1.04f, 0.16f, 1.12f), floatArrayOf(0.08f, 0.32f, 1.10f),
            floatArrayOf(0.35f, 0.28f, 1.22f), floatArrayOf(0.66f, 0.34f, 1.04f),
            floatArrayOf(0.94f, 0.39f, 1.24f), floatArrayOf(-0.04f, 0.58f, 1.18f),
            floatArrayOf(0.22f, 0.55f, 1.03f), floatArrayOf(0.51f, 0.62f, 1.30f),
            floatArrayOf(0.80f, 0.58f, 1.12f), floatArrayOf(1.03f, 0.69f, 1.20f),
            floatArrayOf(0.08f, 0.86f, 1.24f), floatArrayOf(0.38f, 0.84f, 1.10f),
            floatArrayOf(0.68f, 0.91f, 1.28f), floatArrayOf(0.96f, 0.88f, 1.12f),
            floatArrayOf(0.22f, 1.06f, 1.20f), floatArrayOf(0.56f, 1.04f, 1.16f)
        )

        anchors.forEachIndexed { index, a ->
            val cx = a[0] * w
            val cy = a[1] * h
            val r = base * a[2]
            canvas.drawCircle(cx + r * 0.08f, cy + r * 0.14f, r * 0.95f, cloudShadowPaint)
            cloudPaint.color = if (index % 3 == 0) Color.argb(210, 255, 255, 255)
            else Color.argb(188, 248, 251, 254)
            canvas.drawCircle(cx, cy, r, cloudPaint)
            canvas.drawCircle(cx + r * 0.62f, cy - r * 0.12f, r * 0.72f, cloudPaint)
            canvas.drawCircle(cx - r * 0.55f, cy + r * 0.08f, r * 0.68f, cloudPaint)
        }
    }

    private fun drawExploredRoutes(canvas: Canvas, currentMap: MapLibreMap) {
        val grouped = track.groupBy { it.walkId }
        for (walkPoints in grouped.values) {
            if (walkPoints.isEmpty()) continue

            val path = Path()
            var started = false
            var representativeRadiusPx = 24f

            for (point in walkPoints) {
                val screen = currentMap.projection.toScreenLocation(LatLng(point.latitude, point.longitude))
                if (!started) {
                    path.moveTo(screen.x, screen.y)
                    representativeRadiusPx = radiusMetersToPixels(currentMap, point.latitude, point.longitude, REVEAL_RADIUS_M)
                    started = true
                } else {
                    path.lineTo(screen.x, screen.y)
                }
            }
            if (!started) continue

            val coreWidth = (representativeRadiusPx * 2f).coerceIn(16f, 1400f)
            featherPaint.strokeWidth = (coreWidth + 56f).coerceAtMost(1460f)
            clearPaint.strokeWidth = coreWidth
            canvas.drawPath(path, featherPaint)
            canvas.drawPath(path, clearPaint)

            if (walkPoints.size == 1) {
                val only = walkPoints.first()
                val center = currentMap.projection.toScreenLocation(LatLng(only.latitude, only.longitude))
                val r = representativeRadiusPx
                val soft = Paint(featherPaint).apply { style = Paint.Style.FILL }
                val clear = Paint(clearPaint).apply { style = Paint.Style.FILL }
                canvas.drawCircle(center.x, center.y, r + 28f, soft)
                canvas.drawCircle(center.x, center.y, r, clear)
            }
        }
    }

    private fun radiusMetersToPixels(map: MapLibreMap, lat: Double, lon: Double, radiusM: Double): Float {
        val center = map.projection.toScreenLocation(LatLng(lat, lon))
        val latitudeDelta = radiusM / 111_320.0
        val north = map.projection.toScreenLocation(LatLng(lat + latitudeDelta, lon))
        return abs(center.y - north.y).coerceIn(7f, 700f)
    }

    companion object {
        private const val REVEAL_RADIUS_M = 32.0
    }
}
