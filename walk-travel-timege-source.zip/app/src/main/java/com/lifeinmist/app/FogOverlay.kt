package com.lifeinmist.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import kotlin.math.abs

/**
 * Permanent cloud layer for unexplored territory.
 *
 * Unlike the old implementation this does NOT build the fog from circles.
 * Two soft cloud textures are composited over the map and the permanently
 * explored GPS corridors are cut out of that cloud sheet.
 */
class FogOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) {
            field = value
            invalidate()
        }

    private var track: List<TrackPoint> = emptyList()
    private var currentLocation: LatLng? = null

    private val cloudsFar: Bitmap by lazy {
        BitmapFactory.decodeResource(resources, R.drawable.clouds_far)
    }
    private val cloudsNear: Bitmap by lazy {
        BitmapFactory.decodeResource(resources, R.drawable.clouds_near)
    }

    private val veilPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(118, 226, 237, 240)
        style = Paint.Style.FILL
    }

    private val farCloudPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = 220
    }

    private val nearCloudPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = 245
    }

    private val featherPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        maskFilter = BlurMaskFilter(34f, BlurMaskFilter.Blur.NORMAL)
    }

    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val softCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        maskFilter = BlurMaskFilter(34f, BlurMaskFilter.Blur.NORMAL)
    }

    private val clearCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    init {
        isClickable = false
        isFocusable = false
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun setTrackPoints(points: List<TrackPoint>) {
        track = points
        invalidate()
    }

    fun setCurrentLocation(location: LatLng?) {
        currentLocation = location
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        // One off-screen layer lets CLEAR/DST_OUT cut holes through the complete
        // cloud composition while leaving the underlying MapLibre map untouched.
        val layer = canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)

        // Pale atmospheric wash closes any tiny transparent gaps in the textures.
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), veilPaint)
        drawCloudTexture(canvas, cloudsFar, farCloudPaint, scale = 1.08f, xShift = -0.035f, yShift = -0.015f)
        drawCloudTexture(canvas, cloudsNear, nearCloudPaint, scale = 1.02f, xShift = 0.018f, yShift = 0.025f)

        map?.let { currentMap ->
            if (track.isNotEmpty()) drawExploredRoutes(canvas, currentMap)
            currentLocation?.let { drawTemporaryOpening(canvas, currentMap, it) }
        }

        canvas.restoreToCount(layer)
    }

    /**
     * Scales one portrait cloud texture to cover the full view. A slight overscan
     * plus different offsets for the two layers prevents a flat wallpaper look.
     */
    private fun drawCloudTexture(
        canvas: Canvas,
        bitmap: Bitmap,
        paint: Paint,
        scale: Float,
        xShift: Float,
        yShift: Float
    ) {
        if (bitmap.width <= 0 || bitmap.height <= 0) return

        val viewW = width.toFloat()
        val viewH = height.toFloat()
        val bitmapAspect = bitmap.width.toFloat() / bitmap.height.toFloat()
        val viewAspect = viewW / viewH

        val targetW: Float
        val targetH: Float
        if (bitmapAspect > viewAspect) {
            targetH = viewH * scale
            targetW = targetH * bitmapAspect
        } else {
            targetW = viewW * scale
            targetH = targetW / bitmapAspect
        }

        val left = (viewW - targetW) * 0.5f + viewW * xShift
        val top = (viewH - targetH) * 0.5f + viewH * yShift
        canvas.drawBitmap(bitmap, null, RectF(left, top, left + targetW, top + targetH), paint)
    }

    private fun drawExploredRoutes(canvas: Canvas, currentMap: MapLibreMap) {
        val grouped = track.groupBy { it.walkId }
        for (walkPoints in grouped.values) {
            if (walkPoints.isEmpty()) continue

            val path = Path()
            var started = false
            var representativeRadiusPx = 22f

            for (point in walkPoints) {
                val screen = currentMap.projection.toScreenLocation(LatLng(point.latitude, point.longitude))
                if (!started) {
                    path.moveTo(screen.x, screen.y)
                    representativeRadiusPx = radiusMetersToPixels(
                        currentMap,
                        point.latitude,
                        point.longitude,
                        REVEAL_RADIUS_M
                    )
                    started = true
                } else {
                    path.lineTo(screen.x, screen.y)
                }
            }
            if (!started) continue

            val coreWidth = (representativeRadiusPx * 2f).coerceIn(16f, 1100f)
            featherPaint.strokeWidth = (coreWidth + 62f).coerceAtMost(1170f)
            clearPaint.strokeWidth = coreWidth
            canvas.drawPath(path, featherPaint)
            canvas.drawPath(path, clearPaint)

            if (walkPoints.size == 1) {
                val only = walkPoints.first()
                val center = currentMap.projection.toScreenLocation(LatLng(only.latitude, only.longitude))
                clearCircle(canvas, center.x, center.y, representativeRadiusPx)
            }
        }
    }

    private fun drawTemporaryOpening(canvas: Canvas, currentMap: MapLibreMap, location: LatLng) {
        val center = currentMap.projection.toScreenLocation(location)
        val radius = radiusMetersToPixels(
            currentMap,
            location.latitude,
            location.longitude,
            CURRENT_OPENING_RADIUS_M
        ).coerceAtLeast(32f)
        clearCircle(canvas, center.x, center.y, radius)
    }

    private fun clearCircle(canvas: Canvas, x: Float, y: Float, radius: Float) {
        canvas.drawCircle(x, y, radius + 30f, softCirclePaint)
        canvas.drawCircle(x, y, radius, clearCirclePaint)
    }

    private fun radiusMetersToPixels(map: MapLibreMap, lat: Double, lon: Double, radiusM: Double): Float {
        val center = map.projection.toScreenLocation(LatLng(lat, lon))
        val latitudeDelta = radiusM / 111_320.0
        val north = map.projection.toScreenLocation(LatLng(lat + latitudeDelta, lon))
        return abs(center.y - north.y).coerceIn(6f, 560f)
    }

    companion object {
        private const val REVEAL_RADIUS_M = 30.0
        private const val CURRENT_OPENING_RADIUS_M = 44.0
    }
}
