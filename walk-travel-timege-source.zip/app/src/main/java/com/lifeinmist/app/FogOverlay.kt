package com.lifeinmist.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ComposeShader
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * Lightweight permanent mask for unexplored territory.
 *
 * The unexplored area is a single, uniform, translucent cool grey-blue layer.
 * Explored routes are fully transparent and have a softly feathered edge.
 *
 * During pan / zoom / rotate the app only transforms ONE cached bitmap, which is
 * much lighter than rebuilding a field of cloud sprites every frame.
 */
class FogOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) {
            field = value
            markDirty()
        }

    private var track: List<TrackPoint> = emptyList()
    private var trackSegments: Collection<List<TrackPoint>> = emptyList()
    private var trackChunks: List<List<TrackChunk>> = emptyList()
    private var currentLocation: LatLng? = null

    private var cacheBitmap: Bitmap? = null
    private var spareBitmap: Bitmap? = null
    private val chunkCoordinates = FloatArray(128 * 2)
    private var cacheCenter: LatLng? = null
    private var cacheZoom: Double = 0.0
    private var cacheBearing: Double = 0.0
    private var cacheDirty = true
    private var cameraMoving = false
    private var cacheOriginX = 0f
    private var cacheOriginY = 0f

    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    private val fogFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(242, 220, 231, 241)
        style = Paint.Style.FILL
    }

    private val edgeFeatherPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    }

    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val softCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    }

    private val clearCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    // --- Animated cloud texture, layered on top of the (unchanged, cheap) fog mask. ---
    // Loaded once on a background thread; drawing is two shader-filled rects per frame,
    // no per-frame bitmap decoding, no offscreen layer, no per-sprite redraw.
    private var cloudTexturesRequested = false
    private var cloudFarBitmap: Bitmap? = null
    private var cloudNearBitmap: Bitmap? = null
    private var cloudFarShader: BitmapShader? = null
    private var cloudNearShader: BitmapShader? = null
    private var composeMaskBitmap: Bitmap? = null
    private var maskShader: BitmapShader? = null
    private var farCompose: ComposeShader? = null
    private var nearCompose: ComposeShader? = null
    private val farMatrix = Matrix()
    private val nearMatrix = Matrix()
    private val cloudFarPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val cloudNearPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    private val driftRunnable = object : Runnable {
        override fun run() {
            postInvalidateOnAnimation()
            if (isAttachedToWindow) postDelayed(this, DRIFT_FRAME_MS)
        }
    }

    init {
        isClickable = false
        isFocusable = false
        ensureCloudTextures()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        removeCallbacks(driftRunnable)
        postDelayed(driftRunnable, DRIFT_FRAME_MS)
    }

    /** Decodes the two tileable cloud textures off the main thread, once, then invalidates. */
    private fun ensureCloudTextures() {
        if (cloudTexturesRequested) return
        cloudTexturesRequested = true
        Thread {
            val opts = BitmapFactory.Options().apply {
                inSampleSize = 2
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val far = runCatching {
                BitmapFactory.decodeResource(resources, R.drawable.clouds_far, opts)
            }.getOrNull()
            val near = runCatching {
                BitmapFactory.decodeResource(resources, R.drawable.clouds_near, opts)
            }.getOrNull()
            post {
                if (!isAttachedToWindow) {
                    far?.recycle()
                    near?.recycle()
                    return@post
                }
                cloudFarBitmap = far
                cloudNearBitmap = near
                cloudFarShader = far?.let { BitmapShader(it, Shader.TileMode.MIRROR, Shader.TileMode.MIRROR) }
                cloudNearShader = near?.let { BitmapShader(it, Shader.TileMode.MIRROR, Shader.TileMode.MIRROR) }
                // Force the compose shaders to be rebuilt against the current mask.
                composeMaskBitmap = null
                postInvalidateOnAnimation()
            }
        }.start()
    }

    fun setTrackPoints(points: List<TrackPoint>) {
        if (track == points) return
        track = points
        trackSegments = points.groupBy { it.walkId }.values
        trackChunks = trackSegments.map { segment ->
            val chunks = ArrayList<TrackChunk>()
            var start = 0
            while (start < segment.size) {
                val end = minOf(start + 128, segment.size)
                chunks.add(TrackChunk(segment.subList(start, end)))
                if (end == segment.size) break
                start = end - 1
            }
            chunks
        }
        markDirty()
    }

    fun setCurrentLocation(location: LatLng?) {
        if (currentLocation == location) return
        currentLocation = location
        markDirty()
    }

    fun onCameraMove() {
        cameraMoving = true
        postInvalidateOnAnimation()
    }

    fun onCameraIdle() {
        cameraMoving = false
        // Translation/rotation alone do not invalidate a world-anchored bitmap.
        // Refresh resolution only after a meaningful zoom change.
        val zoom = map?.cameraPosition?.zoom
        if (zoom != null && kotlin.math.abs(zoom - cacheZoom) > 0.5) cacheDirty = true
        postInvalidateOnAnimation()
    }

    private fun markDirty() {
        cacheDirty = true
        postInvalidateOnAnimation()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        cacheDirty = true
        if (w > 0 && h > 0) postInvalidateOnAnimation()
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(driftRunnable)
        cacheBitmap?.recycle()
        spareBitmap?.recycle()
        cacheBitmap = null
        spareBitmap = null
        cloudFarBitmap?.recycle()
        cloudNearBitmap?.recycle()
        cloudFarBitmap = null
        cloudNearBitmap = null
        cloudFarShader = null
        cloudNearShader = null
        farCompose = null
        nearCompose = null
        maskShader = null
        composeMaskBitmap = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        // Re-anchor during a gesture too, before the cached footprint runs out.
        rebuildCacheIfPossible()

        val bitmap = cacheBitmap
        val currentMap = map
        val cachedCenter = cacheCenter
        if (bitmap == null || currentMap == null || cachedCenter == null) {
            canvas.drawPaint(fogFillPaint)
            return
        }
        val camera = currentMap.cameraPosition
        val cachedCenterOnScreen = currentMap.projection.toScreenLocation(cachedCenter)
        val mapScale = FogTransform.scale(camera.zoom, cacheZoom).toFloat()
        val rotation = FogTransform.rotation(camera.bearing, cacheBearing).toFloat()

        canvas.save()
        canvas.translate(cachedCenterOnScreen.x, cachedCenterOnScreen.y)
        if (rotation != 0f) canvas.rotate(rotation)
        canvas.scale(mapScale / CACHE_PIXEL_SCALE, mapScale / CACHE_PIXEL_SCALE)
        // The two regions are disjoint: uniform cover outside the cached rectangle,
        // cached mask inside. No full-screen offscreen layer or per-frame SRC blend.
        canvas.save()
        canvas.clipOutRect(-bitmap.width / 2f, -bitmap.height / 2f,
            bitmap.width / 2f, bitmap.height / 2f)
        canvas.drawPaint(fogFillPaint)
        canvas.restore()
        canvas.drawBitmap(bitmap, -bitmap.width / 2f, -bitmap.height / 2f, bitmapPaint)
        drawAnimatedClouds(canvas, bitmap)
        canvas.restore()
    }

    /**
     * Two large, slowly drifting cloud textures, masked to exactly the fog shape via
     * ComposeShader(DST_IN) against the existing cache bitmap's alpha channel.
     * No saveLayer, no offscreen compositing, no per-sprite draws: each layer is one
     * shader-filled rect. Only the shaders' local matrices change per frame.
     */
    private fun drawAnimatedClouds(canvas: Canvas, bitmap: Bitmap) {
        val far = cloudFarShader
        val near = cloudNearShader
        if (far == null && near == null) return

        if (composeMaskBitmap !== bitmap) {
            val mask = BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            mask.setLocalMatrix(Matrix().apply { setTranslate(-bitmap.width / 2f, -bitmap.height / 2f) })
            maskShader = mask
            farCompose = far?.let { ComposeShader(it, mask, PorterDuff.Mode.DST_IN) }
            nearCompose = near?.let { ComposeShader(it, mask, PorterDuff.Mode.DST_IN) }
            composeMaskBitmap = bitmap
        }

        val now = SystemClock.uptimeMillis()
        val breath = sin(2.0 * Math.PI * (now % BREATH_PERIOD_MS).toDouble() / BREATH_PERIOD_MS)

        val farBitmap = cloudFarBitmap
        if (far != null && farBitmap != null) {
            val tileW = farBitmap.width * FAR_TEXTURE_SCALE
            val tileH = farBitmap.height * FAR_TEXTURE_SCALE
            val dx = ((now.toDouble() * FAR_SPEED_X) % tileW).toFloat()
            val dy = ((now.toDouble() * FAR_SPEED_Y) % tileH).toFloat()
            farMatrix.reset()
            farMatrix.setScale(FAR_TEXTURE_SCALE, FAR_TEXTURE_SCALE)
            farMatrix.postTranslate(dx, dy)
            far.setLocalMatrix(farMatrix)
            cloudFarPaint.shader = farCompose
            cloudFarPaint.alpha = (FAR_BASE_ALPHA + breath * BREATH_AMPLITUDE).toInt().coerceIn(0, 255)
            canvas.drawRect(-bitmap.width / 2f, -bitmap.height / 2f, bitmap.width / 2f, bitmap.height / 2f, cloudFarPaint)
        }

        val nearBitmap = cloudNearBitmap
        if (near != null && nearBitmap != null) {
            val tileW = nearBitmap.width * NEAR_TEXTURE_SCALE
            val tileH = nearBitmap.height * NEAR_TEXTURE_SCALE
            val dx = ((now.toDouble() * NEAR_SPEED_X) % tileW).toFloat()
            val dy = ((now.toDouble() * NEAR_SPEED_Y) % tileH).toFloat()
            nearMatrix.reset()
            nearMatrix.setScale(NEAR_TEXTURE_SCALE, NEAR_TEXTURE_SCALE)
            nearMatrix.postTranslate(dx, dy)
            near.setLocalMatrix(nearMatrix)
            cloudNearPaint.shader = nearCompose
            cloudNearPaint.alpha = (NEAR_BASE_ALPHA - breath * BREATH_AMPLITUDE).toInt().coerceIn(0, 255)
            canvas.drawRect(-bitmap.width / 2f, -bitmap.height / 2f, bitmap.width / 2f, bitmap.height / 2f, cloudNearPaint)
        }
    }

    private fun cacheStillCoversView(): Boolean {
        val bitmap = cacheBitmap ?: return false
        val currentMap = map ?: return false
        val cachedCenter = cacheCenter ?: return false
        val camera = currentMap.cameraPosition
        val center = currentMap.projection.toScreenLocation(cachedCenter)
        val mapScale = FogTransform.scale(camera.zoom, cacheZoom).toFloat()

        val shownW = bitmap.width / CACHE_PIXEL_SCALE * mapScale
        val shownH = bitmap.height / CACHE_PIXEL_SCALE * mapScale
        return FogTransform.covers(width.toDouble(), height.toDouble(),
            center.x.toDouble(), center.y.toDouble(), shownW / 2.0, shownH / 2.0,
            FogTransform.rotation(camera.bearing, cacheBearing))
    }

    private fun rebuildCacheIfPossible() {
        // During gestures reuse the texture while it covers the screen. GPS changes
        // and resolution refresh wait for idle; a genuinely uncovered viewport still
        // re-anchors immediately so distant explored areas do not disappear.
        if (cacheBitmap != null && cacheStillCoversView() && (cameraMoving || !cacheDirty)) return
        val currentMap = map ?: return
        if (width <= 0 || height <= 0) return

        val camera = currentMap.cameraPosition
        val target = camera.target ?: return
        val origin = currentMap.projection.toScreenLocation(target)
        cacheOriginX = origin.x
        cacheOriginY = origin.y
        val cacheW = max(1, (width * CACHE_OVERSCAN * CACHE_PIXEL_SCALE).toInt())
        val cacheH = max(1, (height * CACHE_OVERSCAN * CACHE_PIXEL_SCALE).toInt())
        // Never draw into the currently displayed bitmap. Alternate two buffers.
        val newBitmap = spareBitmap?.takeIf {
            !it.isRecycled && it.width == cacheW && it.height == cacheH
        } ?: Bitmap.createBitmap(cacheW, cacheH, Bitmap.Config.ARGB_8888)
        spareBitmap = null
        // Essential for reuse: otherwise semi-transparent fills accumulate opacity.
        newBitmap.eraseColor(Color.TRANSPARENT)
        val offscreen = Canvas(newBitmap)

        // This canvas already targets an isolated bitmap; an extra layer doubles work.
        drawUniformMask(offscreen, cacheW, cacheH)
        if (track.isNotEmpty()) drawExploredRoutes(offscreen, currentMap, cacheW, cacheH)
        currentLocation?.let { drawTemporaryOpening(offscreen, currentMap, it, cacheW, cacheH) }

        val old = cacheBitmap
        cacheBitmap = newBitmap
        cacheCenter = LatLng(target.latitude, target.longitude)
        cacheZoom = camera.zoom
        cacheBearing = camera.bearing
        cacheDirty = false
        // A differently sized old buffer will be discarded on the next resize.
        // Do not recycle here: the renderer may still reference its last frame.
        spareBitmap = old
    }

    private fun drawUniformMask(canvas: Canvas, cacheW: Int, cacheH: Int) {
        canvas.drawRect(0f, 0f, cacheW.toFloat(), cacheH.toFloat(), fogFillPaint)
    }

    private fun drawExploredRoutes(canvas: Canvas, currentMap: MapLibreMap, cacheW: Int, cacheH: Int) {
        // Includes the entire oversized cache, not just the current screen, plus
        // the maximum 300-cache-pixel feather/stroke reach.
        val margin = 300f / CACHE_PIXEL_SCALE
        val left = cacheOriginX - cacheW / (2f * CACHE_PIXEL_SCALE) - margin
        val right = cacheOriginX + cacheW / (2f * CACHE_PIXEL_SCALE) + margin
        val top = cacheOriginY - cacheH / (2f * CACHE_PIXEL_SCALE) - margin
        val bottom = cacheOriginY + cacheH / (2f * CACHE_PIXEL_SCALE) + margin
        for (chunks in trackChunks) {
            if (chunks.isEmpty()) continue
            val visible = chunks.filter { it.mayIntersect(currentMap, left, top, right, bottom) }
            if (visible.isEmpty()) continue
            val first = chunks.first().points.first()
            val representativeRadiusPx = radiusMetersToPixels(currentMap,
                first.latitude, first.longitude, REVEAL_RADIUS_M) * CACHE_PIXEL_SCALE

            val path = Path()
            for (chunk in visible) {
                chunk.points.forEachIndexed { index, point ->
                    val screen = currentMap.projection.toScreenLocation(LatLng(point.latitude, point.longitude))
                    chunkCoordinates[2 * index] = (screen.x - cacheOriginX) * CACHE_PIXEL_SCALE + cacheW / 2f
                    chunkCoordinates[2 * index + 1] = (screen.y - cacheOriginY) * CACHE_PIXEL_SCALE + cacheH / 2f
                }
                val kept = ScreenPolyline.simplify(chunkCoordinates, chunk.points.size, 0.15)
                kept.forEachIndexed { index, point ->
                    val x = chunkCoordinates[2 * point]
                    val y = chunkCoordinates[2 * point + 1]
                    if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
            }

            val coreWidth = (representativeRadiusPx * 2f).coerceIn(9f, 550f)
            for (step in FEATHER_STEPS downTo 1) {
                val progress = step / FEATHER_STEPS.toFloat()
                edgeFeatherPaint.strokeWidth =
                    (coreWidth + progress * FEATHER_EXTRA_PX).coerceAtMost(600f)
                edgeFeatherPaint.alpha = (FEATHER_MAX_ALPHA * (1f - progress)).toInt()
                    .coerceIn(1, FEATHER_MAX_ALPHA)
                canvas.drawPath(path, edgeFeatherPaint)
            }
            clearPaint.strokeWidth = coreWidth
            canvas.drawPath(path, clearPaint)

            if (chunks.size == 1 && chunks.first().points.size == 1) {
                val only = first
                val screen = currentMap.projection.toScreenLocation(LatLng(only.latitude, only.longitude))
                val p = screenToCache(screen.x, screen.y, cacheW, cacheH)
                clearCircle(canvas, p.first, p.second, representativeRadiusPx)
            }
        }
    }

    private fun drawTemporaryOpening(
        canvas: Canvas,
        currentMap: MapLibreMap,
        location: LatLng,
        cacheW: Int,
        cacheH: Int
    ) {
        val screen = currentMap.projection.toScreenLocation(location)
        val p = screenToCache(screen.x, screen.y, cacheW, cacheH)
        val radius = (radiusMetersToPixels(
            currentMap,
            location.latitude,
            location.longitude,
            CURRENT_OPENING_RADIUS_M
        ) * CACHE_PIXEL_SCALE).coerceAtLeast(17f)
        clearCircle(canvas, p.first, p.second, radius)
    }

    private fun screenToCache(x: Float, y: Float, cacheW: Int, cacheH: Int): Pair<Float, Float> {
        val cx = (x - cacheOriginX) * CACHE_PIXEL_SCALE + cacheW / 2f
        val cy = (y - cacheOriginY) * CACHE_PIXEL_SCALE + cacheH / 2f
        return cx to cy
    }

    private fun clearCircle(canvas: Canvas, x: Float, y: Float, radius: Float) {
        for (i in FEATHER_STEPS downTo 1) {
            val t = i / FEATHER_STEPS.toFloat()
            softCirclePaint.alpha = (FEATHER_MAX_ALPHA * (1f - t)).toInt()
                .coerceIn(1, FEATHER_MAX_ALPHA)
            canvas.drawCircle(x, y, radius + t * FEATHER_EXTRA_PX, softCirclePaint)
        }
        canvas.drawCircle(x, y, radius, clearCirclePaint)
        softCirclePaint.alpha = 255
    }

    private fun radiusMetersToPixels(map: MapLibreMap, lat: Double, lon: Double, radiusM: Double): Float {
        val center = map.projection.toScreenLocation(LatLng(lat, lon))
        val latitudeDelta = radiusM / 111_320.0
        val north = map.projection.toScreenLocation(LatLng(lat + latitudeDelta, lon))
        return hypot(center.x - north.x, center.y - north.y).coerceIn(6f, 560f)
    }

    companion object {
        private const val REVEAL_RADIUS_M = 30.0
        private const val CURRENT_OPENING_RADIUS_M = 44.0
        private const val FEATHER_EXTRA_PX = 22f
        private const val FEATHER_STEPS = 8
        private const val FEATHER_MAX_ALPHA = 54

        // Lower internal resolution keeps panning/zooming light while overscan hides cache edges.
        private const val CACHE_PIXEL_SCALE = 0.32f
        private const val CACHE_OVERSCAN = 4.00f

        // Animated cloud drift: throttled well below display refresh rate since the motion
        // itself is slow, which keeps this cheap to run continuously in the background.
        private const val DRIFT_FRAME_MS = 55L // ~18 fps
        private const val FAR_TEXTURE_SCALE = 1.5f
        private const val NEAR_TEXTURE_SCALE = 1.0f
        private const val FAR_SPEED_X = 0.006  // cache-local px / ms
        private const val FAR_SPEED_Y = 0.003
        private const val NEAR_SPEED_X = -0.014
        private const val NEAR_SPEED_Y = 0.010
        private const val FAR_BASE_ALPHA = 46
        private const val NEAR_BASE_ALPHA = 60
        private const val BREATH_AMPLITUDE = 14
        private const val BREATH_PERIOD_MS = 9000L
    }
}
