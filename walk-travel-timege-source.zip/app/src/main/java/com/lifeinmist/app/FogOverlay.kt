package com.lifeinmist.app

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import kotlin.math.abs

class FogOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) { field = value; invalidate() }

    private var track: List<TrackPoint> = emptyList()

    private val fogPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val sheenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(10, 220, 235, 246)
        strokeWidth = 1.2f
    }
    private val featherPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        maskFilter = BlurMaskFilter(28f, BlurMaskFilter.Blur.NORMAL)
    }
    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    init {
        isClickable = false
        isFocusable = false
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun setTrackPoints(points: List<TrackPoint>) {
        track = points
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        val layer = canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)

        // Dark frosted glass: the underlying map is only faintly visible.
        fogPaint.shader = LinearGradient(
            0f, 0f, width.toFloat(), height.toFloat(),
            intArrayOf(
                Color.argb(225, 26, 34, 44),
                Color.argb(218, 35, 45, 57),
                Color.argb(228, 22, 30, 40)
            ),
            floatArrayOf(0f, 0.52f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fogPaint)

        var x = -height.toFloat()
        while (x < width * 1.6f) {
            canvas.drawLine(x, 0f, x + height.toFloat(), height.toFloat(), sheenPaint)
            x += 190f
        }

        map?.let { currentMap ->
            if (track.isNotEmpty()) drawExploredRoutes(canvas, currentMap)
        }
        canvas.restoreToCount(layer)
    }

    private fun drawExploredRoutes(canvas: Canvas, currentMap: MapLibreMap) {
        // Each recording session is drawn as its own path, but ALL sessions are retained.
        // This prevents an artificial line between yesterday's endpoint and today's start,
        // while still producing one accumulated explored world.
        val grouped = track.groupBy { it.walkId }
        for (walkPoints in grouped.values) {
            if (walkPoints.isEmpty()) continue

            val path = Path()
            var started = false
            var representativeRadiusPx = 24f

            for (point in walkPoints) {
                val screen = currentMap.projection.toScreenLocation(LatLng(point.latitude, point.longitude))
                if (!started) {
                    path.moveTo(screen.x, screen.y)
                    representativeRadiusPx = radiusMetersToPixels(currentMap, point.latitude, point.longitude, REVEAL_RADIUS_M)
                    started = true
                } else {
                    path.lineTo(screen.x, screen.y)
                }
            }
            if (!started) continue

            val coreWidth = (representativeRadiusPx * 2f).coerceIn(16f, 1400f)
            featherPaint.strokeWidth = (coreWidth + 42f).coerceAtMost(1450f)
            clearPaint.strokeWidth = coreWidth
            canvas.drawPath(path, featherPaint)
            canvas.drawPath(path, clearPaint)

            if (walkPoints.size == 1) {
                val only = walkPoints.first()
                val center = currentMap.projection.toScreenLocation(LatLng(only.latitude, only.longitude))
                val r = representativeRadiusPx
                val circleSoft = Paint(featherPaint).apply { style = Paint.Style.FILL }
                val circleClear = Paint(clearPaint).apply { style = Paint.Style.FILL }
                canvas.drawCircle(center.x, center.y, r + 21f, circleSoft)
                canvas.drawCircle(center.x, center.y, r, circleClear)
            }
        }
    }

    private fun radiusMetersToPixels(map: MapLibreMap, lat: Double, lon: Double, radiusM: Double): Float {
        val center = map.projection.toScreenLocation(LatLng(lat, lon))
        val latitudeDelta = radiusM / 111_320.0
        val north = map.projection.toScreenLocation(LatLng(lat + latitudeDelta, lon))
        return abs(center.y - north.y).coerceIn(7f, 700f)
    }

    companion object {
        private const val REVEAL_RADIUS_M = 32.0
    }
}
