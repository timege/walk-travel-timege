package com.lifeinmist.app

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import kotlin.math.abs

/**
 * Permanent "clouds of the unexplored world" layer.
 * All persisted track points are cut out of this layer. The current position also gets a
 * temporary small opening so the user can always see where they are before recording starts.
 */
class FogOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) {
            field = value
            invalidate()
        }

    private var track: List<TrackPoint> = emptyList()
    private var currentLocation: LatLng? = null

    private val veilPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(188, 239, 245, 250)
        style = Paint.Style.FILL
    }

    private val cloudShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(45, 116, 139, 160)
        style = Paint.Style.FILL
        maskFilter = BlurMaskFilter(28f, BlurMaskFilter.Blur.NORMAL)
    }

    private val featherPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        maskFilter = BlurMaskFilter(28f, BlurMaskFilter.Blur.NORMAL)
    }

    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    init {
        isClickable = false
        isFocusable = false
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun setTrackPoints(points: List<TrackPoint>) {
        track = points
        invalidate()
    }

    fun setCurrentLocation(location: LatLng?) {
        currentLocation = location
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        val layer = canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)

        // A pale base keeps the unexplored map only slightly visible below the cloud field.
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), veilPaint)
        drawCloudField(canvas)

        map?.let { currentMap ->
            if (track.isNotEmpty()) drawExploredRoutes(canvas, currentMap)
            currentLocation?.let { drawTemporaryOpening(canvas, currentMap, it) }
        }

        canvas.restoreToCount(layer)
    }

    private fun drawCloudField(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val base = (w.coerceAtMost(h) / 4.8f).coerceAtLeast(78f)

        // Fixed anchor positions keep the clouds stable while the map moves below them.
        // Each cluster is built from several differently tinted puffs to avoid a flat white veil.
        val anchors = arrayOf(
            floatArrayOf(-0.08f, 0.04f, 1.32f), floatArrayOf(0.16f, 0.02f, 1.08f),
            floatArrayOf(0.43f, 0.08f, 1.18f), floatArrayOf(0.73f, 0.02f, 1.26f),
            floatArrayOf(1.03f, 0.13f, 1.20f), floatArrayOf(0.02f, 0.27f, 1.18f),
            floatArrayOf(0.29f, 0.31f, 1.13f), floatArrayOf(0.61f, 0.29f, 1.18f),
            floatArrayOf(0.91f, 0.35f, 1.30f), floatArrayOf(-0.05f, 0.52f, 1.22f),
            floatArrayOf(0.20f, 0.56f, 1.08f), floatArrayOf(0.48f, 0.59f, 1.27f),
            floatArrayOf(0.78f, 0.55f, 1.16f), floatArrayOf(1.05f, 0.64f, 1.26f),
            floatArrayOf(0.03f, 0.80f, 1.25f), floatArrayOf(0.31f, 0.83f, 1.14f),
            floatArrayOf(0.63f, 0.86f, 1.30f), floatArrayOf(0.94f, 0.83f, 1.18f),
            floatArrayOf(0.15f, 1.03f, 1.22f), floatArrayOf(0.48f, 1.03f, 1.18f),
            floatArrayOf(0.80f, 1.04f, 1.23f)
        )

        anchors.forEachIndexed { index, a ->
            val cx = a[0] * w
            val cy = a[1] * h
            val r = base * a[2]

            canvas.drawCircle(cx + r * 0.10f, cy + r * 0.16f, r * 0.98f, cloudShadowPaint)
            drawCloudPuff(canvas, cx, cy, r, index)
            drawCloudPuff(canvas, cx + r * 0.58f, cy - r * 0.13f, r * 0.72f, index + 1)
            drawCloudPuff(canvas, cx - r * 0.54f, cy + r * 0.10f, r * 0.67f, index + 2)
            drawCloudPuff(canvas, cx + r * 0.12f, cy - r * 0.44f, r * 0.58f, index + 3)
        }
    }

    private fun drawCloudPuff(canvas: Canvas, cx: Float, cy: Float, radius: Float, variant: Int) {
        val center = when (variant % 4) {
            0 -> Color.argb(242, 255, 255, 255)
            1 -> Color.argb(236, 247, 250, 253)
            2 -> Color.argb(234, 234, 240, 246)
            else -> Color.argb(238, 249, 250, 252)
        }
        val edge = when (variant % 3) {
            0 -> Color.argb(128, 208, 218, 228)
            1 -> Color.argb(116, 224, 230, 237)
            else -> Color.argb(120, 216, 225, 233)
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                cx - radius * 0.18f,
                cy - radius * 0.20f,
                radius,
                intArrayOf(center, center, edge, Color.TRANSPARENT),
                floatArrayOf(0f, 0.45f, 0.82f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawCircle(cx, cy, radius, paint)
    }

    private fun drawExploredRoutes(canvas: Canvas, currentMap: MapLibreMap) {
        val grouped = track.groupBy { it.walkId }
        for (walkPoints in grouped.values) {
            if (walkPoints.isEmpty()) continue

            val path = Path()
            var started = false
            var representativeRadiusPx = 24f

            for (point in walkPoints) {
                val screen = currentMap.projection.toScreenLocation(LatLng(point.latitude, point.longitude))
                if (!started) {
                    path.moveTo(screen.x, screen.y)
                    representativeRadiusPx = radiusMetersToPixels(
                        currentMap,
                        point.latitude,
                        point.longitude,
                        REVEAL_RADIUS_M
                    )
                    started = true
                } else {
                    path.lineTo(screen.x, screen.y)
                }
            }
            if (!started) continue

            val coreWidth = (representativeRadiusPx * 2f).coerceIn(18f, 1400f)
            featherPaint.strokeWidth = (coreWidth + 58f).coerceAtMost(1460f)
            clearPaint.strokeWidth = coreWidth
            canvas.drawPath(path, featherPaint)
            canvas.drawPath(path, clearPaint)

            if (walkPoints.size == 1) {
                val only = walkPoints.first()
                val center = currentMap.projection.toScreenLocation(LatLng(only.latitude, only.longitude))
                clearCircle(canvas, center.x, center.y, representativeRadiusPx)
            }
        }
    }

    private fun drawTemporaryOpening(canvas: Canvas, currentMap: MapLibreMap, location: LatLng) {
        val center = currentMap.projection.toScreenLocation(location)
        val radius = radiusMetersToPixels(
            currentMap,
            location.latitude,
            location.longitude,
            CURRENT_OPENING_RADIUS_M
        ).coerceAtLeast(34f)
        clearCircle(canvas, center.x, center.y, radius)
    }

    private fun clearCircle(canvas: Canvas, x: Float, y: Float, radius: Float) {
        val soft = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.WHITE
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
            maskFilter = BlurMaskFilter(30f, BlurMaskFilter.Blur.NORMAL)
        }
        val clear = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.WHITE
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
        canvas.drawCircle(x, y, radius + 28f, soft)
        canvas.drawCircle(x, y, radius, clear)
    }

    private fun radiusMetersToPixels(map: MapLibreMap, lat: Double, lon: Double, radiusM: Double): Float {
        val center = map.projection.toScreenLocation(LatLng(lat, lon))
        val latitudeDelta = radiusM / 111_320.0
        val north = map.projection.toScreenLocation(LatLng(lat + latitudeDelta, lon))
        return abs(center.y - north.y).coerceIn(7f, 700f)
    }

    companion object {
        private const val REVEAL_RADIUS_M = 32.0
        private const val CURRENT_OPENING_RADIUS_M = 46.0
    }
}
