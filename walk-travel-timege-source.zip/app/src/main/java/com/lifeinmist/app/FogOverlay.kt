package com.lifeinmist.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin

/**
 * Cloud mask for unexplored territory.
 *
 * v0.6.3 is deliberately optimized for map gestures:
 * - expensive cloud composition is rendered only into a half-resolution cache;
 * - while panning/zooming the map we transform that single cached bitmap;
 * - no cloud sprite layout, blur or explored-mask rebuild happens during the gesture;
 * - the cache is rebuilt only when it is actually necessary.
 */
class FogOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) {
            field = value
            cacheDirty = true
            invalidate()
        }

    private var track: List<TrackPoint> = emptyList()
    private var currentLocation: LatLng? = null
    private val animationStartMs = SystemClock.uptimeMillis()

    private var cameraMoving = false
    private var cacheDirty = true
    private var overlayCache: Bitmap? = null
    private var cacheAnchor: LatLng? = null
    private var cacheZoom = 0.0
    private var cacheBearing = 0.0
    private var cachePaddingPx = 0f

    private val cloudSprites: List<Bitmap> by lazy {
        listOf(
            R.drawable.cloud_sprite_1,
            R.drawable.cloud_sprite_2,
            R.drawable.cloud_sprite_3,
            R.drawable.cloud_sprite_4,
            R.drawable.cloud_sprite_5,
            R.drawable.cloud_sprite_6,
            R.drawable.cloud_sprite_7,
            R.drawable.cloud_sprite_8
        ).map { BitmapFactory.decodeResource(resources, it) }
    }

    private val skyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(224, 190, 210, 224)
        style = Paint.Style.FILL
    }

    private val layerPaints = listOf(
        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = 118 },
        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = 154 },
        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = 192 },
        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = 224 },
        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = 246 }
    )

    private val cachePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val featherPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        maskFilter = BlurMaskFilter(38f, BlurMaskFilter.Blur.NORMAL)
    }

    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val softCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        maskFilter = BlurMaskFilter(38f, BlurMaskFilter.Blur.NORMAL)
    }

    private val clearCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    // Cheap visual drift: it moves the already-rendered cache by a few pixels.
    // We never re-compose cloud sprites just for animation.
    private val animationTick = object : Runnable {
        override fun run() {
            if (!isAttachedToWindow) return
            if (!cameraMoving) invalidate()
            postDelayed(this, 500L)
        }
    }

    init {
        isClickable = false
        isFocusable = false
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        removeCallbacks(animationTick)
        post(animationTick)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(animationTick)
        overlayCache?.recycle()
        overlayCache = null
        super.onDetachedFromWindow()
    }

    fun setTrackPoints(points: List<TrackPoint>) {
        if (track === points || track == points) return
        track = points
        cacheDirty = true
        if (!cameraMoving) invalidate()
    }

    fun setCurrentLocation(location: LatLng?) {
        val old = currentLocation
        currentLocation = location
        if (old == null || location == null ||
            abs(old.latitude - location.latitude) > 0.00002 ||
            abs(old.longitude - location.longitude) > 0.00002
        ) {
            cacheDirty = true
            if (!cameraMoving) invalidate()
        }
    }

    fun onCameraMove() {
        cameraMoving = true
        // Only one cached bitmap is drawn while the map is moving.
        invalidate()
    }

    fun onCameraIdle() {
        cameraMoving = false
        val currentMap = map
        if (currentMap != null && cacheNeedsRecentering(currentMap)) {
            cacheDirty = true
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return
        val currentMap = map ?: return

        if (overlayCache == null || (cacheDirty && !cameraMoving)) {
            rebuildCache(currentMap)
        }

        val cache = overlayCache ?: return
        val anchor = cacheAnchor ?: return
        drawTransformedCache(canvas, currentMap, cache, anchor)
    }

    private fun rebuildCache(currentMap: MapLibreMap) {
        if (width <= 0 || height <= 0) return
        val target = currentMap.cameraPosition.target ?: return

        // Small overscan avoids visible edges during normal one-finger pans, while the
        // half-resolution bitmap keeps memory bandwidth dramatically lower than v0.6.2.
        val padding = max(width, height) * CACHE_OVERSCAN_FRACTION
        val logicalWidth = width + padding * 2f
        val logicalHeight = height + padding * 2f
        val bitmapWidth = (logicalWidth * CACHE_RESOLUTION_SCALE).toInt().coerceAtLeast(1)
        val bitmapHeight = (logicalHeight * CACHE_RESOLUTION_SCALE).toInt().coerceAtLeast(1)

        var bitmap = overlayCache
        if (bitmap == null || bitmap.width != bitmapWidth || bitmap.height != bitmapHeight) {
            bitmap?.recycle()
            bitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888)
            overlayCache = bitmap
        } else {
            bitmap.eraseColor(Color.TRANSPARENT)
        }

        val renderCanvas = Canvas(bitmap)
        renderCanvas.scale(CACHE_RESOLUTION_SCALE, CACHE_RESOLUTION_SCALE)
        renderCanvas.translate(padding, padding)

        val layer = renderCanvas.saveLayer(
            -padding,
            -padding,
            width + padding,
            height + padding,
            null
        )
        renderCanvas.drawRect(-padding, -padding, width + padding, height + padding, skyPaint)
        drawCloudField(renderCanvas)
        if (track.isNotEmpty()) drawExploredRoutes(renderCanvas, currentMap)
        currentLocation?.let { drawTemporaryOpening(renderCanvas, currentMap, it) }
        renderCanvas.restoreToCount(layer)

        cachePaddingPx = padding
        cacheAnchor = LatLng(target.latitude, target.longitude)
        cacheZoom = currentMap.cameraPosition.zoom
        cacheBearing = currentMap.cameraPosition.bearing
        cacheDirty = false
    }

    private fun drawTransformedCache(
        canvas: Canvas,
        currentMap: MapLibreMap,
        cache: Bitmap,
        anchor: LatLng
    ) {
        val anchorNow = currentMap.projection.toScreenLocation(anchor)
        val zoomScale = 2.0.pow(currentMap.cameraPosition.zoom - cacheZoom)
            .toFloat()
            .coerceIn(0.30f, 3.20f)
        val bearingDelta = (currentMap.cameraPosition.bearing - cacheBearing).toFloat()

        val seconds = (SystemClock.uptimeMillis() - animationStartMs) / 1000f
        val cloudDriftX = if (cameraMoving) 0f else sin(seconds * 0.045f) * 3.0f
        val cloudDriftY = if (cameraMoving) 0f else cos(seconds * 0.036f) * 2.0f

        val sourceRect = RectF(0f, 0f, cache.width.toFloat(), cache.height.toFloat())
        val logicalRect = RectF(
            -cachePaddingPx,
            -cachePaddingPx,
            width + cachePaddingPx,
            height + cachePaddingPx
        )

        canvas.save()
        canvas.translate(anchorNow.x + cloudDriftX, anchorNow.y + cloudDriftY)
        canvas.rotate(-bearingDelta)
        canvas.scale(zoomScale, zoomScale)
        canvas.translate(-width / 2f, -height / 2f)
        cachePaint.isFilterBitmap = !cameraMoving
        canvas.drawBitmap(cache, sourceRect, logicalRect, cachePaint)
        canvas.restore()
    }

    private fun cacheNeedsRecentering(currentMap: MapLibreMap): Boolean {
        val anchor = cacheAnchor ?: return true
        val point = currentMap.projection.toScreenLocation(anchor)
        val dx = abs(point.x - width / 2f)
        val dy = abs(point.y - height / 2f)
        val zoomDelta = abs(currentMap.cameraPosition.zoom - cacheZoom)
        val bearingDelta = abs(currentMap.cameraPosition.bearing - cacheBearing)
        return dx > width * 0.30f ||
            dy > height * 0.30f ||
            zoomDelta > 0.72 ||
            bearingDelta > 22.0
    }

    /** Five cloud layers. Heavy composition runs only when rebuilding the cache. */
    private fun drawCloudField(canvas: Canvas) {
        if (cloudSprites.isEmpty()) return

        drawGridLayer(canvas, 0, rows = 4, cols = 3, scaleFraction = 0.56f, xStep = 0.43f, yStep = 0.31f, baseX = -0.18f, baseY = -0.14f)
        drawGridLayer(canvas, 1, rows = 5, cols = 3, scaleFraction = 0.46f, xStep = 0.39f, yStep = 0.255f, baseX = -0.12f, baseY = -0.10f)
        drawGridLayer(canvas, 2, rows = 6, cols = 4, scaleFraction = 0.35f, xStep = 0.31f, yStep = 0.215f, baseX = -0.11f, baseY = -0.08f)
        drawGridLayer(canvas, 3, rows = 6, cols = 4, scaleFraction = 0.29f, xStep = 0.30f, yStep = 0.205f, baseX = -0.10f, baseY = -0.07f)
        drawGridLayer(canvas, 4, rows = 5, cols = 4, scaleFraction = 0.38f, xStep = 0.36f, yStep = 0.27f, baseX = -0.14f, baseY = -0.11f)
    }

    private fun drawGridLayer(
        canvas: Canvas,
        layerIndex: Int,
        rows: Int,
        cols: Int,
        scaleFraction: Float,
        xStep: Float,
        yStep: Float,
        baseX: Float,
        baseY: Float
    ) {
        val w = width.toFloat()
        val h = height.toFloat()
        val paint = layerPaints[layerIndex]
        for (row in 0 until rows) {
            for (col in 0 until cols) {
                val index = (layerIndex * 7 + row * 5 + col * 3) % cloudSprites.size
                val rowOffset = if (row % 2 == 0) 0f else xStep * 0.33f
                val x = w * (baseX + col * xStep + rowOffset)
                val y = h * (baseY + row * yStep)
                val variation = ((index * 17 + row * 11 + col * 7 + layerIndex * 13) % 9) * 0.012f
                val size = w * (scaleFraction + variation)
                val rotation = ((index * 29 + row * 13 + col * 9 + layerIndex * 5) % 42 - 21).toFloat()
                drawCloudSprite(canvas, cloudSprites[index], x, y, size, rotation, paint)
            }
        }
    }

    private fun drawCloudSprite(
        canvas: Canvas,
        bitmap: Bitmap,
        left: Float,
        top: Float,
        size: Float,
        rotation: Float,
        paint: Paint
    ) {
        if (bitmap.width <= 0 || bitmap.height <= 0) return
        val aspect = bitmap.height.toFloat() / bitmap.width.toFloat()
        val cloudW = size
        val cloudH = size * aspect
        val cx = left + cloudW / 2f
        val cy = top + cloudH / 2f

        canvas.save()
        canvas.rotate(rotation, cx, cy)
        canvas.drawBitmap(bitmap, null, RectF(left, top, left + cloudW, top + cloudH), paint)
        canvas.restore()
    }

    private fun drawExploredRoutes(canvas: Canvas, currentMap: MapLibreMap) {
        val grouped = track.groupBy { it.walkId }
        for (walkPoints in grouped.values) {
            if (walkPoints.isEmpty()) continue

            val path = Path()
            var started = false
            var representativeRadiusPx = 22f

            for (point in walkPoints) {
                val screen = currentMap.projection.toScreenLocation(LatLng(point.latitude, point.longitude))
                if (!started) {
                    path.moveTo(screen.x, screen.y)
                    representativeRadiusPx = radiusMetersToPixels(
                        currentMap,
                        point.latitude,
                        point.longitude,
                        REVEAL_RADIUS_M
                    )
                    started = true
                } else {
                    path.lineTo(screen.x, screen.y)
                }
            }
            if (!started) continue

            val coreWidth = (representativeRadiusPx * 2f).coerceIn(18f, 1100f)
            featherPaint.strokeWidth = (coreWidth + 78f).coerceAtMost(1180f)
            clearPaint.strokeWidth = coreWidth
            canvas.drawPath(path, featherPaint)
            canvas.drawPath(path, clearPaint)

            if (walkPoints.size == 1) {
                val only = walkPoints.first()
                val center = currentMap.projection.toScreenLocation(LatLng(only.latitude, only.longitude))
                clearCircle(canvas, center.x, center.y, representativeRadiusPx)
            }
        }
    }

    private fun drawTemporaryOpening(canvas: Canvas, currentMap: MapLibreMap, location: LatLng) {
        val center = currentMap.projection.toScreenLocation(location)
        val radius = radiusMetersToPixels(
            currentMap,
            location.latitude,
            location.longitude,
            CURRENT_OPENING_RADIUS_M
        ).coerceAtLeast(34f)
        clearCircle(canvas, center.x, center.y, radius)
    }

    private fun clearCircle(canvas: Canvas, x: Float, y: Float, radius: Float) {
        canvas.drawCircle(x, y, radius + 38f, softCirclePaint)
        canvas.drawCircle(x, y, radius, clearCirclePaint)
    }

    private fun radiusMetersToPixels(map: MapLibreMap, lat: Double, lon: Double, radiusM: Double): Float {
        val center = map.projection.toScreenLocation(LatLng(lat, lon))
        val latitudeDelta = radiusM / 111_320.0
        val north = map.projection.toScreenLocation(LatLng(lat + latitudeDelta, lon))
        return abs(center.y - north.y).coerceIn(6f, 560f)
    }

    companion object {
        private const val REVEAL_RADIUS_M = 30.0
        private const val CURRENT_OPENING_RADIUS_M = 44.0
        private const val CACHE_RESOLUTION_SCALE = 0.25f
        private const val CACHE_OVERSCAN_FRACTION = 0.04f
    }
}
