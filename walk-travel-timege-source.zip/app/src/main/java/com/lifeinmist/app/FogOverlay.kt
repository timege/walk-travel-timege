package com.lifeinmist.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.pow

/**
 * Lightweight permanent mask for unexplored territory.
 *
 * The unexplored area is a single, uniform, translucent cool grey-blue layer.
 * Explored routes are fully transparent and have a softly feathered edge.
 *
 * During pan / zoom / rotate the app only transforms ONE cached bitmap, which is
 * much lighter than rebuilding a field of cloud sprites every frame.
 */
class FogOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) {
            field = value
            markDirty()
        }

    private var track: List<TrackPoint> = emptyList()
    private var currentLocation: LatLng? = null

    private var cacheBitmap: Bitmap? = null
    private var cacheCenter: LatLng? = null
    private var cacheZoom: Double = 0.0
    private var cacheBearing: Double = 0.0
    private var cacheDirty = true
    private var cameraMoving = false

    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    private val fogFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(242, 220, 231, 241)
        style = Paint.Style.FILL
    }

    private val edgeFeatherPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    }

    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val softCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    }

    private val clearCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    init {
        isClickable = false
        isFocusable = false
    }

    fun setTrackPoints(points: List<TrackPoint>) {
        track = points
        markDirty()
    }

    fun setCurrentLocation(location: LatLng?) {
        currentLocation = location
        markDirty()
    }

    fun onCameraMove() {
        cameraMoving = true
        invalidate()
    }

    fun onCameraIdle() {
        cameraMoving = false
        rebuildCacheIfPossible(force = true)
        invalidate()
    }

    private fun markDirty() {
        cacheDirty = true
        if (!cameraMoving) {
            post {
                rebuildCacheIfPossible()
                invalidate()
            }
        } else {
            invalidate()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        cacheDirty = true
        if (w > 0 && h > 0) post { rebuildCacheIfPossible() }
    }

    override fun onDetachedFromWindow() {
        cacheBitmap?.recycle()
        cacheBitmap = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        if (cacheBitmap == null && !cameraMoving) rebuildCacheIfPossible()

        val bitmap = cacheBitmap ?: return
        val currentMap = map ?: return
        val cachedCenter = cacheCenter ?: return
        val camera = currentMap.cameraPosition
        val cachedCenterOnScreen = currentMap.projection.toScreenLocation(cachedCenter)
        val mapScale = 2.0.pow(camera.zoom - cacheZoom).toFloat().coerceIn(0.08f, 12f)
        val rotation = (camera.bearing - cacheBearing).toFloat()

        canvas.save()
        canvas.translate(cachedCenterOnScreen.x, cachedCenterOnScreen.y)
        if (rotation != 0f) canvas.rotate(rotation)
        canvas.scale(mapScale / CACHE_PIXEL_SCALE, mapScale / CACHE_PIXEL_SCALE)
        canvas.drawBitmap(bitmap, -bitmap.width / 2f, -bitmap.height / 2f, bitmapPaint)
        canvas.restore()
    }

    private fun cacheStillCoversView(): Boolean {
        val bitmap = cacheBitmap ?: return false
        val currentMap = map ?: return false
        val cachedCenter = cacheCenter ?: return false
        val camera = currentMap.cameraPosition
        val center = currentMap.projection.toScreenLocation(cachedCenter)
        val mapScale = 2.0.pow(camera.zoom - cacheZoom).toFloat()

        if (mapScale < 0.58f || mapScale > 1.72f) return false

        val shownW = bitmap.width / CACHE_PIXEL_SCALE * mapScale
        val shownH = bitmap.height / CACHE_PIXEL_SCALE * mapScale
        val left = center.x - shownW / 2f
        val right = center.x + shownW / 2f
        val top = center.y - shownH / 2f
        val bottom = center.y + shownH / 2f
        val margin = 8f
        return left <= -margin && right >= width + margin && top <= -margin && bottom >= height + margin
    }

    private fun rebuildCacheIfPossible(force: Boolean = false) {
        if (!force && !cacheDirty && cacheStillCoversView()) return
        if (cameraMoving) return
        val currentMap = map ?: return
        if (width <= 0 || height <= 0) return

        val camera = currentMap.cameraPosition
        val target = camera.target ?: return
        val cacheW = max(1, (width * CACHE_OVERSCAN * CACHE_PIXEL_SCALE).toInt())
        val cacheH = max(1, (height * CACHE_OVERSCAN * CACHE_PIXEL_SCALE).toInt())
        val newBitmap = Bitmap.createBitmap(cacheW, cacheH, Bitmap.Config.ARGB_8888)
        val offscreen = Canvas(newBitmap)

        val layer = offscreen.saveLayer(0f, 0f, cacheW.toFloat(), cacheH.toFloat(), null)
        drawUniformMask(offscreen, cacheW, cacheH)
        if (track.isNotEmpty()) drawExploredRoutes(offscreen, currentMap, cacheW, cacheH)
        currentLocation?.let { drawTemporaryOpening(offscreen, currentMap, it, cacheW, cacheH) }
        offscreen.restoreToCount(layer)

        val old = cacheBitmap
        cacheBitmap = newBitmap
        cacheCenter = LatLng(target.latitude, target.longitude)
        cacheZoom = camera.zoom
        cacheBearing = camera.bearing
        cacheDirty = false
        old?.recycle()
    }

    private fun drawUniformMask(canvas: Canvas, cacheW: Int, cacheH: Int) {
        canvas.drawRect(0f, 0f, cacheW.toFloat(), cacheH.toFloat(), fogFillPaint)
    }

    private fun drawExploredRoutes(canvas: Canvas, currentMap: MapLibreMap, cacheW: Int, cacheH: Int) {
        val grouped = track.groupBy { it.walkId }
        for (walkPoints in grouped.values) {
            if (walkPoints.isEmpty()) continue

            val path = Path()
            var started = false
            var representativeRadiusPx = 22f * CACHE_PIXEL_SCALE

            for (point in walkPoints) {
                val screen = currentMap.projection.toScreenLocation(LatLng(point.latitude, point.longitude))
                val p = screenToCache(screen.x, screen.y, cacheW, cacheH)
                if (!started) {
                    path.moveTo(p.first, p.second)
                    representativeRadiusPx = radiusMetersToPixels(
                        currentMap,
                        point.latitude,
                        point.longitude,
                        REVEAL_RADIUS_M
                    ) * CACHE_PIXEL_SCALE
                    started = true
                } else {
                    path.lineTo(p.first, p.second)
                }
            }
            if (!started) continue

            val coreWidth = (representativeRadiusPx * 2f).coerceIn(9f, 550f)
            for (step in FEATHER_STEPS downTo 1) {
                val progress = step / FEATHER_STEPS.toFloat()
                edgeFeatherPaint.strokeWidth =
                    (coreWidth + progress * FEATHER_EXTRA_PX).coerceAtMost(600f)
                edgeFeatherPaint.alpha = (FEATHER_MAX_ALPHA * (1f - progress)).toInt()
                    .coerceIn(1, FEATHER_MAX_ALPHA)
                canvas.drawPath(path, edgeFeatherPaint)
            }
            clearPaint.strokeWidth = coreWidth
            canvas.drawPath(path, clearPaint)

            if (walkPoints.size == 1) {
                val only = walkPoints.first()
                val screen = currentMap.projection.toScreenLocation(LatLng(only.latitude, only.longitude))
                val p = screenToCache(screen.x, screen.y, cacheW, cacheH)
                clearCircle(canvas, p.first, p.second, representativeRadiusPx)
            }
        }
    }

    private fun drawTemporaryOpening(
        canvas: Canvas,
        currentMap: MapLibreMap,
        location: LatLng,
        cacheW: Int,
        cacheH: Int
    ) {
        val screen = currentMap.projection.toScreenLocation(location)
        val p = screenToCache(screen.x, screen.y, cacheW, cacheH)
        val radius = (radiusMetersToPixels(
            currentMap,
            location.latitude,
            location.longitude,
            CURRENT_OPENING_RADIUS_M
        ) * CACHE_PIXEL_SCALE).coerceAtLeast(17f)
        clearCircle(canvas, p.first, p.second, radius)
    }

    private fun screenToCache(x: Float, y: Float, cacheW: Int, cacheH: Int): Pair<Float, Float> {
        val cx = (x - width / 2f) * CACHE_PIXEL_SCALE + cacheW / 2f
        val cy = (y - height / 2f) * CACHE_PIXEL_SCALE + cacheH / 2f
        return cx to cy
    }

    private fun clearCircle(canvas: Canvas, x: Float, y: Float, radius: Float) {
        for (i in FEATHER_STEPS downTo 1) {
            val t = i / FEATHER_STEPS.toFloat()
            softCirclePaint.alpha = (FEATHER_MAX_ALPHA * (1f - t)).toInt()
                .coerceIn(1, FEATHER_MAX_ALPHA)
            canvas.drawCircle(x, y, radius + t * FEATHER_EXTRA_PX, softCirclePaint)
        }
        canvas.drawCircle(x, y, radius, clearCirclePaint)
        softCirclePaint.alpha = 255
    }

    private fun radiusMetersToPixels(map: MapLibreMap, lat: Double, lon: Double, radiusM: Double): Float {
        val center = map.projection.toScreenLocation(LatLng(lat, lon))
        val latitudeDelta = radiusM / 111_320.0
        val north = map.projection.toScreenLocation(LatLng(lat + latitudeDelta, lon))
        return abs(center.y - north.y).coerceIn(6f, 560f)
    }

    companion object {
        private const val REVEAL_RADIUS_M = 30.0
        private const val CURRENT_OPENING_RADIUS_M = 44.0
        private const val FEATHER_EXTRA_PX = 22f
        private const val FEATHER_STEPS = 8
        private const val FEATHER_MAX_ALPHA = 54

        // Lower internal resolution keeps panning/zooming light while overscan hides cache edges.
        private const val CACHE_PIXEL_SCALE = 0.32f
        private const val CACHE_OVERSCAN = 4.00f
    }
}
