package com.lifeinmist.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.pow

/**
 * Permanent cloud layer for unexplored territory.
 *
 * v0.6.0 uses five independently drifting cloud layers. The animation is deliberately
 * slow and low-frequency so the cloud field feels alive without becoming a battery-heavy
 * weather animation. Explored GPS corridors are cut out of the complete cloud composite.
 */
class FogOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) {
            field = value
            cloudAnchor = null
            cloudReferenceZoom = null
            invalidate()
        }

    private var track: List<TrackPoint> = emptyList()
    private var currentLocation: LatLng? = null
    private val animationStartMs = SystemClock.uptimeMillis()
    private var cloudAnchor: LatLng? = null
    private var cloudReferenceZoom: Double? = null

    private val cloudSprites: List<Bitmap> by lazy {
        listOf(
            R.drawable.cloud_sprite_1,
            R.drawable.cloud_sprite_2,
            R.drawable.cloud_sprite_3,
            R.drawable.cloud_sprite_4,
            R.drawable.cloud_sprite_5,
            R.drawable.cloud_sprite_6,
            R.drawable.cloud_sprite_7,
            R.drawable.cloud_sprite_8
        ).map { BitmapFactory.decodeResource(resources, it) }
    }

    // This closes unexplored territory between individual cloud masses. It is intentionally
    // pale and cool, but explored areas are cut completely through it to the actual map.
    private val skyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(224, 190, 210, 224)
        style = Paint.Style.FILL
    }

    private val layerPaints = listOf(
        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = 118 },
        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = 154 },
        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = 192 },
        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = 224 },
        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = 246 }
    )

    private val featherPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        maskFilter = BlurMaskFilter(38f, BlurMaskFilter.Blur.NORMAL)
    }

    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val softCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        maskFilter = BlurMaskFilter(38f, BlurMaskFilter.Blur.NORMAL)
    }

    private val clearCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val animationTick = object : Runnable {
        override fun run() {
            if (!isAttachedToWindow) return
            invalidate()
            // About 6 fps is enough for very slow cloud drift and materially cheaper than 60 fps.
            postDelayed(this, 165L)
        }
    }

    init {
        isClickable = false
        isFocusable = false
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        removeCallbacks(animationTick)
        post(animationTick)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(animationTick)
        super.onDetachedFromWindow()
    }

    fun setTrackPoints(points: List<TrackPoint>) {
        track = points
        invalidate()
    }

    fun setCurrentLocation(location: LatLng?) {
        currentLocation = location
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        val layer = canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)

        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), skyPaint)
        map?.let { drawCloudField(canvas, it) }

        map?.let { currentMap ->
            if (track.isNotEmpty()) drawExploredRoutes(canvas, currentMap)
            currentLocation?.let { drawTemporaryOpening(canvas, currentMap, it) }
        }

        canvas.restoreToCount(layer)
    }

    /** Five cloud layers anchored to the map. Their position and size follow camera zoom/pan. */
    private fun drawCloudField(canvas: Canvas, currentMap: MapLibreMap) {
        if (cloudSprites.isEmpty()) return

        val currentZoom = currentMap.cameraPosition.zoom
        val previousReferenceZoom = cloudReferenceZoom
        if (cloudAnchor == null || previousReferenceZoom == null || abs(currentZoom - previousReferenceZoom) > 8.0) {
            cloudAnchor = currentMap.cameraPosition.target
            cloudReferenceZoom = currentZoom
        }

        val anchor = cloudAnchor ?: currentMap.cameraPosition.target
        val referenceZoom = cloudReferenceZoom ?: currentZoom
        val zoomScale = 2.0.pow(currentZoom - referenceZoom).toFloat().coerceIn(0.25f, 4.0f)
        val anchorScreen = currentMap.projection.toScreenLocation(anchor)
        val seconds = (SystemClock.uptimeMillis() - animationStartMs) / 1000f

        drawAnchoredGridLayer(
            canvas, 0, 0.56f, 0.43f, 0.31f, -0.18f, -0.14f,
            anchorScreen.x, anchorScreen.y, zoomScale,
            sin(seconds * 0.030f) * 10f, cos(seconds * 0.024f) * 5f
        )
        drawAnchoredGridLayer(
            canvas, 1, 0.46f, 0.39f, 0.255f, -0.12f, -0.10f,
            anchorScreen.x, anchorScreen.y, zoomScale,
            cos(seconds * 0.038f) * 8f, sin(seconds * 0.028f) * 6f
        )
        drawAnchoredGridLayer(
            canvas, 2, 0.35f, 0.31f, 0.215f, -0.11f, -0.08f,
            anchorScreen.x, anchorScreen.y, zoomScale,
            sin(seconds * 0.045f) * 7f, cos(seconds * 0.035f) * 6f
        )
        drawAnchoredGridLayer(
            canvas, 3, 0.29f, 0.30f, 0.205f, -0.10f, -0.07f,
            anchorScreen.x, anchorScreen.y, zoomScale,
            cos(seconds * 0.052f) * 6f, sin(seconds * 0.041f) * 5f
        )
        drawAnchoredGridLayer(
            canvas, 4, 0.38f, 0.36f, 0.27f, -0.14f, -0.11f,
            anchorScreen.x, anchorScreen.y, zoomScale,
            sin(seconds * 0.060f) * 5f, cos(seconds * 0.047f) * 4f
        )
    }

    private fun drawAnchoredGridLayer(
        canvas: Canvas,
        layerIndex: Int,
        scaleFraction: Float,
        xStepFraction: Float,
        yStepFraction: Float,
        baseXFraction: Float,
        baseYFraction: Float,
        anchorX: Float,
        anchorY: Float,
        zoomScale: Float,
        driftX: Float,
        driftY: Float
    ) {
        val w = width.toFloat()
        val h = height.toFloat()
        val stepX = (w * xStepFraction * zoomScale).coerceAtLeast(34f)
        val stepY = (h * yStepFraction * zoomScale).coerceAtLeast(34f)
        val sizeBase = (w * scaleFraction * zoomScale).coerceAtLeast(26f)
        val originX = anchorX + w * baseXFraction * zoomScale + driftX * zoomScale
        val originY = anchorY + h * baseYFraction * zoomScale + driftY * zoomScale
        val paint = layerPaints[layerIndex]

        val minCol = floor((0f - originX) / stepX).toInt() - 2
        val maxCol = ceil((w - originX) / stepX).toInt() + 2
        val minRow = floor((0f - originY) / stepY).toInt() - 2
        val maxRow = ceil((h - originY) / stepY).toInt() + 2

        for (row in minRow..maxRow) {
            for (col in minCol..maxCol) {
                val seed = positiveMod(layerIndex * 97 + row * 31 + col * 17, 10_000)
                val index = seed % cloudSprites.size
                val rowOffset = if ((row and 1) == 0) 0f else stepX * 0.33f
                val x = originX + col * stepX + rowOffset
                val y = originY + row * stepY
                val variation = (seed % 9) * 0.012f
                val size = sizeBase * (1f + variation)
                val rotation = (positiveMod(seed * 29 + layerIndex * 13, 42) - 21).toFloat()
                drawCloudSprite(canvas, cloudSprites[index], x, y, size, rotation, paint)
            }
        }
    }

    private fun positiveMod(value: Int, mod: Int): Int {
        val result = value % mod
        return if (result < 0) result + mod else result
    }

    private fun drawCloudSprite(
        canvas: Canvas,
        bitmap: Bitmap,
        left: Float,
        top: Float,
        size: Float,
        rotation: Float,
        paint: Paint
    ) {
        if (bitmap.width <= 0 || bitmap.height <= 0) return
        val aspect = bitmap.height.toFloat() / bitmap.width.toFloat()
        val cloudW = size
        val cloudH = size * aspect
        val cx = left + cloudW / 2f
        val cy = top + cloudH / 2f

        canvas.save()
        canvas.rotate(rotation, cx, cy)
        canvas.drawBitmap(bitmap, null, RectF(left, top, left + cloudW, top + cloudH), paint)
        canvas.restore()
    }

    private fun drawExploredRoutes(canvas: Canvas, currentMap: MapLibreMap) {
        val grouped = track.groupBy { it.walkId }
        for (walkPoints in grouped.values) {
            if (walkPoints.isEmpty()) continue

            val path = Path()
            var started = false
            var representativeRadiusPx = 22f

            for (point in walkPoints) {
                val screen = currentMap.projection.toScreenLocation(LatLng(point.latitude, point.longitude))
                if (!started) {
                    path.moveTo(screen.x, screen.y)
                    representativeRadiusPx = radiusMetersToPixels(
                        currentMap,
                        point.latitude,
                        point.longitude,
                        REVEAL_RADIUS_M
                    )
                    started = true
                } else {
                    path.lineTo(screen.x, screen.y)
                }
            }
            if (!started) continue

            val coreWidth = (representativeRadiusPx * 2f).coerceIn(18f, 1100f)
            featherPaint.strokeWidth = (coreWidth + 78f).coerceAtMost(1180f)
            clearPaint.strokeWidth = coreWidth
            canvas.drawPath(path, featherPaint)
            canvas.drawPath(path, clearPaint)

            if (walkPoints.size == 1) {
                val only = walkPoints.first()
                val center = currentMap.projection.toScreenLocation(LatLng(only.latitude, only.longitude))
                clearCircle(canvas, center.x, center.y, representativeRadiusPx)
            }
        }
    }

    private fun drawTemporaryOpening(canvas: Canvas, currentMap: MapLibreMap, location: LatLng) {
        val center = currentMap.projection.toScreenLocation(location)
        val radius = radiusMetersToPixels(
            currentMap,
            location.latitude,
            location.longitude,
            CURRENT_OPENING_RADIUS_M
        ).coerceAtLeast(34f)
        clearCircle(canvas, center.x, center.y, radius)
    }

    private fun clearCircle(canvas: Canvas, x: Float, y: Float, radius: Float) {
        canvas.drawCircle(x, y, radius + 38f, softCirclePaint)
        canvas.drawCircle(x, y, radius, clearCirclePaint)
    }

    private fun radiusMetersToPixels(map: MapLibreMap, lat: Double, lon: Double, radiusM: Double): Float {
        val center = map.projection.toScreenLocation(LatLng(lat, lon))
        val latitudeDelta = radiusM / 111_320.0
        val north = map.projection.toScreenLocation(LatLng(lat + latitudeDelta, lon))
        return abs(center.y - north.y).coerceIn(6f, 560f)
    }

    companion object {
        private const val REVEAL_RADIUS_M = 30.0
        private const val CURRENT_OPENING_RADIUS_M = 44.0
    }
}
