package com.lifeinmist.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sinh

/**
 * Fast permanent cloud mask for unexplored territory.
 *
 * Runtime rendering is ONE cached cloud bitmap. While the map is panned/zoomed/rotated,
 * that bitmap is only transformed together with the map. The expensive work (cloud
 * composition + soft explored mask) is done only when the cache really needs rebuilding.
 * Cloud positions are deterministic in WebMercator world coordinates, so they stay tied
 * to geography when the cache is rebuilt.
 */
class FogOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) {
            field = value
            markDirty()
        }

    private var track: List<TrackPoint> = emptyList()
    private var currentLocation: LatLng? = null

    private var cacheBitmap: Bitmap? = null
    private var cacheCenter: LatLng? = null
    private var cacheZoom: Double = 0.0
    private var cacheBearing: Double = 0.0
    private var cacheDirty = true
    private var cameraMoving = false

    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    private val cloudSprites: List<Bitmap> by lazy {
        listOf(
            R.drawable.cloud_sprite_1,
            R.drawable.cloud_sprite_2,
            R.drawable.cloud_sprite_3,
            R.drawable.cloud_sprite_4,
            R.drawable.cloud_sprite_5,
            R.drawable.cloud_sprite_6,
            R.drawable.cloud_sprite_7,
            R.drawable.cloud_sprite_8
        ).map { BitmapFactory.decodeResource(resources, it) }
    }

    private val skyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(216, 190, 210, 224)
        style = Paint.Style.FILL
    }

    private val cloudPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = 236
    }

    private val featherPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        maskFilter = BlurMaskFilter(22f, BlurMaskFilter.Blur.NORMAL)
    }

    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val softCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        maskFilter = BlurMaskFilter(22f, BlurMaskFilter.Blur.NORMAL)
    }

    private val clearCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    init {
        isClickable = false
        isFocusable = false
        // Keep this View hardware accelerated. Blur/CLEAR work happens only on the
        // off-screen software bitmap when the cache is rebuilt.
    }

    fun setTrackPoints(points: List<TrackPoint>) {
        track = points
        markDirty()
    }

    fun setCurrentLocation(location: LatLng?) {
        currentLocation = location
        markDirty()
    }

    fun onCameraMove() {
        cameraMoving = true
        invalidate()
    }

    fun onCameraIdle() {
        cameraMoving = false
        // Always recenter the cached cloud sheet after a completed gesture.
        // Otherwise several small pans accumulate until the old cache edge becomes visible.
        rebuildCacheIfPossible(force = true)
        invalidate()
    }

    private fun markDirty() {
        cacheDirty = true
        if (!cameraMoving) {
            post {
                rebuildCacheIfPossible()
                invalidate()
            }
        } else {
            invalidate()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        cacheDirty = true
        if (w > 0 && h > 0) post { rebuildCacheIfPossible() }
    }

    override fun onDetachedFromWindow() {
        cacheBitmap?.recycle()
        cacheBitmap = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        if (cacheBitmap == null && !cameraMoving) rebuildCacheIfPossible()

        val bitmap = cacheBitmap ?: return
        val currentMap = map ?: return
        val cachedCenter = cacheCenter ?: return
        val camera = currentMap.cameraPosition
        val cachedCenterOnScreen = currentMap.projection.toScreenLocation(cachedCenter)
        val mapScale = 2.0.pow(camera.zoom - cacheZoom).toFloat().coerceIn(0.08f, 12f)
        val rotation = (camera.bearing - cacheBearing).toFloat()

        canvas.save()
        canvas.translate(cachedCenterOnScreen.x, cachedCenterOnScreen.y)
        if (rotation != 0f) canvas.rotate(rotation)
        canvas.scale(mapScale / CACHE_PIXEL_SCALE, mapScale / CACHE_PIXEL_SCALE)
        canvas.drawBitmap(bitmap, -bitmap.width / 2f, -bitmap.height / 2f, bitmapPaint)
        canvas.restore()
    }

    private fun cacheStillCoversView(): Boolean {
        val bitmap = cacheBitmap ?: return false
        val currentMap = map ?: return false
        val cachedCenter = cacheCenter ?: return false
        val camera = currentMap.cameraPosition
        val center = currentMap.projection.toScreenLocation(cachedCenter)
        val mapScale = 2.0.pow(camera.zoom - cacheZoom).toFloat()

        // Avoid stretching the cached texture too far. Rebuild only after the gesture.
        if (mapScale < 0.58f || mapScale > 1.72f) return false

        val shownW = bitmap.width / CACHE_PIXEL_SCALE * mapScale
        val shownH = bitmap.height / CACHE_PIXEL_SCALE * mapScale
        val left = center.x - shownW / 2f
        val right = center.x + shownW / 2f
        val top = center.y - shownH / 2f
        val bottom = center.y + shownH / 2f
        val margin = 8f
        return left <= -margin && right >= width + margin && top <= -margin && bottom >= height + margin
    }

    private fun rebuildCacheIfPossible(force: Boolean = false) {
        if (!force && !cacheDirty && cacheStillCoversView()) return
        if (cameraMoving) return
        val currentMap = map ?: return
        if (width <= 0 || height <= 0) return

        val camera = currentMap.cameraPosition
        val target = camera.target ?: return
        val cacheW = max(1, (width * CACHE_OVERSCAN * CACHE_PIXEL_SCALE).toInt())
        val cacheH = max(1, (height * CACHE_OVERSCAN * CACHE_PIXEL_SCALE).toInt())
        val newBitmap = Bitmap.createBitmap(cacheW, cacheH, Bitmap.Config.ARGB_8888)
        val offscreen = Canvas(newBitmap)

        val layer = offscreen.saveLayer(0f, 0f, cacheW.toFloat(), cacheH.toFloat(), null)
        offscreen.drawRect(0f, 0f, cacheW.toFloat(), cacheH.toFloat(), skyPaint)
        drawWorldAnchoredCloudLayer(offscreen, currentMap, camera.zoom, cacheW, cacheH)
        if (track.isNotEmpty()) drawExploredRoutes(offscreen, currentMap, cacheW, cacheH)
        currentLocation?.let { drawTemporaryOpening(offscreen, currentMap, it, cacheW, cacheH) }
        offscreen.restoreToCount(layer)

        val old = cacheBitmap
        cacheBitmap = newBitmap
        cacheCenter = LatLng(target.latitude, target.longitude)
        cacheZoom = camera.zoom
        cacheBearing = camera.bearing
        cacheDirty = false
        old?.recycle()
    }

    /**
     * One cloud layer, using the existing fluffy cloud sprites. Grid positions are fixed
     * in WebMercator world space. The cache therefore rebuilds without clouds jumping.
     */
    private fun drawWorldAnchoredCloudLayer(
        canvas: Canvas,
        currentMap: MapLibreMap,
        zoom: Double,
        cacheW: Int,
        cacheH: Int
    ) {
        if (cloudSprites.isEmpty()) return

        val cameraTarget = currentMap.cameraPosition.target ?: return
        val centerWorldX = lonToWorldX(cameraTarget.longitude)
        val centerWorldY = latToWorldY(cameraTarget.latitude)

        var stepWorld = BASE_STEP_WORLD
        var stepScreenPx = BASE_STEP_PX * 2.0.pow(zoom - BASE_ZOOM).toFloat()
        while (stepScreenPx < 105f) {
            stepWorld *= 2.0
            stepScreenPx *= 2f
        }

        val cols = ceil((width * CACHE_OVERSCAN) / stepScreenPx).toInt() + 6
        val rows = ceil((height * CACHE_OVERSCAN) / stepScreenPx).toInt() + 8
        val centerCol = floor(centerWorldX / stepWorld).toInt()
        val centerRow = floor(centerWorldY / stepWorld).toInt()
        val cloudSizeScreen = (BASE_CLOUD_PX * 2.0.pow(zoom - BASE_ZOOM)).toFloat().coerceIn(150f, 1500f)

        for (row in (centerRow - rows / 2)..(centerRow + rows / 2)) {
            for (col in (centerCol - cols / 2)..(centerCol + cols / 2)) {
                val hash = stableHash(row, col)
                val jitterX = (((hash ushr 5) and 255) / 255.0 - 0.5) * stepWorld * 0.54
                val jitterY = (((hash ushr 13) and 255) / 255.0 - 0.5) * stepWorld * 0.48
                val rowShift = if ((row and 1) == 0) 0.0 else stepWorld * 0.36
                val wx = wrapWorldX(col * stepWorld + rowShift + jitterX)
                val wy = (row * stepWorld + jitterY).coerceIn(0.000001, 0.999999)
                val latLng = LatLng(worldYToLat(wy), worldXToLon(wx))
                val screen = currentMap.projection.toScreenLocation(latLng)
                val p = screenToCache(screen.x, screen.y, cacheW, cacheH)

                val variation = 0.78f + ((hash ushr 21) and 31) / 100f
                val size = cloudSizeScreen * variation * CACHE_PIXEL_SCALE
                val rotation = (((hash ushr 2) and 63) - 31).toFloat() * 0.55f
                val sprite = cloudSprites[(hash and Int.MAX_VALUE) % cloudSprites.size]
                drawCloudSprite(canvas, sprite, p.first, p.second, size, rotation)
            }
        }
    }

    private fun drawCloudSprite(
        canvas: Canvas,
        bitmap: Bitmap,
        centerX: Float,
        centerY: Float,
        widthPx: Float,
        rotation: Float
    ) {
        if (bitmap.width <= 0 || bitmap.height <= 0) return
        val aspect = bitmap.height.toFloat() / bitmap.width.toFloat()
        val cloudW = widthPx
        val cloudH = widthPx * aspect
        val left = centerX - cloudW / 2f
        val top = centerY - cloudH / 2f

        canvas.save()
        canvas.rotate(rotation, centerX, centerY)
        canvas.drawBitmap(bitmap, null, RectF(left, top, left + cloudW, top + cloudH), cloudPaint)
        canvas.restore()
    }

    private fun drawExploredRoutes(canvas: Canvas, currentMap: MapLibreMap, cacheW: Int, cacheH: Int) {
        val grouped = track.groupBy { it.walkId }
        for (walkPoints in grouped.values) {
            if (walkPoints.isEmpty()) continue

            val path = Path()
            var started = false
            var representativeRadiusPx = 22f * CACHE_PIXEL_SCALE

            for (point in walkPoints) {
                val screen = currentMap.projection.toScreenLocation(LatLng(point.latitude, point.longitude))
                val p = screenToCache(screen.x, screen.y, cacheW, cacheH)
                if (!started) {
                    path.moveTo(p.first, p.second)
                    representativeRadiusPx = radiusMetersToPixels(
                        currentMap,
                        point.latitude,
                        point.longitude,
                        REVEAL_RADIUS_M
                    ) * CACHE_PIXEL_SCALE
                    started = true
                } else {
                    path.lineTo(p.first, p.second)
                }
            }
            if (!started) continue

            val coreWidth = (representativeRadiusPx * 2f).coerceIn(9f, 550f)
            featherPaint.strokeWidth = (coreWidth + 42f).coerceAtMost(600f)
            clearPaint.strokeWidth = coreWidth
            canvas.drawPath(path, featherPaint)
            canvas.drawPath(path, clearPaint)

            if (walkPoints.size == 1) {
                val only = walkPoints.first()
                val screen = currentMap.projection.toScreenLocation(LatLng(only.latitude, only.longitude))
                val p = screenToCache(screen.x, screen.y, cacheW, cacheH)
                clearCircle(canvas, p.first, p.second, representativeRadiusPx)
            }
        }
    }

    private fun drawTemporaryOpening(
        canvas: Canvas,
        currentMap: MapLibreMap,
        location: LatLng,
        cacheW: Int,
        cacheH: Int
    ) {
        val screen = currentMap.projection.toScreenLocation(location)
        val p = screenToCache(screen.x, screen.y, cacheW, cacheH)
        val radius = (radiusMetersToPixels(
            currentMap,
            location.latitude,
            location.longitude,
            CURRENT_OPENING_RADIUS_M
        ) * CACHE_PIXEL_SCALE).coerceAtLeast(17f)
        clearCircle(canvas, p.first, p.second, radius)
    }

    private fun screenToCache(x: Float, y: Float, cacheW: Int, cacheH: Int): Pair<Float, Float> {
        val cx = (x - width / 2f) * CACHE_PIXEL_SCALE + cacheW / 2f
        val cy = (y - height / 2f) * CACHE_PIXEL_SCALE + cacheH / 2f
        return cx to cy
    }

    private fun clearCircle(canvas: Canvas, x: Float, y: Float, radius: Float) {
        canvas.drawCircle(x, y, radius + 22f, softCirclePaint)
        canvas.drawCircle(x, y, radius, clearCirclePaint)
    }

    private fun radiusMetersToPixels(map: MapLibreMap, lat: Double, lon: Double, radiusM: Double): Float {
        val center = map.projection.toScreenLocation(LatLng(lat, lon))
        val latitudeDelta = radiusM / 111_320.0
        val north = map.projection.toScreenLocation(LatLng(lat + latitudeDelta, lon))
        return abs(center.y - north.y).coerceIn(6f, 560f)
    }

    private fun stableHash(a: Int, b: Int): Int {
        var x = a * 0x45d9f3b + b * 0x27d4eb2d
        x = x xor (x ushr 16)
        x *= 0x45d9f3b
        x = x xor (x ushr 16)
        return x
    }

    private fun lonToWorldX(lon: Double): Double = (lon + 180.0) / 360.0

    private fun latToWorldY(lat: Double): Double {
        val clamped = lat.coerceIn(-85.05112878, 85.05112878)
        val rad = Math.toRadians(clamped)
        return (1.0 - ln(kotlin.math.tan(rad) + 1.0 / kotlin.math.cos(rad)) / PI) / 2.0
    }

    private fun worldXToLon(x: Double): Double = wrapWorldX(x) * 360.0 - 180.0

    private fun worldYToLat(y: Double): Double {
        val n = PI * (1.0 - 2.0 * y)
        return Math.toDegrees(atan(sinh(n)))
    }

    private fun wrapWorldX(value: Double): Double {
        var x = value % 1.0
        if (x < 0.0) x += 1.0
        return x
    }

    companion object {
        private const val REVEAL_RADIUS_M = 30.0
        private const val CURRENT_OPENING_RADIUS_M = 44.0

        // A large overscan gives the cached sheet enough off-screen margin for a full swipe.
        // Lower internal resolution keeps memory/GPU cost close to the previous implementation.
        private const val CACHE_PIXEL_SCALE = 0.40f
        private const val CACHE_OVERSCAN = 2.80f

        private const val BASE_ZOOM = 15.0
        private const val BASE_STEP_PX = 245f
        private const val BASE_CLOUD_PX = 430f
        private const val BASE_STEP_WORLD = 245.0 / (256.0 * 32768.0) // zoom 15 world step
    }
}
