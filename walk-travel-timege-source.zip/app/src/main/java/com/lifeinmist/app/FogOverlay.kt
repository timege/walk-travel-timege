package com.lifeinmist.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import kotlin.math.abs
import kotlin.math.max

/**
 * Permanent cloud layer for unexplored territory.
 *
 * v0.5.9 replaces the old washed-out wallpaper layer with a field of reusable
 * transparent cloud sprites. Unexplored territory is fully covered by an
 * atmospheric base + several layers of cloud masses. Permanently explored GPS
 * corridors are then cut out of that composite with a soft feathered edge.
 */
class FogOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) {
            field = value
            invalidate()
        }

    private var track: List<TrackPoint> = emptyList()
    private var currentLocation: LatLng? = null

    private val cloudSprites: List<Bitmap> by lazy {
        listOf(
            R.drawable.cloud_sprite_1,
            R.drawable.cloud_sprite_2,
            R.drawable.cloud_sprite_3,
            R.drawable.cloud_sprite_4,
            R.drawable.cloud_sprite_5,
            R.drawable.cloud_sprite_6,
            R.drawable.cloud_sprite_7,
            R.drawable.cloud_sprite_8
        ).map { BitmapFactory.decodeResource(resources, it) }
    }

    // Opaque enough to hide the unexplored map even where transparent cloud
    // sprites do not fully overlap. It reads as open sky between cloud masses.
    private val skyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(236, 190, 211, 224)
        style = Paint.Style.FILL
    }

    private val farCloudPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = 205
    }

    private val middleCloudPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = 232
    }

    private val nearCloudPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = 252
    }

    private val featherPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        maskFilter = BlurMaskFilter(38f, BlurMaskFilter.Blur.NORMAL)
    }

    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val softCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        maskFilter = BlurMaskFilter(38f, BlurMaskFilter.Blur.NORMAL)
    }

    private val clearCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    init {
        isClickable = false
        isFocusable = false
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun setTrackPoints(points: List<TrackPoint>) {
        track = points
        invalidate()
    }

    fun setCurrentLocation(location: LatLng?) {
        currentLocation = location
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        val layer = canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)

        // Close the unexplored map first, then build visible 3-D cloud masses on
        // top. The cloud field is deterministic so it does not flicker between
        // frames while zooming or moving.
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), skyPaint)
        drawCloudField(canvas)

        map?.let { currentMap ->
            if (track.isNotEmpty()) drawExploredRoutes(canvas, currentMap)
            currentLocation?.let { drawTemporaryOpening(canvas, currentMap, it) }
        }

        canvas.restoreToCount(layer)
    }

    private fun drawCloudField(canvas: Canvas) {
        if (cloudSprites.isEmpty()) return

        val w = width.toFloat()
        val h = height.toFloat()

        // Back layer: larger, softer masses. Rows are offset so the eye never
        // sees a tiled grid. Numbers are fractions of current view dimensions.
        val backRows = 5
        val backCols = 3
        for (row in 0 until backRows) {
            for (col in 0 until backCols) {
                val index = (row * backCols + col) % cloudSprites.size
                val x = w * (-0.03f + col * 0.39f + if (row % 2 == 0) 0.02f else 0.16f)
                val y = h * (-0.06f + row * 0.245f)
                val scale = w * (0.43f + ((index * 17 + row * 11) % 9) * 0.014f)
                val rotation = ((index * 29 + row * 13 + col * 7) % 34 - 17).toFloat()
                drawCloudSprite(canvas, cloudSprites[index], x, y, scale, rotation, farCloudPaint)
            }
        }

        // Middle layer: gives the cloud cover depth and prevents obvious gaps.
        val middleRows = 6
        val middleCols = 4
        for (row in 0 until middleRows) {
            for (col in 0 until middleCols) {
                val index = (row * 5 + col * 3 + 2) % cloudSprites.size
                val x = w * (-0.11f + col * 0.31f + if (row % 2 == 0) 0.0f else 0.10f)
                val y = h * (-0.08f + row * 0.205f)
                val scale = w * (0.31f + ((index * 19 + col * 5) % 8) * 0.012f)
                val rotation = ((index * 23 + row * 17 + col * 9) % 42 - 21).toFloat()
                drawCloudSprite(canvas, cloudSprites[index], x, y, scale, rotation, middleCloudPaint)
            }
        }

        // Foreground accents: fewer dense puffs create natural, irregular cloud
        // banks around the clear explored windows.
        val accents = arrayOf(
            floatArrayOf(-0.10f, 0.02f, 0.38f, -8f),
            floatArrayOf(0.64f, 0.08f, 0.40f, 11f),
            floatArrayOf(0.08f, 0.30f, 0.34f, 16f),
            floatArrayOf(0.72f, 0.36f, 0.37f, -14f),
            floatArrayOf(-0.06f, 0.58f, 0.41f, 7f),
            floatArrayOf(0.61f, 0.66f, 0.43f, -12f),
            floatArrayOf(0.12f, 0.83f, 0.39f, 14f),
            floatArrayOf(0.67f, 0.88f, 0.36f, -6f)
        )
        accents.forEachIndexed { i, a ->
            drawCloudSprite(
                canvas,
                cloudSprites[(i * 3 + 1) % cloudSprites.size],
                w * a[0],
                h * a[1],
                w * a[2],
                a[3],
                nearCloudPaint
            )
        }
    }

    private fun drawCloudSprite(
        canvas: Canvas,
        bitmap: Bitmap,
        left: Float,
        top: Float,
        size: Float,
        rotation: Float,
        paint: Paint
    ) {
        if (bitmap.width <= 0 || bitmap.height <= 0) return
        val aspect = bitmap.height.toFloat() / bitmap.width.toFloat()
        val cloudW = size
        val cloudH = size * aspect
        val cx = left + cloudW / 2f
        val cy = top + cloudH / 2f

        canvas.save()
        canvas.rotate(rotation, cx, cy)
        canvas.drawBitmap(bitmap, null, RectF(left, top, left + cloudW, top + cloudH), paint)
        canvas.restore()
    }

    private fun drawExploredRoutes(canvas: Canvas, currentMap: MapLibreMap) {
        val grouped = track.groupBy { it.walkId }
        for (walkPoints in grouped.values) {
            if (walkPoints.isEmpty()) continue

            val path = Path()
            var started = false
            var representativeRadiusPx = 22f

            for (point in walkPoints) {
                val screen = currentMap.projection.toScreenLocation(LatLng(point.latitude, point.longitude))
                if (!started) {
                    path.moveTo(screen.x, screen.y)
                    representativeRadiusPx = radiusMetersToPixels(
                        currentMap,
                        point.latitude,
                        point.longitude,
                        REVEAL_RADIUS_M
                    )
                    started = true
                } else {
                    path.lineTo(screen.x, screen.y)
                }
            }
            if (!started) continue

            val coreWidth = (representativeRadiusPx * 2f).coerceIn(18f, 1100f)
            featherPaint.strokeWidth = (coreWidth + 78f).coerceAtMost(1180f)
            clearPaint.strokeWidth = coreWidth
            canvas.drawPath(path, featherPaint)
            canvas.drawPath(path, clearPaint)

            if (walkPoints.size == 1) {
                val only = walkPoints.first()
                val center = currentMap.projection.toScreenLocation(LatLng(only.latitude, only.longitude))
                clearCircle(canvas, center.x, center.y, representativeRadiusPx)
            }
        }
    }

    private fun drawTemporaryOpening(canvas: Canvas, currentMap: MapLibreMap, location: LatLng) {
        val center = currentMap.projection.toScreenLocation(location)
        val radius = radiusMetersToPixels(
            currentMap,
            location.latitude,
            location.longitude,
            CURRENT_OPENING_RADIUS_M
        ).coerceAtLeast(34f)
        clearCircle(canvas, center.x, center.y, radius)
    }

    private fun clearCircle(canvas: Canvas, x: Float, y: Float, radius: Float) {
        canvas.drawCircle(x, y, radius + 38f, softCirclePaint)
        canvas.drawCircle(x, y, radius, clearCirclePaint)
    }

    private fun radiusMetersToPixels(map: MapLibreMap, lat: Double, lon: Double, radiusM: Double): Float {
        val center = map.projection.toScreenLocation(LatLng(lat, lon))
        val latitudeDelta = radiusM / 111_320.0
        val north = map.projection.toScreenLocation(LatLng(lat + latitudeDelta, lon))
        return abs(center.y - north.y).coerceIn(6f, 560f)
    }

    companion object {
        private const val REVEAL_RADIUS_M = 30.0
        private const val CURRENT_OPENING_RADIUS_M = 44.0
    }
}
