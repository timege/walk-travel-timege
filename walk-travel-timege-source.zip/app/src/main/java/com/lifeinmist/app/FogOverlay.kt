package com.lifeinmist.app

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import kotlin.math.abs

/**
 * Permanent "clouds of the unexplored world" layer.
 * All persisted track points are cut out of this layer. The current position also gets a
 * temporary small opening so the user can always see where they are before recording starts.
 */
class FogOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) {
            field = value
            invalidate()
        }

    private var track: List<TrackPoint> = emptyList()
    private var currentLocation: LatLng? = null

    private val veilPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(150, 244, 248, 242)
        style = Paint.Style.FILL
    }

    private val cloudShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(42, 109, 132, 113)
        style = Paint.Style.FILL
        maskFilter = BlurMaskFilter(28f, BlurMaskFilter.Blur.NORMAL)
    }

    private val featherPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        maskFilter = BlurMaskFilter(28f, BlurMaskFilter.Blur.NORMAL)
    }

    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    init {
        isClickable = false
        isFocusable = false
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun setTrackPoints(points: List<TrackPoint>) {
        track = points
        invalidate()
    }

    fun setCurrentLocation(location: LatLng?) {
        currentLocation = location
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        val layer = canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)

        // A pale base keeps the unexplored map only slightly visible below the cloud field.
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), veilPaint)
        drawCloudField(canvas)

        map?.let { currentMap ->
            if (track.isNotEmpty()) drawExploredRoutes(canvas, currentMap)
            currentLocation?.let { drawTemporaryOpening(canvas, currentMap, it) }
        }

        canvas.restoreToCount(layer)
    }

    private fun drawCloudField(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val base = (w.coerceAtMost(h) / 7.0f).coerceAtLeast(58f)

        // Irregular multi-puff clusters make the unexplored area read as clouds rather than circles.
        val anchors = arrayOf(
            floatArrayOf(-0.05f, 0.05f, 1.25f), floatArrayOf(0.18f, 0.03f, 1.05f),
            floatArrayOf(0.46f, 0.07f, 1.18f), floatArrayOf(0.76f, 0.04f, 1.12f),
            floatArrayOf(1.02f, 0.12f, 1.22f), floatArrayOf(0.02f, 0.27f, 1.14f),
            floatArrayOf(0.32f, 0.29f, 1.08f), floatArrayOf(0.68f, 0.30f, 1.20f),
            floatArrayOf(0.96f, 0.37f, 1.14f), floatArrayOf(-0.03f, 0.51f, 1.17f),
            floatArrayOf(0.23f, 0.56f, 1.06f), floatArrayOf(0.52f, 0.58f, 1.16f),
            floatArrayOf(0.82f, 0.56f, 1.12f), floatArrayOf(1.03f, 0.66f, 1.20f),
            floatArrayOf(0.03f, 0.79f, 1.18f), floatArrayOf(0.31f, 0.84f, 1.10f),
            floatArrayOf(0.64f, 0.85f, 1.17f), floatArrayOf(0.94f, 0.84f, 1.13f),
            floatArrayOf(0.14f, 1.02f, 1.18f), floatArrayOf(0.48f, 1.02f, 1.10f),
            floatArrayOf(0.81f, 1.03f, 1.19f)
        )

        anchors.forEachIndexed { index, a ->
            drawCloudCluster(canvas, a[0] * w, a[1] * h, base * a[2], index)
        }
    }

    private fun drawCloudCluster(canvas: Canvas, cx: Float, cy: Float, radius: Float, variant: Int) {
        canvas.drawCircle(cx + radius * 0.08f, cy + radius * 0.22f, radius * 1.18f, cloudShadowPaint)

        val puffs = arrayOf(
            floatArrayOf(0.00f, 0.10f, 1.00f),
            floatArrayOf(-0.62f, 0.18f, 0.72f),
            floatArrayOf(0.62f, 0.14f, 0.78f),
            floatArrayOf(-0.30f, -0.42f, 0.70f),
            floatArrayOf(0.25f, -0.50f, 0.76f),
            floatArrayOf(0.72f, -0.27f, 0.58f),
            floatArrayOf(-0.78f, -0.20f, 0.52f)
        )
        puffs.forEachIndexed { i, puff ->
            drawCloudPuff(
                canvas,
                cx + radius * puff[0],
                cy + radius * puff[1],
                radius * puff[2],
                variant + i
            )
        }
    }

    private fun drawCloudPuff(canvas: Canvas, cx: Float, cy: Float, radius: Float, variant: Int) {
        val center = when (variant % 4) {
            0 -> Color.argb(246, 255, 255, 255)
            1 -> Color.argb(242, 248, 251, 247)
            2 -> Color.argb(238, 237, 242, 237)
            else -> Color.argb(244, 250, 252, 248)
        }
        val edge = when (variant % 3) {
            0 -> Color.argb(115, 204, 216, 207)
            1 -> Color.argb(108, 222, 231, 221)
            else -> Color.argb(110, 213, 225, 215)
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                cx - radius * 0.18f,
                cy - radius * 0.20f,
                radius,
                intArrayOf(center, center, edge, Color.TRANSPARENT),
                floatArrayOf(0f, 0.45f, 0.82f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawCircle(cx, cy, radius, paint)
    }

    private fun drawExploredRoutes(canvas: Canvas, currentMap: MapLibreMap) {
        val grouped = track.groupBy { it.walkId }
        for (walkPoints in grouped.values) {
            if (walkPoints.isEmpty()) continue

            val path = Path()
            var started = false
            var representativeRadiusPx = 24f

            for (point in walkPoints) {
                val screen = currentMap.projection.toScreenLocation(LatLng(point.latitude, point.longitude))
                if (!started) {
                    path.moveTo(screen.x, screen.y)
                    representativeRadiusPx = radiusMetersToPixels(
                        currentMap,
                        point.latitude,
                        point.longitude,
                        REVEAL_RADIUS_M
                    )
                    started = true
                } else {
                    path.lineTo(screen.x, screen.y)
                }
            }
            if (!started) continue

            val coreWidth = (representativeRadiusPx * 2f).coerceIn(18f, 1400f)
            featherPaint.strokeWidth = (coreWidth + 58f).coerceAtMost(1460f)
            clearPaint.strokeWidth = coreWidth
            canvas.drawPath(path, featherPaint)
            canvas.drawPath(path, clearPaint)

            if (walkPoints.size == 1) {
                val only = walkPoints.first()
                val center = currentMap.projection.toScreenLocation(LatLng(only.latitude, only.longitude))
                clearCircle(canvas, center.x, center.y, representativeRadiusPx)
            }
        }
    }

    private fun drawTemporaryOpening(canvas: Canvas, currentMap: MapLibreMap, location: LatLng) {
        val center = currentMap.projection.toScreenLocation(location)
        val radius = radiusMetersToPixels(
            currentMap,
            location.latitude,
            location.longitude,
            CURRENT_OPENING_RADIUS_M
        ).coerceAtLeast(34f)
        clearCircle(canvas, center.x, center.y, radius)
    }

    private fun clearCircle(canvas: Canvas, x: Float, y: Float, radius: Float) {
        val soft = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.WHITE
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
            maskFilter = BlurMaskFilter(30f, BlurMaskFilter.Blur.NORMAL)
        }
        val clear = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.WHITE
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
        canvas.drawCircle(x, y, radius + 28f, soft)
        canvas.drawCircle(x, y, radius, clear)
    }

    private fun radiusMetersToPixels(map: MapLibreMap, lat: Double, lon: Double, radiusM: Double): Float {
        val center = map.projection.toScreenLocation(LatLng(lat, lon))
        val latitudeDelta = radiusM / 111_320.0
        val north = map.projection.toScreenLocation(LatLng(lat + latitudeDelta, lon))
        return abs(center.y - north.y).coerceIn(7f, 700f)
    }

    companion object {
        private const val REVEAL_RADIUS_M = 32.0
        private const val CURRENT_OPENING_RADIUS_M = 46.0
    }
}
