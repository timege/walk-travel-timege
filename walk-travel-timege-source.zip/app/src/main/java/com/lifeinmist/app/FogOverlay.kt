package com.lifeinmist.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Permanent cloud layer for unexplored territory.
 *
 * v0.6.0 uses five independently drifting cloud layers. The animation is deliberately
 * slow and low-frequency so the cloud field feels alive without becoming a battery-heavy
 * weather animation. Explored GPS corridors are cut out of the complete cloud composite.
 */
class FogOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) {
            field = value
            invalidate()
        }

    private var track: List<TrackPoint> = emptyList()
    private var currentLocation: LatLng? = null
    private val animationStartMs = SystemClock.uptimeMillis()

    private val cloudSprites: List<Bitmap> by lazy {
        listOf(
            R.drawable.cloud_sprite_1,
            R.drawable.cloud_sprite_2,
            R.drawable.cloud_sprite_3,
            R.drawable.cloud_sprite_4,
            R.drawable.cloud_sprite_5,
            R.drawable.cloud_sprite_6,
            R.drawable.cloud_sprite_7,
            R.drawable.cloud_sprite_8
        ).map { BitmapFactory.decodeResource(resources, it) }
    }

    // This closes unexplored territory between individual cloud masses. It is intentionally
    // pale and cool, but explored areas are cut completely through it to the actual map.
    private val skyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(224, 190, 210, 224)
        style = Paint.Style.FILL
    }

    private val layerPaints = listOf(
        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = 118 },
        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = 154 },
        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = 192 },
        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = 224 },
        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = 246 }
    )

    private val featherPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        maskFilter = BlurMaskFilter(38f, BlurMaskFilter.Blur.NORMAL)
    }

    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val softCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        maskFilter = BlurMaskFilter(38f, BlurMaskFilter.Blur.NORMAL)
    }

    private val clearCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val animationTick = object : Runnable {
        override fun run() {
            if (!isAttachedToWindow) return
            invalidate()
            // About 6 fps is enough for very slow cloud drift and materially cheaper than 60 fps.
            postDelayed(this, 165L)
        }
    }

    init {
        isClickable = false
        isFocusable = false
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        removeCallbacks(animationTick)
        post(animationTick)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(animationTick)
        super.onDetachedFromWindow()
    }

    fun setTrackPoints(points: List<TrackPoint>) {
        track = points
        invalidate()
    }

    fun setCurrentLocation(location: LatLng?) {
        currentLocation = location
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        val layer = canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)

        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), skyPaint)
        drawCloudField(canvas)

        map?.let { currentMap ->
            if (track.isNotEmpty()) drawExploredRoutes(canvas, currentMap)
            currentLocation?.let { drawTemporaryOpening(canvas, currentMap, it) }
        }

        canvas.restoreToCount(layer)
    }

    /** Five cloud layers with distinct scale, opacity and very slow drift. */
    private fun drawCloudField(canvas: Canvas) {
        if (cloudSprites.isEmpty()) return

        val seconds = (SystemClock.uptimeMillis() - animationStartMs) / 1000f

        drawGridLayer(
            canvas = canvas,
            layerIndex = 0,
            rows = 4,
            cols = 3,
            scaleFraction = 0.56f,
            xStep = 0.43f,
            yStep = 0.31f,
            baseX = -0.18f,
            baseY = -0.14f,
            driftX = sin(seconds * 0.030f) * 10f,
            driftY = cos(seconds * 0.024f) * 5f
        )
        drawGridLayer(
            canvas = canvas,
            layerIndex = 1,
            rows = 5,
            cols = 3,
            scaleFraction = 0.46f,
            xStep = 0.39f,
            yStep = 0.255f,
            baseX = -0.12f,
            baseY = -0.10f,
            driftX = cos(seconds * 0.038f) * 8f,
            driftY = sin(seconds * 0.028f) * 6f
        )
        drawGridLayer(
            canvas = canvas,
            layerIndex = 2,
            rows = 6,
            cols = 4,
            scaleFraction = 0.35f,
            xStep = 0.31f,
            yStep = 0.215f,
            baseX = -0.11f,
            baseY = -0.08f,
            driftX = sin(seconds * 0.045f) * 7f,
            driftY = cos(seconds * 0.035f) * 6f
        )
        drawGridLayer(
            canvas = canvas,
            layerIndex = 3,
            rows = 6,
            cols = 4,
            scaleFraction = 0.29f,
            xStep = 0.30f,
            yStep = 0.205f,
            baseX = -0.10f,
            baseY = -0.07f,
            driftX = cos(seconds * 0.052f) * 6f,
            driftY = sin(seconds * 0.041f) * 5f
        )

        // Foreground banks are intentionally sparse and large so the edges around explored
        // windows look like cloud masses rather than a repeating texture.
        val w = width.toFloat()
        val h = height.toFloat()
        val dx = sin(seconds * 0.060f) * 5f
        val dy = cos(seconds * 0.047f) * 4f
        val accents = arrayOf(
            floatArrayOf(-0.16f, 0.00f, 0.46f, -10f),
            floatArrayOf(0.58f, 0.04f, 0.45f, 11f),
            floatArrayOf(-0.12f, 0.30f, 0.42f, 13f),
            floatArrayOf(0.66f, 0.34f, 0.43f, -15f),
            floatArrayOf(-0.15f, 0.61f, 0.49f, 7f),
            floatArrayOf(0.60f, 0.66f, 0.48f, -11f),
            floatArrayOf(0.04f, 0.86f, 0.43f, 12f),
            floatArrayOf(0.64f, 0.87f, 0.40f, -8f)
        )
        accents.forEachIndexed { i, a ->
            drawCloudSprite(
                canvas,
                cloudSprites[(i * 3 + 1) % cloudSprites.size],
                w * a[0] + dx,
                h * a[1] + dy,
                w * a[2],
                a[3],
                layerPaints[4]
            )
        }
    }

    private fun drawGridLayer(
        canvas: Canvas,
        layerIndex: Int,
        rows: Int,
        cols: Int,
        scaleFraction: Float,
        xStep: Float,
        yStep: Float,
        baseX: Float,
        baseY: Float,
        driftX: Float,
        driftY: Float
    ) {
        val w = width.toFloat()
        val h = height.toFloat()
        val paint = layerPaints[layerIndex]
        for (row in 0 until rows) {
            for (col in 0 until cols) {
                val index = (layerIndex * 7 + row * 5 + col * 3) % cloudSprites.size
                val rowOffset = if (row % 2 == 0) 0f else xStep * 0.33f
                val x = w * (baseX + col * xStep + rowOffset) + driftX
                val y = h * (baseY + row * yStep) + driftY
                val variation = ((index * 17 + row * 11 + col * 7 + layerIndex * 13) % 9) * 0.012f
                val scale = w * (scaleFraction + variation)
                val rotation = ((index * 29 + row * 13 + col * 9 + layerIndex * 5) % 42 - 21).toFloat()
                drawCloudSprite(canvas, cloudSprites[index], x, y, scale, rotation, paint)
            }
        }
    }

    private fun drawCloudSprite(
        canvas: Canvas,
        bitmap: Bitmap,
        left: Float,
        top: Float,
        size: Float,
        rotation: Float,
        paint: Paint
    ) {
        if (bitmap.width <= 0 || bitmap.height <= 0) return
        val aspect = bitmap.height.toFloat() / bitmap.width.toFloat()
        val cloudW = size
        val cloudH = size * aspect
        val cx = left + cloudW / 2f
        val cy = top + cloudH / 2f

        canvas.save()
        canvas.rotate(rotation, cx, cy)
        canvas.drawBitmap(bitmap, null, RectF(left, top, left + cloudW, top + cloudH), paint)
        canvas.restore()
    }

    private fun drawExploredRoutes(canvas: Canvas, currentMap: MapLibreMap) {
        val grouped = track.groupBy { it.walkId }
        for (walkPoints in grouped.values) {
            if (walkPoints.isEmpty()) continue

            val path = Path()
            var started = false
            var representativeRadiusPx = 22f

            for (point in walkPoints) {
                val screen = currentMap.projection.toScreenLocation(LatLng(point.latitude, point.longitude))
                if (!started) {
                    path.moveTo(screen.x, screen.y)
                    representativeRadiusPx = radiusMetersToPixels(
                        currentMap,
                        point.latitude,
                        point.longitude,
                        REVEAL_RADIUS_M
                    )
                    started = true
                } else {
                    path.lineTo(screen.x, screen.y)
                }
            }
            if (!started) continue

            val coreWidth = (representativeRadiusPx * 2f).coerceIn(18f, 1100f)
            featherPaint.strokeWidth = (coreWidth + 78f).coerceAtMost(1180f)
            clearPaint.strokeWidth = coreWidth
            canvas.drawPath(path, featherPaint)
            canvas.drawPath(path, clearPaint)

            if (walkPoints.size == 1) {
                val only = walkPoints.first()
                val center = currentMap.projection.toScreenLocation(LatLng(only.latitude, only.longitude))
                clearCircle(canvas, center.x, center.y, representativeRadiusPx)
            }
        }
    }

    private fun drawTemporaryOpening(canvas: Canvas, currentMap: MapLibreMap, location: LatLng) {
        val center = currentMap.projection.toScreenLocation(location)
        val radius = radiusMetersToPixels(
            currentMap,
            location.latitude,
            location.longitude,
            CURRENT_OPENING_RADIUS_M
        ).coerceAtLeast(34f)
        clearCircle(canvas, center.x, center.y, radius)
    }

    private fun clearCircle(canvas: Canvas, x: Float, y: Float, radius: Float) {
        canvas.drawCircle(x, y, radius + 38f, softCirclePaint)
        canvas.drawCircle(x, y, radius, clearCirclePaint)
    }

    private fun radiusMetersToPixels(map: MapLibreMap, lat: Double, lon: Double, radiusM: Double): Float {
        val center = map.projection.toScreenLocation(LatLng(lat, lon))
        val latitudeDelta = radiusM / 111_320.0
        val north = map.projection.toScreenLocation(LatLng(lat + latitudeDelta, lon))
        return abs(center.y - north.y).coerceIn(6f, 560f)
    }

    companion object {
        private const val REVEAL_RADIUS_M = 30.0
        private const val CURRENT_OPENING_RADIUS_M = 44.0
    }
}
