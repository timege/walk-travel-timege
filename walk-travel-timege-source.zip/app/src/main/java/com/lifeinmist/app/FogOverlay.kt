package com.lifeinmist.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import kotlin.math.abs

class FogOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) {
            field = value
            invalidate()
        }

    private var explored: List<ExploredPoint> = emptyList()

    private val fogPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(17, 19, 23)
        alpha = 238
        style = Paint.Style.FILL
    }

    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        style = Paint.Style.FILL
    }

    init {
        isClickable = false
        isFocusable = false
        // CLEAR compositing is reliable when the overlay owns a software layer.
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun setExploredPoints(points: List<ExploredPoint>) {
        explored = points
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val layer = canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fogPaint)

        val currentMap = map
        if (currentMap != null) {
            for (point in explored) {
                val center = currentMap.projection.toScreenLocation(LatLng(point.latitude, point.longitude))
                if (center.x < -800 || center.x > width + 800 || center.y < -800 || center.y > height + 800) continue

                val latitudeDelta = point.radiusM / 111_320.0
                val north = currentMap.projection.toScreenLocation(
                    LatLng(point.latitude + latitudeDelta, point.longitude)
                )
                val radiusPx = abs(center.y - north.y).coerceIn(4f, 700f)
                canvas.drawCircle(center.x, center.y, radiusPx, clearPaint)
            }
        }

        canvas.restoreToCount(layer)
    }
}
