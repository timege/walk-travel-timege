package com.lifeinmist.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sinh

/**
 * Lightweight permanent fog for unexplored territory.
 *
 * This version intentionally avoids many sprite clouds / runtime blur layers.
 * It uses one cached bitmap with:
 * 1) soft fog color fill
 * 2) repeated lightweight fog texture tiles anchored to world coordinates
 * 3) explored routes cut out from the fog with soft edges
 *
 * During pan / zoom / rotate the app only transforms ONE cached bitmap, which is
 * much lighter than rebuilding a field of cloud sprites every frame.
 */
class FogOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) {
            field = value
            markDirty()
        }

    private var track: List<TrackPoint> = emptyList()
    private var currentLocation: LatLng? = null

    private var cacheBitmap: Bitmap? = null
    private var cacheCenter: LatLng? = null
    private var cacheZoom: Double = 0.0
    private var cacheBearing: Double = 0.0
    private var cacheDirty = true
    private var cameraMoving = false

    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    private val fogFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(178, 214, 224, 236)
        style = Paint.Style.FILL
    }

    private val fogTilePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = 230
    }

    private val fogSoftLightPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = 150
    }

    private val edgeFeatherPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    }

    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val softCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    }

    private val clearCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val fogTileBitmap: Bitmap by lazy {
        buildFogTileBitmap(220)
    }

    init {
        isClickable = false
        isFocusable = false
    }

    fun setTrackPoints(points: List<TrackPoint>) {
        track = points
        markDirty()
    }

    fun setCurrentLocation(location: LatLng?) {
        currentLocation = location
        markDirty()
    }

    fun onCameraMove() {
        cameraMoving = true
        invalidate()
    }

    fun onCameraIdle() {
        cameraMoving = false
        rebuildCacheIfPossible(force = true)
        invalidate()
    }

    private fun markDirty() {
        cacheDirty = true
        if (!cameraMoving) {
            post {
                rebuildCacheIfPossible()
                invalidate()
            }
        } else {
            invalidate()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        cacheDirty = true
        if (w > 0 && h > 0) post { rebuildCacheIfPossible() }
    }

    override fun onDetachedFromWindow() {
        cacheBitmap?.recycle()
        cacheBitmap = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        if (cacheBitmap == null && !cameraMoving) rebuildCacheIfPossible()

        val bitmap = cacheBitmap ?: return
        val currentMap = map ?: return
        val cachedCenter = cacheCenter ?: return
        val camera = currentMap.cameraPosition
        val cachedCenterOnScreen = currentMap.projection.toScreenLocation(cachedCenter)
        val mapScale = 2.0.pow(camera.zoom - cacheZoom).toFloat().coerceIn(0.08f, 12f)
        val rotation = (camera.bearing - cacheBearing).toFloat()

        canvas.save()
        canvas.translate(cachedCenterOnScreen.x, cachedCenterOnScreen.y)
        if (rotation != 0f) canvas.rotate(rotation)
        canvas.scale(mapScale / CACHE_PIXEL_SCALE, mapScale / CACHE_PIXEL_SCALE)
        canvas.drawBitmap(bitmap, -bitmap.width / 2f, -bitmap.height / 2f, bitmapPaint)
        canvas.restore()
    }

    private fun cacheStillCoversView(): Boolean {
        val bitmap = cacheBitmap ?: return false
        val currentMap = map ?: return false
        val cachedCenter = cacheCenter ?: return false
        val camera = currentMap.cameraPosition
        val center = currentMap.projection.toScreenLocation(cachedCenter)
        val mapScale = 2.0.pow(camera.zoom - cacheZoom).toFloat()

        if (mapScale < 0.58f || mapScale > 1.72f) return false

        val shownW = bitmap.width / CACHE_PIXEL_SCALE * mapScale
        val shownH = bitmap.height / CACHE_PIXEL_SCALE * mapScale
        val left = center.x - shownW / 2f
        val right = center.x + shownW / 2f
        val top = center.y - shownH / 2f
        val bottom = center.y + shownH / 2f
        val margin = 8f
        return left <= -margin && right >= width + margin && top <= -margin && bottom >= height + margin
    }

    private fun rebuildCacheIfPossible(force: Boolean = false) {
        if (!force && !cacheDirty && cacheStillCoversView()) return
        if (cameraMoving) return
        val currentMap = map ?: return
        if (width <= 0 || height <= 0) return

        val camera = currentMap.cameraPosition
        val target = camera.target ?: return
        val cacheW = max(1, (width * CACHE_OVERSCAN * CACHE_PIXEL_SCALE).toInt())
        val cacheH = max(1, (height * CACHE_OVERSCAN * CACHE_PIXEL_SCALE).toInt())
        val newBitmap = Bitmap.createBitmap(cacheW, cacheH, Bitmap.Config.ARGB_8888)
        val offscreen = Canvas(newBitmap)

        val layer = offscreen.saveLayer(0f, 0f, cacheW.toFloat(), cacheH.toFloat(), null)
        drawWorldAnchoredFogLayer(offscreen, currentMap, camera.zoom, cacheW, cacheH)
        if (track.isNotEmpty()) drawExploredRoutes(offscreen, currentMap, cacheW, cacheH)
        currentLocation?.let { drawTemporaryOpening(offscreen, currentMap, it, cacheW, cacheH) }
        offscreen.restoreToCount(layer)

        val old = cacheBitmap
        cacheBitmap = newBitmap
        cacheCenter = LatLng(target.latitude, target.longitude)
        cacheZoom = camera.zoom
        cacheBearing = camera.bearing
        cacheDirty = false
        old?.recycle()
    }

    private fun drawWorldAnchoredFogLayer(
        canvas: Canvas,
        currentMap: MapLibreMap,
        zoom: Double,
        cacheW: Int,
        cacheH: Int
    ) {
        val cameraTarget = currentMap.cameraPosition.target ?: return
        val centerWorldX = lonToWorldX(cameraTarget.longitude)
        val centerWorldY = latToWorldY(cameraTarget.latitude)

        // Base soft veil - always closes the unexplored territory completely.
        canvas.drawRect(0f, 0f, cacheW.toFloat(), cacheH.toFloat(), fogFillPaint)

        // One anchored texture pass for structure.
        drawRepeatedFogTexture(
            canvas = canvas,
            bitmap = fogTileBitmap,
            cacheW = cacheW,
            cacheH = cacheH,
            worldX = centerWorldX,
            worldY = centerWorldY,
            zoom = zoom,
            tileScreenPx = 260f,
            phaseScale = 0.92,
            paint = fogTilePaint
        )

        // One softer secondary pass for more alive edges, but still cheap.
        drawRepeatedFogTexture(
            canvas = canvas,
            bitmap = fogTileBitmap,
            cacheW = cacheW,
            cacheH = cacheH,
            worldX = centerWorldX,
            worldY = centerWorldY,
            zoom = zoom,
            tileScreenPx = 420f,
            phaseScale = 0.53,
            paint = fogSoftLightPaint
        )
    }

    private fun drawRepeatedFogTexture(
        canvas: Canvas,
        bitmap: Bitmap,
        cacheW: Int,
        cacheH: Int,
        worldX: Double,
        worldY: Double,
        zoom: Double,
        tileScreenPx: Float,
        phaseScale: Double,
        paint: Paint
    ) {
        if (bitmap.width <= 0 || bitmap.height <= 0) return

        val zoomScale = 2.0.pow((zoom - BASE_ZOOM) * 0.18).toFloat().coerceIn(0.74f, 1.7f)
        val tileW = (tileScreenPx * zoomScale * CACHE_PIXEL_SCALE).coerceAtLeast(72f)
        val aspect = bitmap.height.toFloat() / bitmap.width.toFloat()
        val tileH = (tileW * aspect).coerceAtLeast(72f)

        val phaseX = (((worldX * 8192.0 * phaseScale) % 1.0 + 1.0) % 1.0).toFloat() * tileW
        val phaseY = (((worldY * 8192.0 * phaseScale) % 1.0 + 1.0) % 1.0).toFloat() * tileH

        var y = -tileH - phaseY
        var row = 0
        while (y < cacheH + tileH) {
            val rowShift = if ((row and 1) == 0) 0f else tileW * 0.28f
            var x = -tileW - phaseX + rowShift
            while (x < cacheW + tileW) {
                canvas.drawBitmap(
                    bitmap,
                    null,
                    RectF(x - 2f, y - 2f, x + tileW + 2f, y + tileH + 2f),
                    paint
                )
                x += tileW * 0.86f
            }
            y += tileH * 0.84f
            row++
        }
    }

    private fun drawExploredRoutes(canvas: Canvas, currentMap: MapLibreMap, cacheW: Int, cacheH: Int) {
        val grouped = track.groupBy { it.walkId }
        for (walkPoints in grouped.values) {
            if (walkPoints.isEmpty()) continue

            val path = Path()
            var started = false
            var representativeRadiusPx = 22f * CACHE_PIXEL_SCALE

            for (point in walkPoints) {
                val screen = currentMap.projection.toScreenLocation(LatLng(point.latitude, point.longitude))
                val p = screenToCache(screen.x, screen.y, cacheW, cacheH)
                if (!started) {
                    path.moveTo(p.first, p.second)
                    representativeRadiusPx = radiusMetersToPixels(
                        currentMap,
                        point.latitude,
                        point.longitude,
                        REVEAL_RADIUS_M
                    ) * CACHE_PIXEL_SCALE
                    started = true
                } else {
                    path.lineTo(p.first, p.second)
                }
            }
            if (!started) continue

            val coreWidth = (representativeRadiusPx * 2f).coerceIn(9f, 550f)
            edgeFeatherPaint.strokeWidth = (coreWidth + FEATHER_EXTRA_PX).coerceAtMost(600f)
            clearPaint.strokeWidth = coreWidth
            canvas.drawPath(path, edgeFeatherPaint)
            canvas.drawPath(path, clearPaint)

            if (walkPoints.size == 1) {
                val only = walkPoints.first()
                val screen = currentMap.projection.toScreenLocation(LatLng(only.latitude, only.longitude))
                val p = screenToCache(screen.x, screen.y, cacheW, cacheH)
                clearCircle(canvas, p.first, p.second, representativeRadiusPx)
            }
        }
    }

    private fun drawTemporaryOpening(
        canvas: Canvas,
        currentMap: MapLibreMap,
        location: LatLng,
        cacheW: Int,
        cacheH: Int
    ) {
        val screen = currentMap.projection.toScreenLocation(location)
        val p = screenToCache(screen.x, screen.y, cacheW, cacheH)
        val radius = (radiusMetersToPixels(
            currentMap,
            location.latitude,
            location.longitude,
            CURRENT_OPENING_RADIUS_M
        ) * CACHE_PIXEL_SCALE).coerceAtLeast(17f)
        clearCircle(canvas, p.first, p.second, radius)
    }

    private fun screenToCache(x: Float, y: Float, cacheW: Int, cacheH: Int): Pair<Float, Float> {
        val cx = (x - width / 2f) * CACHE_PIXEL_SCALE + cacheW / 2f
        val cy = (y - height / 2f) * CACHE_PIXEL_SCALE + cacheH / 2f
        return cx to cy
    }

    private fun clearCircle(canvas: Canvas, x: Float, y: Float, radius: Float) {
        // Cheap feather without runtime blur filters: draw several rings with descending alpha.
        val featherRadius = radius + FEATHER_EXTRA_PX
        val steps = 5
        for (i in steps downTo 1) {
            val t = i / steps.toFloat()
            softCirclePaint.alpha = (28f * t).toInt().coerceIn(0, 255)
            canvas.drawCircle(x, y, radius + t * FEATHER_EXTRA_PX, softCirclePaint)
        }
        canvas.drawCircle(x, y, radius, clearCirclePaint)
        softCirclePaint.alpha = 255
    }

    private fun radiusMetersToPixels(map: MapLibreMap, lat: Double, lon: Double, radiusM: Double): Float {
        val center = map.projection.toScreenLocation(LatLng(lat, lon))
        val latitudeDelta = radiusM / 111_320.0
        val north = map.projection.toScreenLocation(LatLng(lat + latitudeDelta, lon))
        return abs(center.y - north.y).coerceIn(6f, 560f)
    }

    private fun lonToWorldX(lon: Double): Double = (lon + 180.0) / 360.0

    private fun latToWorldY(lat: Double): Double {
        val clamped = lat.coerceIn(-85.05112878, 85.05112878)
        val rad = Math.toRadians(clamped)
        return (1.0 - ln(kotlin.math.tan(rad) + 1.0 / kotlin.math.cos(rad)) / PI) / 2.0
    }

    private fun worldXToLon(x: Double): Double = wrapWorldX(x) * 360.0 - 180.0

    private fun worldYToLat(y: Double): Double {
        val n = PI * (1.0 - 2.0 * y)
        return Math.toDegrees(atan(sinh(n)))
    }

    private fun wrapWorldX(value: Double): Double {
        var x = value % 1.0
        if (x < 0.0) x += 1.0
        return x
    }

    private fun buildFogTileBitmap(size: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)

        val base = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f,
                0f,
                size.toFloat(),
                size.toFloat(),
                intArrayOf(
                    Color.argb(165, 255, 255, 255),
                    Color.argb(215, 245, 249, 255),
                    Color.argb(180, 236, 242, 250)
                ),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, size.toFloat(), size.toFloat(), base)

        val puffs = listOf(
            floatArrayOf(0.22f, 0.24f, 0.28f),
            floatArrayOf(0.58f, 0.18f, 0.24f),
            floatArrayOf(0.80f, 0.38f, 0.22f),
            floatArrayOf(0.36f, 0.56f, 0.30f),
            floatArrayOf(0.72f, 0.66f, 0.32f),
            floatArrayOf(0.18f, 0.78f, 0.24f),
            floatArrayOf(0.53f, 0.86f, 0.22f)
        )

        puffs.forEachIndexed { index, puff ->
            val cx = puff[0] * size
            val cy = puff[1] * size
            val r = puff[2] * size
            val alpha = if (index % 2 == 0) 135 else 105
            val puffPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    cx,
                    cy,
                    r,
                    intArrayOf(
                        Color.argb(alpha, 255, 255, 255),
                        Color.argb((alpha * 0.60f).toInt(), 245, 250, 255),
                        Color.argb(0, 240, 246, 255)
                    ),
                    floatArrayOf(0f, 0.62f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawCircle(cx, cy, r, puffPaint)
        }

        val haze = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f,
                size.toFloat() * 0.08f,
                size.toFloat(),
                size.toFloat() * 0.92f,
                intArrayOf(
                    Color.argb(52, 255, 255, 255),
                    Color.argb(0, 255, 255, 255),
                    Color.argb(48, 255, 255, 255)
                ),
                floatArrayOf(0f, 0.48f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, size.toFloat(), size.toFloat(), haze)

        return bitmap
    }

    companion object {
        private const val REVEAL_RADIUS_M = 30.0
        private const val CURRENT_OPENING_RADIUS_M = 44.0
        private const val FEATHER_EXTRA_PX = 22f

        // Lower internal resolution keeps panning/zooming light while overscan hides cache edges.
        private const val CACHE_PIXEL_SCALE = 0.32f
        private const val CACHE_OVERSCAN = 4.00f
        private const val BASE_ZOOM = 15.0
    }
}
