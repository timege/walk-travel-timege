package com.lifeinmist.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.LocationManager
import android.os.SystemClock
import android.view.Gravity
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatTextView
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

class GpsStatusView(context: Context) : AppCompatTextView(context) {
    private var accuracy = 0f
    private var fixNanos = 0L
    private var active = false
    private var state = "waiting"
    private val tick = object : Runnable {
        override fun run() { refresh(); if (active) postDelayed(this, 5_000) }
    }
    init {
        textSize = 12f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        gravity = Gravity.CENTER
        minHeight = dp(48)
        setPadding(dp(10), 0, dp(10), 0)
        background = GradientDrawable().apply { setColor(Color.rgb(246, 250, 241)); cornerRadius = dp(18).toFloat() }
        elevation = dp(2).toFloat()
        setOnClickListener {
            val details = when (state) {
                "permission" -> "Allow location access to show GPS quality."
                "off" -> "Location services are off. Turn them on in your phone settings."
                "waiting" -> "No recent GPS fix. Start a walk for continuous updates, or tap My location to refresh."
                else -> "Estimated accuracy: ±${accuracy.roundToInt()} m.\nLast fix: ${((SystemClock.elapsedRealtimeNanos() - fixNanos) / 1_000_000_000).coerceAtLeast(0)} seconds ago."
            }
            AlertDialog.Builder(context).setTitle("GPS quality")
                .setMessage("$details\n\nTo unlock places, record a walk and move close enough with a fresh, precise GPS fix. Accuracy alone does not guarantee an unlock.")
                .setPositiveButton("Got it", null).show()
        }
        refresh()
    }
    fun update(accuracyM: Float, elapsedNanos: Long) {
        if (elapsedNanos < fixNanos) return
        accuracy = accuracyM; fixNanos = elapsedNanos; refresh()
    }
    fun resumeUpdates() { active = true; removeCallbacks(tick); tick.run() }
    fun pauseUpdates() { active = false; removeCallbacks(tick) }
    override fun onDetachedFromWindow() { pauseUpdates(); super.onDetachedFromWindow() }
    private fun refresh() {
        val permission = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val enabled = runCatching { manager.isProviderEnabled(LocationManager.GPS_PROVIDER) || manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) }.getOrDefault(false)
        state = GpsQuality.state(permission, enabled, accuracy, fixNanos, SystemClock.elapsedRealtimeNanos())
        text = when (state) {
            "good", "fair" -> "GPS ±${accuracy.roundToInt()} m"
            "weak" -> "GPS · weak"
            "off" -> "GPS · off"
            "permission" -> "GPS · access"
            else -> "GPS · waiting"
        }
        setTextColor(when (state) {
            "good" -> Color.rgb(20, 94, 35)
            "fair", "weak" -> Color.rgb(131, 83, 0)
            else -> Color.rgb(80, 89, 82)
        })
        contentDescription = "$text. Tap for GPS quality details."
    }
    private fun dp(n: Int) = (n * resources.displayMetrics.density).roundToInt()
}
