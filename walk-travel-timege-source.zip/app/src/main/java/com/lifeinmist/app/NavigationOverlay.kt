package com.lifeinmist.app

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap

/** Draws navigation UI above the cloud layer so it stays readable in unexplored areas. */
class NavigationOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) {
            field = value
            invalidate()
        }

    private var currentLocation: LatLng? = null
    private var destination: LatLng? = null
    private var route: List<LatLng> = emptyList()

    private val routeOutlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.argb(220, 255, 255, 255)
        strokeWidth = dp(8f)
    }

    private val routePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.rgb(70, 151, 221)
        strokeWidth = dp(5f)
    }

    private val destinationPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(74, 137, 195)
        style = Paint.Style.FILL
        setShadowLayer(dp(5f), 0f, dp(2f), Color.argb(80, 35, 63, 88))
    }

    init {
        isClickable = false
        isFocusable = false
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun setCurrentLocation(location: LatLng?) {
        currentLocation = location
        invalidate()
    }

    fun setDestination(location: LatLng?) {
        destination = location
        invalidate()
    }

    fun setRoute(points: List<LatLng>) {
        route = points
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val currentMap = map ?: return

        if (route.size > 1) drawRoute(canvas, currentMap)
        destination?.let { drawDestination(canvas, currentMap, it) }
        currentLocation?.let { drawCurrentLocation(canvas, currentMap, it) }
    }

    private fun drawRoute(canvas: Canvas, currentMap: MapLibreMap) {
        val path = Path()
        route.forEachIndexed { index, point ->
            val screen = currentMap.projection.toScreenLocation(point)
            if (index == 0) path.moveTo(screen.x, screen.y) else path.lineTo(screen.x, screen.y)
        }
        canvas.drawPath(path, routeOutlinePaint)
        canvas.drawPath(path, routePaint)
    }

    private fun drawCurrentLocation(canvas: Canvas, currentMap: MapLibreMap, location: LatLng) {
        val p = currentMap.projection.toScreenLocation(location)
        val haloRadius = dp(43f)
        val glowRadius = dp(22f)

        val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                p.x,
                p.y,
                haloRadius,
                intArrayOf(
                    Color.argb(86, 48, 223, 151),
                    Color.argb(44, 70, 224, 164),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawCircle(p.x, p.y, haloRadius, halo)

        val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(115, 44, 220, 143)
            maskFilter = BlurMaskFilter(dp(8f), BlurMaskFilter.Blur.NORMAL)
        }
        canvas.drawCircle(p.x, p.y, glowRadius, glow)

        val outer = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.WHITE
        }
        canvas.drawCircle(p.x, p.y, dp(13f), outer)

        val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = RadialGradient(
                p.x - dp(3f),
                p.y - dp(4f),
                dp(11f),
                intArrayOf(Color.rgb(51, 226, 139), Color.rgb(18, 198, 117)),
                null,
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawCircle(p.x, p.y, dp(9f), dot)
    }

    private fun drawDestination(canvas: Canvas, currentMap: MapLibreMap, location: LatLng) {
        val p = currentMap.projection.toScreenLocation(location)
        val r = dp(12f)
        val path = Path().apply {
            moveTo(p.x, p.y + r * 1.65f)
            lineTo(p.x - r * 0.72f, p.y + r * 0.42f)
            lineTo(p.x + r * 0.72f, p.y + r * 0.42f)
            close()
        }
        canvas.drawPath(path, destinationPaint)
        canvas.drawCircle(p.x, p.y, r, destinationPaint)
        val inner = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        canvas.drawCircle(p.x, p.y, r * 0.43f, inner)
    }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density
}
