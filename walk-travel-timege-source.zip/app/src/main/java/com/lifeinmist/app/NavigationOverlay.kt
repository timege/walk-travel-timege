package com.lifeinmist.app

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap

/** Draws explored progress, optional navigation route and current location above the cloud layer. */
class NavigationOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) {
            field = value
            invalidate()
        }

    private var currentLocation: LatLng? = null
    private var destination: LatLng? = null
    private var route: List<LatLng> = emptyList()
    private var exploredTrack: List<TrackPoint> = emptyList()

    private val exploredOutlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.argb(205, 255, 255, 255)
        strokeWidth = dp(3.4f)
    }

    private val exploredPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.rgb(86, 222, 62)
        strokeWidth = dp(1.7f)
        setShadowLayer(dp(4f), 0f, 0f, Color.argb(120, 83, 236, 75))
    }

    private val routeOutlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.argb(225, 255, 255, 255)
        strokeWidth = dp(4.6f)
    }

    private val routePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.rgb(42, 163, 55)
        strokeWidth = dp(2.35f)
    }

    private val destinationPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(49, 132, 52)
        style = Paint.Style.FILL
        setShadowLayer(dp(5f), 0f, dp(2f), Color.argb(75, 36, 79, 38))
    }

    init {
        isClickable = false
        isFocusable = false
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun setCurrentLocation(location: LatLng?) {
        currentLocation = location
        invalidate()
    }

    fun setDestination(location: LatLng?) {
        destination = location
        invalidate()
    }

    fun setRoute(points: List<LatLng>) {
        route = points
        invalidate()
    }

    fun setExploredTrack(points: List<TrackPoint>) {
        exploredTrack = points
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val currentMap = map ?: return

        if (exploredTrack.size > 1) drawExploredTrack(canvas, currentMap)
        if (route.size > 1) drawRoute(canvas, currentMap)
        destination?.let { drawDestination(canvas, currentMap, it) }
        currentLocation?.let { drawCurrentLocation(canvas, currentMap, it) }
    }

    private fun drawExploredTrack(canvas: Canvas, currentMap: MapLibreMap) {
        val grouped = exploredTrack.groupBy { it.walkId }
        grouped.values.forEach { points ->
            if (points.size < 2) return@forEach
            val path = Path()
            points.forEachIndexed { index, point ->
                val screen = currentMap.projection.toScreenLocation(LatLng(point.latitude, point.longitude))
                if (index == 0) path.moveTo(screen.x, screen.y) else path.lineTo(screen.x, screen.y)
            }
            canvas.drawPath(path, exploredOutlinePaint)
            canvas.drawPath(path, exploredPaint)
        }
    }

    private fun drawRoute(canvas: Canvas, currentMap: MapLibreMap) {
        val path = Path()
        route.forEachIndexed { index, point ->
            val screen = currentMap.projection.toScreenLocation(point)
            if (index == 0) path.moveTo(screen.x, screen.y) else path.lineTo(screen.x, screen.y)
        }
        canvas.drawPath(path, routeOutlinePaint)
        canvas.drawPath(path, routePaint)
    }

    private fun drawCurrentLocation(canvas: Canvas, currentMap: MapLibreMap, location: LatLng) {
        val p = currentMap.projection.toScreenLocation(location)
        val haloRadius = dp(41f)
        val glowRadius = dp(21f)

        val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                p.x,
                p.y,
                haloRadius,
                intArrayOf(
                    Color.argb(82, 82, 235, 100),
                    Color.argb(36, 101, 235, 116),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f, 0.56f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawCircle(p.x, p.y, haloRadius, halo)

        val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(118, 77, 225, 90)
            maskFilter = BlurMaskFilter(dp(8f), BlurMaskFilter.Blur.NORMAL)
        }
        canvas.drawCircle(p.x, p.y, glowRadius, glow)

        val outer = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.WHITE
        }
        canvas.drawCircle(p.x, p.y, dp(13f), outer)

        val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = RadialGradient(
                p.x - dp(3f),
                p.y - dp(4f),
                dp(11f),
                intArrayOf(Color.rgb(105, 239, 70), Color.rgb(25, 171, 54)),
                null,
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawCircle(p.x, p.y, dp(9f), dot)
    }

    private fun drawDestination(canvas: Canvas, currentMap: MapLibreMap, location: LatLng) {
        val p = currentMap.projection.toScreenLocation(location)
        val r = dp(12f)
        val path = Path().apply {
            moveTo(p.x, p.y + r * 1.65f)
            lineTo(p.x - r * 0.72f, p.y + r * 0.42f)
            lineTo(p.x + r * 0.72f, p.y + r * 0.42f)
            close()
        }
        canvas.drawPath(path, destinationPaint)
        canvas.drawCircle(p.x, p.y, r, destinationPaint)
        val inner = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        canvas.drawCircle(p.x, p.y, r * 0.43f, inner)
    }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density
}
