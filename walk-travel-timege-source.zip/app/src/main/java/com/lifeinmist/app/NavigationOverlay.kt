package com.lifeinmist.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import kotlin.math.ceil

/** Fast navigation/exploration overlay. Heavy work is intentionally skipped during map gestures. */
class NavigationOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) {
            field = value
            invalidate()
        }

    private var currentLocation: LatLng? = null
    private var destination: LatLng? = null
    private var route: List<LatLng> = emptyList()
    private var exploredTrack: List<TrackPoint> = emptyList()
    private var cameraMoving = false

    private val exploredOutlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.argb(205, 255, 255, 255)
        strokeWidth = dp(3.2f)
    }

    private val exploredPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.rgb(86, 222, 62)
        strokeWidth = dp(1.7f)
    }

    private val routeOutlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.argb(225, 255, 255, 255)
        strokeWidth = dp(4.4f)
    }

    private val routePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.rgb(42, 163, 55)
        strokeWidth = dp(2.25f)
    }

    private val destinationPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(49, 132, 52)
        style = Paint.Style.FILL
    }
    private val whitePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val locationGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(52, 82, 235, 100) }
    private val locationGlow2Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(88, 77, 225, 90) }

    init {
        isClickable = false
        isFocusable = false
        // Deliberately do not force software rendering.
    }

    fun setCurrentLocation(location: LatLng?) {
        currentLocation = location
        if (!cameraMoving) invalidate()
    }

    fun setDestination(location: LatLng?) {
        destination = location
        if (!cameraMoving) invalidate()
    }

    fun setRoute(points: List<LatLng>) {
        route = points
        if (!cameraMoving) invalidate()
    }

    fun setExploredTrack(points: List<TrackPoint>) {
        exploredTrack = points
        if (!cameraMoving) invalidate()
    }

    fun onCameraMove() {
        cameraMoving = true
        // Do not redraw thousands of projected points on every finger-move frame.
    }

    fun onCameraIdle() {
        cameraMoving = false
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val currentMap = map ?: return

        if (exploredTrack.size > 1) drawExploredTrack(canvas, currentMap)
        if (route.size > 1) drawRoute(canvas, currentMap)
        destination?.let { drawDestination(canvas, currentMap, it) }
        currentLocation?.let { drawCurrentLocation(canvas, currentMap, it) }
    }

    private fun drawExploredTrack(canvas: Canvas, currentMap: MapLibreMap) {
        val grouped = exploredTrack.groupBy { it.walkId }
        val total = exploredTrack.size.coerceAtLeast(1)
        val stride = ceil(total / MAX_EXPLORED_POINTS.toDouble()).toInt().coerceAtLeast(1)

        grouped.values.forEach { points ->
            if (points.size < 2) return@forEach
            val path = Path()
            var drew = false
            var index = 0
            while (index < points.size) {
                val point = points[index]
                val screen = currentMap.projection.toScreenLocation(LatLng(point.latitude, point.longitude))
                if (!drew) {
                    path.moveTo(screen.x, screen.y)
                    drew = true
                } else {
                    path.lineTo(screen.x, screen.y)
                }
                index += stride
            }
            val last = points.last()
            val lastScreen = currentMap.projection.toScreenLocation(LatLng(last.latitude, last.longitude))
            path.lineTo(lastScreen.x, lastScreen.y)
            canvas.drawPath(path, exploredOutlinePaint)
            canvas.drawPath(path, exploredPaint)
        }
    }

    private fun drawRoute(canvas: Canvas, currentMap: MapLibreMap) {
        val path = Path()
        val stride = ceil(route.size / MAX_ROUTE_POINTS.toDouble()).toInt().coerceAtLeast(1)
        var drew = false
        var index = 0
        while (index < route.size) {
            val point = route[index]
            val screen = currentMap.projection.toScreenLocation(point)
            if (!drew) {
                path.moveTo(screen.x, screen.y)
                drew = true
            } else {
                path.lineTo(screen.x, screen.y)
            }
            index += stride
        }
        val last = route.last()
        val lastScreen = currentMap.projection.toScreenLocation(last)
        path.lineTo(lastScreen.x, lastScreen.y)
        canvas.drawPath(path, routeOutlinePaint)
        canvas.drawPath(path, routePaint)
    }

    private fun drawCurrentLocation(canvas: Canvas, currentMap: MapLibreMap, location: LatLng) {
        val p = currentMap.projection.toScreenLocation(location)
        canvas.drawCircle(p.x, p.y, dp(34f), locationGlowPaint)
        canvas.drawCircle(p.x, p.y, dp(20f), locationGlow2Paint)
        canvas.drawCircle(p.x, p.y, dp(13f), whitePaint)

        val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = RadialGradient(
                p.x - dp(3f), p.y - dp(4f), dp(11f),
                intArrayOf(Color.rgb(105, 239, 70), Color.rgb(25, 171, 54)),
                null, Shader.TileMode.CLAMP
            )
        }
        canvas.drawCircle(p.x, p.y, dp(9f), dot)
    }

    private fun drawDestination(canvas: Canvas, currentMap: MapLibreMap, location: LatLng) {
        val p = currentMap.projection.toScreenLocation(location)
        val r = dp(12f)
        val path = Path().apply {
            moveTo(p.x, p.y + r * 1.65f)
            lineTo(p.x - r * 0.72f, p.y + r * 0.42f)
            lineTo(p.x + r * 0.72f, p.y + r * 0.42f)
            close()
        }
        canvas.drawPath(path, destinationPaint)
        canvas.drawCircle(p.x, p.y, r, destinationPaint)
        canvas.drawCircle(p.x, p.y, r * 0.43f, whitePaint)
    }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density

    companion object {
        private const val MAX_EXPLORED_POINTS = 900
        private const val MAX_ROUTE_POINTS = 500
    }
}
