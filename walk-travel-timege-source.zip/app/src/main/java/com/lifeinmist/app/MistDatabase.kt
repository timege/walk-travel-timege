package com.lifeinmist.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.location.Location
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max


data class WalkRecord(
    val id: Long,
    val startedAt: Long,
    val endedAt: Long?,
    val distanceM: Double
)

data class TrackPoint(
    val walkId: Long,
    val latitude: Double,
    val longitude: Double,
    val accuracyM: Double,
    val recordedAt: Long
)

data class ImportResult(
    val restoredTrackPoints: Int,
    val restoredExploredPoints: Int
)

class MistDatabase(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
    private var exploredLayerChecked = false

    @Synchronized
    private fun ensureExploredLayer() {
        if (exploredLayerChecked) return
        repairPermanentExploredLayer()
        exploredLayerChecked = true
    }

    data class ExploredBatch(val lastId: Long, val points: List<TrackPoint>)

    /** ID cursor, not timestamp: restored historical points may have old dates. */
    fun exploredAfter(afterId: Long): ExploredBatch {
        ensureExploredLayer()
        var lastId = afterId
        val points = ArrayList<TrackPoint>()
        readableDatabase.rawQuery(
            "SELECT id, walk_id, lat, lon, accuracy, recorded_at FROM permanent_explored_points WHERE id > ? ORDER BY id",
            arrayOf(afterId.toString())
        ).use { c ->
            while (c.moveToNext()) {
                lastId = c.getLong(0)
                points.add(TrackPoint(c.getLong(1), c.getDouble(2), c.getDouble(3), c.getDouble(4), c.getLong(5)))
            }
        }
        return ExploredBatch(lastId, points)
    }

    override fun onCreate(db: SQLiteDatabase) {
        createSchema(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Never destructively migrate the user's explored world.
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS walks (id INTEGER PRIMARY KEY AUTOINCREMENT, started_at INTEGER NOT NULL, ended_at INTEGER, distance_m REAL NOT NULL DEFAULT 0)")
            db.execSQL("CREATE TABLE IF NOT EXISTS track_points (id INTEGER PRIMARY KEY AUTOINCREMENT, walk_id INTEGER NOT NULL, lat REAL NOT NULL, lon REAL NOT NULL, accuracy REAL NOT NULL, recorded_at INTEGER NOT NULL, FOREIGN KEY(walk_id) REFERENCES walks(id) ON DELETE CASCADE)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_track_walk ON track_points(walk_id, id)")
        }

        if (oldVersion < 4) {
            createPermanentExploredSchema(db)
        }

        if (oldVersion < 5) {
            createPermanentExploredSchema(db)
            // Self-heal the permanent explored layer from all historical GPS points.
            // This intentionally runs again in v5 because older imports could restore
            // walk history without keeping the permanent cloud-cutout layer in sync.
            repairPermanentExploredLayer(db)
        }
    }

    private fun createSchema(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE walks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                started_at INTEGER NOT NULL,
                ended_at INTEGER,
                distance_m REAL NOT NULL DEFAULT 0
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE track_points (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                walk_id INTEGER NOT NULL,
                lat REAL NOT NULL,
                lon REAL NOT NULL,
                accuracy REAL NOT NULL,
                recorded_at INTEGER NOT NULL,
                FOREIGN KEY(walk_id) REFERENCES walks(id) ON DELETE CASCADE
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_track_walk ON track_points(walk_id, id)")
        createPermanentExploredSchema(db)
    }

    private fun createPermanentExploredSchema(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS permanent_explored_points (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                walk_id INTEGER NOT NULL,
                lat REAL NOT NULL,
                lon REAL NOT NULL,
                accuracy REAL NOT NULL,
                recorded_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_permanent_explored_walk ON permanent_explored_points(walk_id, id)")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_permanent_explored_unique ON permanent_explored_points(recorded_at, lat, lon)")
    }

    private fun repairPermanentExploredLayer(db: SQLiteDatabase = writableDatabase) {
        createPermanentExploredSchema(db)
        db.execSQL(
            """
            INSERT OR IGNORE INTO permanent_explored_points(walk_id, lat, lon, accuracy, recorded_at)
            SELECT walk_id, lat, lon, accuracy, recorded_at FROM track_points
            """.trimIndent()
        )
    }

    fun startWalk(): Long {
        val values = ContentValues().apply {
            put("started_at", System.currentTimeMillis())
            put("distance_m", 0.0)
        }
        return writableDatabase.insertOrThrow("walks", null, values)
    }

    fun activeWalk(): WalkRecord? {
        readableDatabase.rawQuery(
            "SELECT id, started_at, ended_at, distance_m FROM walks WHERE ended_at IS NULL ORDER BY id DESC LIMIT 1",
            null
        ).use { c ->
            if (!c.moveToFirst()) return null
            return WalkRecord(
                id = c.getLong(0),
                startedAt = c.getLong(1),
                endedAt = if (c.isNull(2)) null else c.getLong(2),
                distanceM = c.getDouble(3)
            )
        }
    }

    fun finishWalk(walkId: Long) {
        writableDatabase.update(
            "walks",
            ContentValues().apply { put("ended_at", System.currentTimeMillis()) },
            "id = ?",
            arrayOf(walkId.toString())
        )
    }

    /**
     * Saves real movement regardless of transport mode. Only physically implausible GPS
     * teleports are rejected. Every accepted point is written to BOTH the temporary/session
     * track and the permanent explored-world layer.
     */
    fun appendLocation(walkId: Long, location: Location): Double {
        val db = writableDatabase
        db.beginTransaction()
        try {
            var last: TrackPoint? = null
            db.rawQuery(
                "SELECT walk_id, lat, lon, accuracy, recorded_at FROM track_points WHERE walk_id = ? ORDER BY id DESC LIMIT 1",
                arrayOf(walkId.toString())
            ).use { c ->
                if (c.moveToFirst()) {
                    last = TrackPoint(
                        walkId = c.getLong(0),
                        latitude = c.getDouble(1),
                        longitude = c.getDouble(2),
                        accuracyM = c.getDouble(3),
                        recordedAt = c.getLong(4)
                    )
                }
            }

            val now = if (location.time > 0L) location.time else System.currentTimeMillis()
            val previous = last
            var movedM = 0.0
            var accept = true

            if (previous != null) {
                val result = FloatArray(1)
                Location.distanceBetween(
                    previous.latitude, previous.longitude,
                    location.latitude, location.longitude,
                    result
                )
                movedM = result[0].toDouble()

                val dtSec = max(1.0, (now - previous.recordedAt).coerceAtLeast(0L) / 1000.0)
                val accuracyAllowance = (previous.accuracyM + location.accuracy.toDouble()).coerceAtLeast(20.0) * 3.0
                val plausibleDistance = 75.0 * dtSec + accuracyAllowance + 120.0
                if (movedM > plausibleDistance) accept = false
                if (movedM < 2.0 && dtSec < 12.0) accept = false
            }

            if (accept) {
                val values = ContentValues().apply {
                    put("walk_id", walkId)
                    put("lat", location.latitude)
                    put("lon", location.longitude)
                    put("accuracy", location.accuracy.toDouble())
                    put("recorded_at", now)
                }
                db.insertOrThrow("track_points", null, values)
                db.insertWithOnConflict(
                    "permanent_explored_points",
                    null,
                    values,
                    SQLiteDatabase.CONFLICT_IGNORE
                )

                if (previous != null && movedM > 0.0) {
                    db.execSQL(
                        "UPDATE walks SET distance_m = distance_m + ? WHERE id = ?",
                        arrayOf(movedM, walkId)
                    )
                }
            }

            var distance = 0.0
            db.rawQuery("SELECT distance_m FROM walks WHERE id = ?", arrayOf(walkId.toString())).use { c ->
                if (c.moveToFirst()) distance = c.getDouble(0)
            }
            db.setTransactionSuccessful()
            return distance
        } finally {
            db.endTransaction()
        }
    }

    fun walksForGpxExport(): List<WalkRecord> {
        val result = ArrayList<WalkRecord>()
        readableDatabase.rawQuery("""
            SELECT id, started_at, ended_at, distance_m FROM walks
            WHERE EXISTS (SELECT 1 FROM track_points WHERE walk_id = walks.id)
            ORDER BY started_at DESC
        """.trimIndent(), null).use { c ->
            while (c.moveToNext()) result.add(WalkRecord(c.getLong(0), c.getLong(1),
                if (c.isNull(2)) null else c.getLong(2), c.getDouble(3)))
        }
        return result
    }

    /** Stream one real recorded walk; do not invent elevation or connect separate walks. */
    fun exportWalkGpx(walkId: Long, writer: java.io.Writer) {
        readableDatabase.rawQuery(
            "SELECT lat, lon, recorded_at FROM track_points WHERE walk_id = ? ORDER BY id",
            arrayOf(walkId.toString())
        ).use { c ->
            require(c.moveToFirst()) { "This walk has no recorded points" }
            val date = java.time.Instant.ofEpochMilli(c.getLong(2)).toString()
            GpxCodec.begin(writer, "Walk $date")
            writer.write("<trkseg>\n")
            do {
                GpxCodec.writePoint(writer, GpxCodec.Point(c.getDouble(0), c.getDouble(1), c.getLong(2), null))
            } while (c.moveToNext())
            writer.write("</trkseg>\n")
            GpxCodec.end(writer)
        }
    }

    fun totalDistanceM(): Double {
        readableDatabase.rawQuery("SELECT COALESCE(SUM(distance_m), 0) FROM walks", null).use { c ->
            if (c.moveToFirst()) return c.getDouble(0)
        }
        return 0.0
    }

    fun totalTrackPoints(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM track_points", null).use { c ->
            if (c.moveToFirst()) return c.getInt(0)
        }
        return 0
    }

    fun totalExploredPoints(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM permanent_explored_points", null).use { c ->
            if (c.moveToFirst()) return c.getInt(0)
        }
        return 0
    }

    fun trackPoints(): List<TrackPoint> = readPoints("track_points")

    fun exploredPoints(): List<TrackPoint> {
        // Repair once for this database helper. Imports explicitly repair again.
        ensureExploredLayer()
        return readPoints("permanent_explored_points")
    }

    private fun readPoints(table: String): List<TrackPoint> {
        val result = ArrayList<TrackPoint>()
        readableDatabase.rawQuery(
            "SELECT walk_id, lat, lon, accuracy, recorded_at FROM $table ORDER BY walk_id, id",
            null
        ).use { c ->
            while (c.moveToNext()) {
                result += TrackPoint(
                    walkId = c.getLong(0),
                    latitude = c.getDouble(1),
                    longitude = c.getDouble(2),
                    accuracyM = c.getDouble(3),
                    recordedAt = c.getLong(4)
                )
            }
        }
        return result
    }

    /**
     * Version 2 stores both walk sessions and an explicit permanent explored-world layer.
     * This means restoring progress no longer depends on session/history semantics.
     */
    fun exportProgressJson(): String {
        val root = JSONObject()
            .put("format", "walk-travel-timege-progress")
            .put("version", 2)
            .put("createdAt", System.currentTimeMillis())

        val walksJson = JSONArray()
        readableDatabase.rawQuery(
            "SELECT id, started_at, ended_at, distance_m FROM walks ORDER BY id",
            null
        ).use { walksCursor ->
            while (walksCursor.moveToNext()) {
                val walkId = walksCursor.getLong(0)
                val walkJson = JSONObject()
                    .put("sourceWalkId", walkId)
                    .put("startedAt", walksCursor.getLong(1))
                    .put("distanceM", walksCursor.getDouble(3))

                if (!walksCursor.isNull(2)) walkJson.put("endedAt", walksCursor.getLong(2))

                val pointsJson = JSONArray()
                readableDatabase.rawQuery(
                    "SELECT lat, lon, accuracy, recorded_at FROM track_points WHERE walk_id = ? ORDER BY id",
                    arrayOf(walkId.toString())
                ).use { pointCursor ->
                    while (pointCursor.moveToNext()) {
                        pointsJson.put(pointJson(pointCursor.getDouble(0), pointCursor.getDouble(1), pointCursor.getDouble(2), pointCursor.getLong(3)))
                    }
                }
                walkJson.put("points", pointsJson)
                walksJson.put(walkJson)
            }
        }
        root.put("walks", walksJson)

        val segments = JSONArray()
        val grouped = exploredPoints().groupBy { it.walkId }
        grouped.forEach { (segmentId, points) ->
            val segment = JSONObject().put("segmentId", segmentId)
            val pointsJson = JSONArray()
            points.forEach { p ->
                pointsJson.put(pointJson(p.latitude, p.longitude, p.accuracyM, p.recordedAt))
            }
            segment.put("points", pointsJson)
            segments.put(segment)
        }
        root.put("exploredSegments", segments)
        return root.toString()
    }

    private fun pointJson(lat: Double, lon: Double, accuracy: Double, recordedAt: Long): JSONObject =
        JSONObject()
            .put("lat", lat)
            .put("lon", lon)
            .put("accuracy", accuracy)
            .put("recordedAt", recordedAt)

    /**
     * Imports both old v1 backups and new v2 backups. The permanent explored layer is
     * restored independently, then used by the cloud renderer immediately.
     */
    fun importProgressJson(rawJson: String): ImportResult {
        val root = JSONObject(rawJson)
        require(root.optString("format") == "walk-travel-timege-progress") { "Unsupported backup format" }
        val version = root.optInt("version", 0)
        require(version == 1 || version == 2) { "Unsupported backup version" }

        val db = writableDatabase
        val existingTrackKeys = existingKeys(db, "track_points")
        val existingExploredKeys = existingKeys(db, "permanent_explored_points")
        var insertedTrackPoints = 0
        var insertedExploredPoints = 0
        val sourceToNewWalkId = HashMap<Long, Long>()

        db.beginTransaction()
        try {
            val walksJson = root.optJSONArray("walks") ?: JSONArray()
            for (i in 0 until walksJson.length()) {
                val walkJson = walksJson.optJSONObject(i) ?: continue
                val pointsJson = walkJson.optJSONArray("points") ?: JSONArray()

                val allValidPoints = ArrayList<JSONObject>()
                val freshTrackPoints = ArrayList<JSONObject>()
                for (j in 0 until pointsJson.length()) {
                    val point = pointsJson.optJSONObject(j) ?: continue
                    if (!validPoint(point)) continue
                    allValidPoints += point
                    val key = pointKey(point)
                    if (existingTrackKeys.add(key)) freshTrackPoints += point
                }

                val sourceWalkId = walkJson.optLong("sourceWalkId", Long.MIN_VALUE)
                var newWalkId: Long? = null

                if (freshTrackPoints.isNotEmpty()) {
                    val startedAt = walkJson.optLong("startedAt", freshTrackPoints.first().optLong("recordedAt"))
                    val endedAt = if (walkJson.has("endedAt")) {
                        walkJson.optLong("endedAt", startedAt)
                    } else {
                        freshTrackPoints.last().optLong("recordedAt", startedAt)
                    }
                    val walkValues = ContentValues().apply {
                        put("started_at", startedAt)
                        put("ended_at", endedAt)
                        put("distance_m", walkJson.optDouble("distanceM", 0.0))
                    }
                    newWalkId = db.insertOrThrow("walks", null, walkValues)
                    if (sourceWalkId != Long.MIN_VALUE) sourceToNewWalkId[sourceWalkId] = newWalkId

                    freshTrackPoints.forEach { point ->
                        insertPoint(db, "track_points", newWalkId, point)
                        insertedTrackPoints++
                    }
                }

                // IMPORTANT: restore cloud cutouts for *all* valid backup points, even when
                // the same points already exist in track_points. Older app versions could
                // leave track history intact but lose the permanent explored layer, which
                // produced exactly the bug where distance remained but the map re-clouded.
                val exploredSegmentId = newWalkId
                    ?: if (sourceWalkId != Long.MIN_VALUE) -(kotlin.math.abs(sourceWalkId) + 1_000_000_000L)
                    else -(System.currentTimeMillis() + i + 1L)

                allValidPoints.forEach { point ->
                    val exploredKey = pointKey(point)
                    if (existingExploredKeys.add(exploredKey)) {
                        insertPoint(db, "permanent_explored_points", exploredSegmentId, point)
                        insertedExploredPoints++
                    }
                }
            }

            // v2 contains an explicit copy of the permanent world. Restore it even if
            // session/history data was incomplete or had already been merged before.
            if (version >= 2) {
                val segments = root.optJSONArray("exploredSegments") ?: JSONArray()
                for (i in 0 until segments.length()) {
                    val segment = segments.optJSONObject(i) ?: continue
                    val sourceSegment = segment.optLong("segmentId", Long.MIN_VALUE)
                    val mappedWalkId = sourceToNewWalkId[sourceSegment]
                        ?: -(System.currentTimeMillis() + i + 1L)
                    val points = segment.optJSONArray("points") ?: continue
                    for (j in 0 until points.length()) {
                        val point = points.optJSONObject(j) ?: continue
                        if (!validPoint(point)) continue
                        val key = pointKey(point)
                        if (!existingExploredKeys.add(key)) continue
                        insertPoint(db, "permanent_explored_points", mappedWalkId, point)
                        insertedExploredPoints++
                    }
                }
            }

            // Old v1 backups do not have exploredSegments, so copy any imported tracks
            // into the permanent layer (already handled above).
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }

        // Final self-heal guarantees every restored historical track also exists in
        // the permanent explored layer before the UI redraws.
        repairPermanentExploredLayer()
        return ImportResult(insertedTrackPoints, insertedExploredPoints)
    }

    private fun existingKeys(db: SQLiteDatabase, table: String): HashSet<String> {
        val keys = HashSet<String>()
        db.rawQuery("SELECT lat, lon, recorded_at FROM $table", null).use { c ->
            while (c.moveToNext()) keys += pointKey(c.getDouble(0), c.getDouble(1), c.getLong(2))
        }
        return keys
    }

    private fun validPoint(point: JSONObject): Boolean =
        point.has("lat") && point.has("lon") && point.has("recordedAt")

    private fun pointKey(point: JSONObject): String =
        pointKey(point.optDouble("lat"), point.optDouble("lon"), point.optLong("recordedAt"))

    private fun pointKey(lat: Double, lon: Double, recordedAt: Long): String =
        "$recordedAt:${"%.6f".format(java.util.Locale.US, lat)}:${"%.6f".format(java.util.Locale.US, lon)}"

    private fun insertPoint(db: SQLiteDatabase, table: String, walkId: Long, point: JSONObject) {
        val values = ContentValues().apply {
            put("walk_id", walkId)
            put("lat", point.getDouble("lat"))
            put("lon", point.getDouble("lon"))
            put("accuracy", point.optDouble("accuracy", 0.0))
            put("recorded_at", point.getLong("recordedAt"))
        }
        db.insertWithOnConflict(table, null, values, SQLiteDatabase.CONFLICT_IGNORE)
    }

    fun walk(walkId: Long): WalkRecord? {
        readableDatabase.rawQuery(
            "SELECT id, started_at, ended_at, distance_m FROM walks WHERE id = ? LIMIT 1",
            arrayOf(walkId.toString())
        ).use { c ->
            if (!c.moveToFirst()) return null
            return WalkRecord(
                id = c.getLong(0),
                startedAt = c.getLong(1),
                endedAt = if (c.isNull(2)) null else c.getLong(2),
                distanceM = c.getDouble(3)
            )
        }
    }

    fun walks(): List<WalkRecord> {
        val result = ArrayList<WalkRecord>()
        readableDatabase.rawQuery(
            "SELECT id, started_at, ended_at, distance_m FROM walks ORDER BY started_at DESC",
            null
        ).use { c ->
            while (c.moveToNext()) {
                result += WalkRecord(
                    id = c.getLong(0),
                    startedAt = c.getLong(1),
                    endedAt = if (c.isNull(2)) null else c.getLong(2),
                    distanceM = c.getDouble(3)
                )
            }
        }
        return result
    }

    companion object {
        private const val DB_NAME = "life_in_mist.db"
        private const val DB_VERSION = 5
    }
}
