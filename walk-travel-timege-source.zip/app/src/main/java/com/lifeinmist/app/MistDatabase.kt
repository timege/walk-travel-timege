package com.lifeinmist.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.location.Location

data class WalkRecord(
    val id: Long,
    val startedAt: Long,
    val endedAt: Long?,
    val distanceM: Double
)

data class ExploredPoint(
    val latitude: Double,
    val longitude: Double,
    val radiusM: Double
)

class MistDatabase(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE walks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                started_at INTEGER NOT NULL,
                ended_at INTEGER,
                distance_m REAL NOT NULL DEFAULT 0
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE track_points (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                walk_id INTEGER NOT NULL,
                lat REAL NOT NULL,
                lon REAL NOT NULL,
                accuracy REAL NOT NULL,
                recorded_at INTEGER NOT NULL,
                FOREIGN KEY(walk_id) REFERENCES walks(id) ON DELETE CASCADE
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE explored_points (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                lat REAL NOT NULL,
                lon REAL NOT NULL,
                radius_m REAL NOT NULL,
                recorded_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_track_walk ON track_points(walk_id)")
        db.execSQL("CREATE INDEX idx_explored_lat_lon ON explored_points(lat, lon)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun startWalk(): Long {
        val values = ContentValues().apply {
            put("started_at", System.currentTimeMillis())
            put("distance_m", 0.0)
        }
        return writableDatabase.insertOrThrow("walks", null, values)
    }

    fun activeWalk(): WalkRecord? {
        readableDatabase.rawQuery(
            "SELECT id, started_at, ended_at, distance_m FROM walks WHERE ended_at IS NULL ORDER BY id DESC LIMIT 1",
            null
        ).use { c ->
            if (!c.moveToFirst()) return null
            return WalkRecord(
                id = c.getLong(0),
                startedAt = c.getLong(1),
                endedAt = if (c.isNull(2)) null else c.getLong(2),
                distanceM = c.getDouble(3)
            )
        }
    }

    fun finishWalk(walkId: Long) {
        val values = ContentValues().apply { put("ended_at", System.currentTimeMillis()) }
        writableDatabase.update("walks", values, "id = ?", arrayOf(walkId.toString()))
    }

    /**
     * Adds a GPS sample and returns the updated distance of the current walk.
     * Samples with tiny movement are ignored to reduce GPS jitter and database growth.
     */
    fun appendLocation(walkId: Long, location: Location, revealRadiusM: Double = 35.0): Double {
        val db = writableDatabase
        db.beginTransaction()
        try {
            var lastLat: Double? = null
            var lastLon: Double? = null
            var lastTime: Long? = null
            db.rawQuery(
                "SELECT lat, lon, recorded_at FROM track_points WHERE walk_id = ? ORDER BY id DESC LIMIT 1",
                arrayOf(walkId.toString())
            ).use { c ->
                if (c.moveToFirst()) {
                    lastLat = c.getDouble(0)
                    lastLon = c.getDouble(1)
                    lastTime = c.getLong(2)
                }
            }

            val now = if (location.time > 0) location.time else System.currentTimeMillis()
            var movedM = Double.MAX_VALUE
            if (lastLat != null && lastLon != null) {
                val result = FloatArray(1)
                Location.distanceBetween(lastLat!!, lastLon!!, location.latitude, location.longitude, result)
                movedM = result[0].toDouble()
            }

            val enoughTime = lastTime == null || now - lastTime!! >= 10_000L
            if (movedM >= 3.0 || enoughTime) {
                ContentValues().also { v ->
                    v.put("walk_id", walkId)
                    v.put("lat", location.latitude)
                    v.put("lon", location.longitude)
                    v.put("accuracy", location.accuracy.toDouble())
                    v.put("recorded_at", now)
                    db.insertOrThrow("track_points", null, v)
                }

                val shouldReveal = lastLat == null || movedM >= 7.0 || enoughTime
                if (shouldReveal) {
                    ContentValues().also { v ->
                        v.put("lat", location.latitude)
                        v.put("lon", location.longitude)
                        v.put("radius_m", revealRadiusM)
                        v.put("recorded_at", now)
                        db.insertOrThrow("explored_points", null, v)
                    }
                }

                if (lastLat != null && movedM < 250.0) {
                    db.execSQL(
                        "UPDATE walks SET distance_m = distance_m + ? WHERE id = ?",
                        arrayOf(movedM, walkId)
                    )
                }
            }

            var distance = 0.0
            db.rawQuery("SELECT distance_m FROM walks WHERE id = ?", arrayOf(walkId.toString())).use { c ->
                if (c.moveToFirst()) distance = c.getDouble(0)
            }
            db.setTransactionSuccessful()
            return distance
        } finally {
            db.endTransaction()
        }
    }

    fun exploredPoints(): List<ExploredPoint> {
        val result = ArrayList<ExploredPoint>()
        readableDatabase.rawQuery(
            "SELECT lat, lon, radius_m FROM explored_points ORDER BY id",
            null
        ).use { c ->
            while (c.moveToNext()) {
                result += ExploredPoint(c.getDouble(0), c.getDouble(1), c.getDouble(2))
            }
        }
        return result
    }

    fun walks(): List<WalkRecord> {
        val result = ArrayList<WalkRecord>()
        readableDatabase.rawQuery(
            "SELECT id, started_at, ended_at, distance_m FROM walks ORDER BY started_at DESC",
            null
        ).use { c ->
            while (c.moveToNext()) {
                result += WalkRecord(
                    id = c.getLong(0),
                    startedAt = c.getLong(1),
                    endedAt = if (c.isNull(2)) null else c.getLong(2),
                    distanceM = c.getDouble(3)
                )
            }
        }
        return result
    }

    companion object {
        private const val DB_NAME = "life_in_mist.db"
        private const val DB_VERSION = 1
    }
}
