package com.lifeinmist.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.location.Location
import kotlin.math.max


data class WalkRecord(
    val id: Long,
    val startedAt: Long,
    val endedAt: Long?,
    val distanceM: Double
)

data class TrackPoint(
    val walkId: Long,
    val latitude: Double,
    val longitude: Double,
    val accuracyM: Double,
    val recordedAt: Long
)

class MistDatabase(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        createSchema(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            // v1 was an early field-test build whose circular reveal points could contain
            // GPS artefacts. Start v2 clean so those artefacts do not survive an upgrade.
            db.execSQL("DROP TABLE IF EXISTS explored_points")
            db.execSQL("DROP TABLE IF EXISTS track_points")
            db.execSQL("DROP TABLE IF EXISTS walks")
            createSchema(db)
        }
    }

    private fun createSchema(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE walks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                started_at INTEGER NOT NULL,
                ended_at INTEGER,
                distance_m REAL NOT NULL DEFAULT 0
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE track_points (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                walk_id INTEGER NOT NULL,
                lat REAL NOT NULL,
                lon REAL NOT NULL,
                accuracy REAL NOT NULL,
                recorded_at INTEGER NOT NULL,
                FOREIGN KEY(walk_id) REFERENCES walks(id) ON DELETE CASCADE
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_track_walk ON track_points(walk_id, id)")
    }

    fun startWalk(): Long {
        val values = ContentValues().apply {
            put("started_at", System.currentTimeMillis())
            put("distance_m", 0.0)
        }
        return writableDatabase.insertOrThrow("walks", null, values)
    }

    fun activeWalk(): WalkRecord? {
        readableDatabase.rawQuery(
            "SELECT id, started_at, ended_at, distance_m FROM walks WHERE ended_at IS NULL ORDER BY id DESC LIMIT 1",
            null
        ).use { c ->
            if (!c.moveToFirst()) return null
            return WalkRecord(
                id = c.getLong(0),
                startedAt = c.getLong(1),
                endedAt = if (c.isNull(2)) null else c.getLong(2),
                distanceM = c.getDouble(3)
            )
        }
    }

    fun finishWalk(walkId: Long) {
        writableDatabase.update(
            "walks",
            ContentValues().apply { put("ended_at", System.currentTimeMillis()) },
            "id = ?",
            arrayOf(walkId.toString())
        )
    }

    /**
     * Saves real movement regardless of transport mode. The only rejected samples are
     * obvious GPS teleports: a jump that is physically implausible for the elapsed time,
     * even after allowing generously for both fixes' reported accuracy.
     */
    fun appendLocation(walkId: Long, location: Location): Double {
        val db = writableDatabase
        db.beginTransaction()
        try {
            var last: TrackPoint? = null
            db.rawQuery(
                "SELECT walk_id, lat, lon, accuracy, recorded_at FROM track_points WHERE walk_id = ? ORDER BY id DESC LIMIT 1",
                arrayOf(walkId.toString())
            ).use { c ->
                if (c.moveToFirst()) {
                    last = TrackPoint(
                        walkId = c.getLong(0),
                        latitude = c.getDouble(1),
                        longitude = c.getDouble(2),
                        accuracyM = c.getDouble(3),
                        recordedAt = c.getLong(4)
                    )
                }
            }

            val now = if (location.time > 0L) location.time else System.currentTimeMillis()
            val previous = last
            var movedM = 0.0
            var accept = true

            if (previous != null) {
                val result = FloatArray(1)
                Location.distanceBetween(
                    previous.latitude, previous.longitude,
                    location.latitude, location.longitude,
                    result
                )
                movedM = result[0].toDouble()

                val dtSec = max(1.0, (now - previous.recordedAt).coerceAtLeast(0L) / 1000.0)
                val accuracyAllowance = (previous.accuracyM + location.accuracy.toDouble()).coerceAtLeast(20.0) * 3.0
                // 75 m/s = 270 km/h. We intentionally keep vehicle travel valid.
                val plausibleDistance = 75.0 * dtSec + accuracyAllowance + 120.0
                if (movedM > plausibleDistance) accept = false

                // Ignore tiny jitter unless enough time has passed to keep the track alive.
                if (movedM < 2.0 && dtSec < 12.0) accept = false
            }

            if (accept) {
                ContentValues().also { v ->
                    v.put("walk_id", walkId)
                    v.put("lat", location.latitude)
                    v.put("lon", location.longitude)
                    v.put("accuracy", location.accuracy.toDouble())
                    v.put("recorded_at", now)
                    db.insertOrThrow("track_points", null, v)
                }

                if (previous != null && movedM > 0.0) {
                    db.execSQL(
                        "UPDATE walks SET distance_m = distance_m + ? WHERE id = ?",
                        arrayOf(movedM, walkId)
                    )
                }
            }

            var distance = 0.0
            db.rawQuery("SELECT distance_m FROM walks WHERE id = ?", arrayOf(walkId.toString())).use { c ->
                if (c.moveToFirst()) distance = c.getDouble(0)
            }
            db.setTransactionSuccessful()
            return distance
        } finally {
            db.endTransaction()
        }
    }

    fun trackPoints(): List<TrackPoint> {
        val result = ArrayList<TrackPoint>()
        readableDatabase.rawQuery(
            "SELECT walk_id, lat, lon, accuracy, recorded_at FROM track_points ORDER BY walk_id, id",
            null
        ).use { c ->
            while (c.moveToNext()) {
                result += TrackPoint(
                    walkId = c.getLong(0),
                    latitude = c.getDouble(1),
                    longitude = c.getDouble(2),
                    accuracyM = c.getDouble(3),
                    recordedAt = c.getLong(4)
                )
            }
        }
        return result
    }

    fun walks(): List<WalkRecord> {
        val result = ArrayList<WalkRecord>()
        readableDatabase.rawQuery(
            "SELECT id, started_at, ended_at, distance_m FROM walks ORDER BY started_at DESC",
            null
        ).use { c ->
            while (c.moveToNext()) {
                result += WalkRecord(
                    id = c.getLong(0),
                    startedAt = c.getLong(1),
                    endedAt = if (c.isNull(2)) null else c.getLong(2),
                    distanceM = c.getDouble(3)
                )
            }
        }
        return result
    }

    companion object {
        private const val DB_NAME = "life_in_mist.db"
        private const val DB_VERSION = 2
    }
}
