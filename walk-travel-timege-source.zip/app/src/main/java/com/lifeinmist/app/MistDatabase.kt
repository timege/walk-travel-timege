package com.lifeinmist.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.location.Location
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max


data class WalkRecord(
    val id: Long,
    val startedAt: Long,
    val endedAt: Long?,
    val distanceM: Double
)

data class TrackPoint(
    val walkId: Long,
    val latitude: Double,
    val longitude: Double,
    val accuracyM: Double,
    val recordedAt: Long
)

class MistDatabase(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        createSchema(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // v3 deliberately performs NO destructive migration.
        // Every previously explored point is part of the permanent world map and must survive updates.
        if (oldVersion < 2) {
            // Only very old installs may have the legacy explored_points table.
            // Preserve existing walks/track_points whenever they already exist.
            db.execSQL("DROP TABLE IF EXISTS explored_points")
            db.execSQL("CREATE TABLE IF NOT EXISTS walks (id INTEGER PRIMARY KEY AUTOINCREMENT, started_at INTEGER NOT NULL, ended_at INTEGER, distance_m REAL NOT NULL DEFAULT 0)")
            db.execSQL("CREATE TABLE IF NOT EXISTS track_points (id INTEGER PRIMARY KEY AUTOINCREMENT, walk_id INTEGER NOT NULL, lat REAL NOT NULL, lon REAL NOT NULL, accuracy REAL NOT NULL, recorded_at INTEGER NOT NULL, FOREIGN KEY(walk_id) REFERENCES walks(id) ON DELETE CASCADE)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_track_walk ON track_points(walk_id, id)")
        }
    }

    private fun createSchema(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE walks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                started_at INTEGER NOT NULL,
                ended_at INTEGER,
                distance_m REAL NOT NULL DEFAULT 0
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE track_points (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                walk_id INTEGER NOT NULL,
                lat REAL NOT NULL,
                lon REAL NOT NULL,
                accuracy REAL NOT NULL,
                recorded_at INTEGER NOT NULL,
                FOREIGN KEY(walk_id) REFERENCES walks(id) ON DELETE CASCADE
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_track_walk ON track_points(walk_id, id)")
    }

    fun startWalk(): Long {
        val values = ContentValues().apply {
            put("started_at", System.currentTimeMillis())
            put("distance_m", 0.0)
        }
        return writableDatabase.insertOrThrow("walks", null, values)
    }

    fun activeWalk(): WalkRecord? {
        readableDatabase.rawQuery(
            "SELECT id, started_at, ended_at, distance_m FROM walks WHERE ended_at IS NULL ORDER BY id DESC LIMIT 1",
            null
        ).use { c ->
            if (!c.moveToFirst()) return null
            return WalkRecord(
                id = c.getLong(0),
                startedAt = c.getLong(1),
                endedAt = if (c.isNull(2)) null else c.getLong(2),
                distanceM = c.getDouble(3)
            )
        }
    }

    fun finishWalk(walkId: Long) {
        writableDatabase.update(
            "walks",
            ContentValues().apply { put("ended_at", System.currentTimeMillis()) },
            "id = ?",
            arrayOf(walkId.toString())
        )
    }

    /**
     * Saves real movement regardless of transport mode. The only rejected samples are
     * obvious GPS teleports: a jump that is physically implausible for the elapsed time,
     * even after allowing generously for both fixes' reported accuracy.
     */
    fun appendLocation(walkId: Long, location: Location): Double {
        val db = writableDatabase
        db.beginTransaction()
        try {
            var last: TrackPoint? = null
            db.rawQuery(
                "SELECT walk_id, lat, lon, accuracy, recorded_at FROM track_points WHERE walk_id = ? ORDER BY id DESC LIMIT 1",
                arrayOf(walkId.toString())
            ).use { c ->
                if (c.moveToFirst()) {
                    last = TrackPoint(
                        walkId = c.getLong(0),
                        latitude = c.getDouble(1),
                        longitude = c.getDouble(2),
                        accuracyM = c.getDouble(3),
                        recordedAt = c.getLong(4)
                    )
                }
            }

            val now = if (location.time > 0L) location.time else System.currentTimeMillis()
            val previous = last
            var movedM = 0.0
            var accept = true

            if (previous != null) {
                val result = FloatArray(1)
                Location.distanceBetween(
                    previous.latitude, previous.longitude,
                    location.latitude, location.longitude,
                    result
                )
                movedM = result[0].toDouble()

                val dtSec = max(1.0, (now - previous.recordedAt).coerceAtLeast(0L) / 1000.0)
                val accuracyAllowance = (previous.accuracyM + location.accuracy.toDouble()).coerceAtLeast(20.0) * 3.0
                // 75 m/s = 270 km/h. We intentionally keep vehicle travel valid.
                val plausibleDistance = 75.0 * dtSec + accuracyAllowance + 120.0
                if (movedM > plausibleDistance) accept = false

                // Ignore tiny jitter unless enough time has passed to keep the track alive.
                if (movedM < 2.0 && dtSec < 12.0) accept = false
            }

            if (accept) {
                ContentValues().also { v ->
                    v.put("walk_id", walkId)
                    v.put("lat", location.latitude)
                    v.put("lon", location.longitude)
                    v.put("accuracy", location.accuracy.toDouble())
                    v.put("recorded_at", now)
                    db.insertOrThrow("track_points", null, v)
                }

                if (previous != null && movedM > 0.0) {
                    db.execSQL(
                        "UPDATE walks SET distance_m = distance_m + ? WHERE id = ?",
                        arrayOf(movedM, walkId)
                    )
                }
            }

            var distance = 0.0
            db.rawQuery("SELECT distance_m FROM walks WHERE id = ?", arrayOf(walkId.toString())).use { c ->
                if (c.moveToFirst()) distance = c.getDouble(0)
            }
            db.setTransactionSuccessful()
            return distance
        } finally {
            db.endTransaction()
        }
    }

    fun trackPoints(): List<TrackPoint> {
        val result = ArrayList<TrackPoint>()
        readableDatabase.rawQuery(
            "SELECT walk_id, lat, lon, accuracy, recorded_at FROM track_points ORDER BY walk_id, id",
            null
        ).use { c ->
            while (c.moveToNext()) {
                result += TrackPoint(
                    walkId = c.getLong(0),
                    latitude = c.getDouble(1),
                    longitude = c.getDouble(2),
                    accuracyM = c.getDouble(3),
                    recordedAt = c.getLong(4)
                )
            }
        }
        return result
    }


    /**
     * Exports all permanently explored movement as a portable JSON document.
     * The backup is intentionally independent of the map provider/style.
     */
    fun exportProgressJson(): String {
        val root = JSONObject()
            .put("format", "walk-travel-timege-progress")
            .put("version", 1)
            .put("createdAt", System.currentTimeMillis())

        val walksJson = JSONArray()
        readableDatabase.rawQuery(
            "SELECT id, started_at, ended_at, distance_m FROM walks ORDER BY id",
            null
        ).use { walksCursor ->
            while (walksCursor.moveToNext()) {
                val walkId = walksCursor.getLong(0)
                val walkJson = JSONObject()
                    .put("startedAt", walksCursor.getLong(1))
                    .put("distanceM", walksCursor.getDouble(3))

                if (!walksCursor.isNull(2)) {
                    walkJson.put("endedAt", walksCursor.getLong(2))
                }

                val pointsJson = JSONArray()
                readableDatabase.rawQuery(
                    "SELECT lat, lon, accuracy, recorded_at FROM track_points WHERE walk_id = ? ORDER BY id",
                    arrayOf(walkId.toString())
                ).use { pointCursor ->
                    while (pointCursor.moveToNext()) {
                        pointsJson.put(
                            JSONObject()
                                .put("lat", pointCursor.getDouble(0))
                                .put("lon", pointCursor.getDouble(1))
                                .put("accuracy", pointCursor.getDouble(2))
                                .put("recordedAt", pointCursor.getLong(3))
                        )
                    }
                }

                walkJson.put("points", pointsJson)
                walksJson.put(walkJson)
            }
        }

        root.put("walks", walksJson)
        return root.toString()
    }

    /**
     * Merges a progress backup into the current database without deleting anything.
     * Duplicate GPS samples are skipped by their original timestamp, so importing the
     * same backup twice does not keep growing the permanent map.
     *
     * @return number of new track points restored.
     */
    fun importProgressJson(rawJson: String): Int {
        val root = JSONObject(rawJson)
        require(root.optString("format") == "walk-travel-timege-progress") {
            "Unsupported backup format"
        }
        require(root.optInt("version", 0) == 1) {
            "Unsupported backup version"
        }

        val db = writableDatabase
        val existingTimes = HashSet<Long>()
        db.rawQuery("SELECT recorded_at FROM track_points", null).use { cursor ->
            while (cursor.moveToNext()) existingTimes += cursor.getLong(0)
        }

        var insertedPoints = 0
        val walksJson = root.optJSONArray("walks") ?: JSONArray()

        db.beginTransaction()
        try {
            for (i in 0 until walksJson.length()) {
                val walkJson = walksJson.optJSONObject(i) ?: continue
                val pointsJson = walkJson.optJSONArray("points") ?: continue
                if (pointsJson.length() == 0) continue

                val freshPoints = ArrayList<JSONObject>()
                for (j in 0 until pointsJson.length()) {
                    val point = pointsJson.optJSONObject(j) ?: continue
                    val recordedAt = point.optLong("recordedAt", Long.MIN_VALUE)
                    if (recordedAt == Long.MIN_VALUE || existingTimes.contains(recordedAt)) continue
                    freshPoints += point
                    existingTimes += recordedAt
                }
                if (freshPoints.isEmpty()) continue

                val startedAt = walkJson.optLong("startedAt", freshPoints.first().optLong("recordedAt"))
                // An imported session must never become the app's currently active recording.
                val endedAt = if (walkJson.has("endedAt")) {
                    walkJson.optLong("endedAt", startedAt)
                } else {
                    freshPoints.last().optLong("recordedAt", startedAt)
                }

                val walkValues = ContentValues().apply {
                    put("started_at", startedAt)
                    put("ended_at", endedAt)
                    put("distance_m", walkJson.optDouble("distanceM", 0.0))
                }
                val newWalkId = db.insertOrThrow("walks", null, walkValues)

                freshPoints.forEach { point ->
                    val pointValues = ContentValues().apply {
                        put("walk_id", newWalkId)
                        put("lat", point.getDouble("lat"))
                        put("lon", point.getDouble("lon"))
                        put("accuracy", point.optDouble("accuracy", 0.0))
                        put("recorded_at", point.getLong("recordedAt"))
                    }
                    db.insertOrThrow("track_points", null, pointValues)
                    insertedPoints++
                }
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }

        return insertedPoints
    }

    fun walks(): List<WalkRecord> {
        val result = ArrayList<WalkRecord>()
        readableDatabase.rawQuery(
            "SELECT id, started_at, ended_at, distance_m FROM walks ORDER BY started_at DESC",
            null
        ).use { c ->
            while (c.moveToNext()) {
                result += WalkRecord(
                    id = c.getLong(0),
                    startedAt = c.getLong(1),
                    endedAt = if (c.isNull(2)) null else c.getLong(2),
                    distanceM = c.getDouble(3)
                )
            }
        }
        return result
    }

    companion object {
        private const val DB_NAME = "life_in_mist.db"
        private const val DB_VERSION = 3
    }
}
