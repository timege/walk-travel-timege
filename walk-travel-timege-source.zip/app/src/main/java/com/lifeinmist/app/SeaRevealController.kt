package com.lifeinmist.app

import android.os.Handler
import android.os.Looper
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.sources.VectorSource
import org.maplibre.geojson.MultiPolygon
import org.maplibre.geojson.Polygon

/** Ocean geometry comes from the same loaded tiles as the map, including offline tiles. */
data class SeaPolygon(val rings: List<List<LatLng>>)

class SeaRevealController(private val map: MapLibreMap, private val fog: FogOverlay) {
    private val handler = Handler(Looper.getMainLooper())
    private var moving = false
    private var closed = false
    private var scheduled = false
    private val refresh = Runnable {
        scheduled = false
        if (!closed && !moving) readOcean()
    }

    fun onCameraMove() {
        moving = true
        handler.removeCallbacks(refresh)
        scheduled = false
    }

    fun onCameraIdle() { moving = false; requestRefresh() }

    fun requestRefresh() {
        if (closed || moving || scheduled) return
        scheduled = true
        handler.postDelayed(refresh, 180)
    }

    private fun readOcean() {
        val style = map.style ?: return
        if (!style.isFullyLoaded) return
        val result = runCatching {
            val polygons = ArrayList<SeaPolygon>()
            for (source in style.sources.filterIsInstance<VectorSource>()) {
                val features = source.querySourceFeatures(arrayOf("water"),
                    Expression.eq(Expression.get("class"), Expression.literal("ocean")))
                for (feature in features) {
                    val parts = when (val geometry = feature.geometry()) {
                        is Polygon -> listOf(geometry.coordinates())
                        is MultiPolygon -> geometry.coordinates()
                        else -> continue
                    }
                    for (part in parts) {
                        val rings = part.map { ring -> ring.map { LatLng(it.latitude(), it.longitude()) } }
                        if (rings.isNotEmpty() && rings.first().size >= 3) polygons.add(SeaPolygon(rings))
                    }
                }
            }
            polygons
        }
        // A transient loading failure must not replace the last valid geometry.
        result.onSuccess { fog.setSeaPolygons(it) }
    }

    fun close() { closed = true; handler.removeCallbacks(refresh) }
}
