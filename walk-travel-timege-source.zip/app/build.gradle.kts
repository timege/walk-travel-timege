plugins {
    id("com.android.application")
}

android {
    namespace = "com.lifeinmist.app"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.lifeinmist.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 19
        versionName = "0.6.4"
    }

    // Always use the persistent debug keystore restored by GitHub Actions.
    // This makes every CI APK update-compatible with the previous one.
    signingConfigs {
        getByName("debug") {
            storeFile = file("${System.getProperty("user.home")}/.android/debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("debug")
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.19.0")
    implementation("androidx.appcompat:appcompat:1.8.0")
    implementation("androidx.activity:activity:1.13.0")
    implementation("org.maplibre.gl:android-sdk:13.6.1")
    implementation("com.google.android.gms:play-services-location:21.4.0")
}
