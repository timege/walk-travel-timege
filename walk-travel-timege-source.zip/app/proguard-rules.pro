# MapLibre's native (JNI) bridge calls back into these classes by exact name/signature.
# The SDK ships its own consumer-rules.pro, but keeping the whole package is cheap
# insurance against anything that slips through — this only costs a little shrinkage,
# never correctness.
-keep class org.maplibre.android.** { *; }
-dontwarn org.maplibre.android.**

# Play Services location: keep the public API surface and Parcelable plumbing.
-keep class com.google.android.gms.location.** { *; }
-keep class com.google.android.gms.common.** { *; }
-dontwarn com.google.android.gms.**

# Parcelable CREATOR fields are looked up by reflection at runtime.
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# Keep source file + line numbers in stack traces for crash reports, without
# blocking obfuscation of the actual class/method names.
-keepattributes SourceFile, LineNumberTable
-renamesourcefileattribute SourceFile
