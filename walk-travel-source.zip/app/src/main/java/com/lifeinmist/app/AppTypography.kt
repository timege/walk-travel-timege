package com.lifeinmist.app

import android.graphics.Typeface

/** Android's native sans-serif family (Roboto on stock Android); no font download needed. */
object AppTypography {
    val body: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    val emphasis: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
}
