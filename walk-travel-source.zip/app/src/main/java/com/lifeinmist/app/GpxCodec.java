package com.lifeinmist.app;

import java.io.*;
import java.time.Instant;
import java.util.*;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.*;
import org.xml.sax.ext.DefaultHandler2;

/** GPX 1.0/1.1 tracks and routes. Never writes exploration data. */
public final class GpxCodec {
    public static final int MAX_POINTS = 200_000;
    public static final long MAX_BYTES = 20_000_000;
    public static final class Point {
        public final double latitude, longitude;
        public final Long time;
        public final Double elevation;
        public Point(double latitude, double longitude, Long time, Double elevation) {
            if (!Double.isFinite(latitude) || !Double.isFinite(longitude)
                    || latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180)
                throw new IllegalArgumentException("Invalid GPX coordinates");
            this.latitude = latitude; this.longitude = longitude;
            this.time = time; this.elevation = elevation;
        }
    }
    public static final class Track {
        public String name;
        public final List<List<Point>> segments = new ArrayList<>();
        public Track(String name) { this.name = name; }
    }

    public static List<Track> read(InputStream input) throws Exception {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        factory.setNamespaceAware(true);
        XMLReader reader = factory.newSAXParser().getXMLReader();
        reader.setFeature("http://xml.org/sax/features/external-general-entities", false);
        reader.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        Handler handler = new Handler();
        reader.setContentHandler(handler);
        reader.setErrorHandler(handler);
        reader.setEntityResolver(handler);
        // Reject DTDs before any entity expansion, including internal entities.
        reader.setProperty("http://xml.org/sax/properties/lexical-handler", handler);
        reader.parse(new InputSource(new FilterInputStream(input) {
            long count;
            private void counted(int n) throws IOException {
                if (n > 0 && (count += n) > MAX_BYTES) throw new IOException("GPX file exceeds 20 MB");
            }
            @Override public int read() throws IOException {
                int b = in.read(); counted(b < 0 ? 0 : 1); return b;
            }
            @Override public int read(byte[] b, int offset, int length) throws IOException {
                int n = in.read(b, offset, length); counted(n); return n;
            }
        }));
        if (handler.tracks.isEmpty()) throw new IOException("No tracks or routes found in this GPX file");
        return handler.tracks;
    }

    private static final class Handler extends DefaultHandler2 {
        final List<Track> tracks = new ArrayList<>();
        final List<String> path = new ArrayList<>();
        final StringBuilder text = new StringBuilder();
        Track track;
        List<Point> segment;
        double lat, lon;
        Long time;
        Double elevation;
        int count;
        String namespace;
        @Override public void startDTD(String name, String publicId, String systemId) throws SAXException {
            throw new SAXException("DTD is not allowed in GPX");
        }
        @Override public InputSource resolveEntity(String publicId, String systemId) throws SAXException {
            throw new SAXException("External entities are not allowed");
        }
        private boolean at(String value) { return String.join("/", path).equals(value); }
        @Override public void startElement(String uri, String local, String qname, Attributes a) throws SAXException {
            if (path.isEmpty()) {
                if (!local.equals("gpx") || !(uri.isEmpty() || uri.equals("http://www.topografix.com/GPX/1/1")
                        || uri.equals("http://www.topografix.com/GPX/1/0"))) throw new SAXException("Not a GPX document");
                namespace = uri;
            }
            if (path.size() >= 32) throw new SAXException("GPX nesting is too deep");
            path.add(uri.equals(namespace) ? local : "#extension");
            text.setLength(0);
            if (at("gpx/trk") || at("gpx/rte")) {
                track = new Track("Imported route " + (tracks.size() + 1));
                if (at("gpx/rte")) { segment = new ArrayList<>(); track.segments.add(segment); }
            } else if (at("gpx/trk/trkseg")) {
                segment = new ArrayList<>(); track.segments.add(segment);
            } else if (at("gpx/trk/trkseg/trkpt") || at("gpx/rte/rtept")) {
                if (++count > MAX_POINTS) throw new SAXException("GPX exceeds 200,000 points");
                try {
                    lat = Double.parseDouble(a.getValue("lat")); lon = Double.parseDouble(a.getValue("lon"));
                    new Point(lat, lon, null, null);
                } catch (RuntimeException e) { throw new SAXException("Invalid GPX coordinates", e); }
                time = null; elevation = null;
            }
        }
        @Override public void characters(char[] ch, int start, int length) throws SAXException {
            if (text.length() + length > 65_536) throw new SAXException("GPX text is too long");
            text.append(ch, start, length);
        }
        @Override public void endElement(String uri, String local, String qname) throws SAXException {
            String value = text.toString().trim();
            if (at("gpx/trk/name") || at("gpx/rte/name")) {
                if (!value.isEmpty()) track.name = value.substring(0, Math.min(200, value.length()));
            } else if (at("gpx/trk/trkseg/trkpt/time") || at("gpx/rte/rtept/time")) {
                try { time = Instant.parse(value).toEpochMilli(); }
                catch (RuntimeException e) { throw new SAXException("Invalid GPX timestamp", e); }
            } else if (at("gpx/trk/trkseg/trkpt/ele") || at("gpx/rte/rtept/ele")) {
                try {
                    elevation = Double.parseDouble(value);
                    if (!Double.isFinite(elevation)) throw new IllegalArgumentException();
                } catch (RuntimeException e) { throw new SAXException("Invalid GPX elevation", e); }
            } else if (at("gpx/trk/trkseg/trkpt") || at("gpx/rte/rtept")) {
                segment.add(new Point(lat, lon, time, elevation));
            } else if (at("gpx/trk") || at("gpx/rte")) {
                track.segments.removeIf(List::isEmpty);
                if (!track.segments.isEmpty()) tracks.add(track);
                track = null; segment = null;
            }
            path.remove(path.size() - 1);
            text.setLength(0);
        }
        @Override public void error(SAXParseException e) throws SAXException { throw e; }
        @Override public void fatalError(SAXParseException e) throws SAXException { throw e; }
    }

    public static void write(Writer out, Track track) throws IOException {
        begin(out, track.name);
        for (List<Point> segment : track.segments) {
            out.write("<trkseg>\n");
            for (Point point : segment) writePoint(out, point);
            out.write("</trkseg>\n");
        }
        end(out);
    }
    public static void begin(Writer out, String name) throws IOException {
        out.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
            + "<gpx version=\"1.1\" creator=\"Walk Travel Timege\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n"
            + "<trk><name>" + escape(name) + "</name><type>walking</type>\n");
    }
    public static void writePoint(Writer out, Point p) throws IOException {
        out.write("<trkpt lat=\"" + p.latitude + "\" lon=\"" + p.longitude + "\">");
        if (p.elevation != null) out.write("<ele>" + p.elevation + "</ele>");
        if (p.time != null) out.write("<time>" + Instant.ofEpochMilli(p.time) + "</time>");
        out.write("</trkpt>\n");
    }
    public static void end(Writer out) throws IOException { out.write("</trk></gpx>\n"); }
    private static String escape(String s) {
        StringBuilder clean = new StringBuilder();
        s.codePoints().filter(c -> c == 9 || c == 10 || c == 13 || c >= 32 && c <= 0xD7FF
            || c >= 0xE000 && c <= 0xFFFD || c >= 0x10000 && c <= 0x10FFFF).forEach(clean::appendCodePoint);
        return clean.toString().replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
