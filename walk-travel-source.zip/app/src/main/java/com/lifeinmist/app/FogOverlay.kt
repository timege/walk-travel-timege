package com.lifeinmist.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import kotlin.math.hypot
import kotlin.math.max

/**
 * Lightweight permanent mask for unexplored territory.
 *
 * The unexplored area is a single, uniform, translucent cool grey-blue layer.
 * Explored routes are fully transparent and have a softly feathered edge.
 *
 * During pan / zoom / rotate the app only transforms ONE cached bitmap, which is
 * much lighter than rebuilding a field of cloud sprites every frame.
 */
class FogOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
        set(value) {
            field = value
            markDirty()
        }

    private var track: List<TrackPoint> = emptyList()
    private var trackSegments: Collection<List<TrackPoint>> = emptyList()
    private var trackChunks: List<List<TrackChunk>> = emptyList()
    private var currentLocation: LatLng? = null
    // Visual hints only. These centers never enter track data or the progress database.
    private var placePreviewCenters: List<LatLng> = emptyList()
    private var seaPolygons: List<SeaPolygon> = emptyList()

    private var cacheBitmap: Bitmap? = null
    private var spareBitmap: Bitmap? = null
    private val chunkCoordinates = FloatArray(128 * 2)
    private var cacheCenter: LatLng? = null
    private var cacheZoom: Double = 0.0
    private var cacheBearing: Double = 0.0
    private var cacheDirty = true
    private var cameraMoving = false
    private var cacheOriginX = 0f
    private var cacheOriginY = 0f

    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    private val fogFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(242, 220, 231, 241)
        style = Paint.Style.FILL
    }

    private val edgeFeatherPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    }

    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val softCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    }

    private val clearCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    // Deliberately NOT anti-aliased. Ocean polygons are clipped per vector tile, so
    // adjacent tiles' water shapes are drawn as separate paths that exactly abut (or
    // slightly overlap, per tile buffering) at tile edges. Anti-aliased CLEAR draws
    // only clear their own partial edge coverage per call, so two abutting AA'd shapes
    // drawn separately leave a thin uncleared seam of fog along every tile boundary —
    // visible as a faint grid over open water. A hard edge here has no partial coverage
    // to leave behind, so no seam; the coastline itself already has no feather anyway.
    private val clearPolygonPaint = Paint().apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    // Static illustrated exploration pattern for unexplored territory.
    // It is drawn through the alpha of the fog cache, so explored areas remain fully clear.
    private var patternBitmap: Bitmap? = null
    private var patternShader: BitmapShader? = null
    private val patternMatrix = Matrix()
    private val patternPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    // Scratch objects for the "screen minus cache rectangle" fog fill below — reused
    // every frame to avoid per-draw allocation.
    private val cacheRectMatrix = Matrix()
    private val cacheRectCorners = FloatArray(8)
    private val cacheRectPath = Path()
    private val screenRectPath = Path()
    private val outsideCachePath = Path()

    init {
        isClickable = false
        isFocusable = false
        loadPattern()
    }

    private fun loadPattern() {
        val opts = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        patternBitmap = BitmapFactory.decodeResource(resources, R.drawable.fog_pattern, opts)
        patternShader = patternBitmap?.let {
            BitmapShader(it, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        }
    }

    fun setTrackPoints(points: List<TrackPoint>) {
        if (track == points) return
        track = points
        trackSegments = points.groupBy { it.walkId }.values
        trackChunks = trackSegments.map { segment ->
            val chunks = ArrayList<TrackChunk>()
            var start = 0
            while (start < segment.size) {
                val end = minOf(start + 128, segment.size)
                chunks.add(TrackChunk(segment.subList(start, end)))
                if (end == segment.size) break
                start = end - 1
            }
            chunks
        }
        markDirty()
    }

    fun setSeaPolygons(polygons: List<SeaPolygon>) {
        if (seaPolygons == polygons) return
        seaPolygons = polygons
        markDirty()
    }

    fun setPlacePreviews(places: List<DiscoveryPlace>) {
        val centers = places.map { LatLng(it.lat, it.lon) }
        if (placePreviewCenters == centers) return
        placePreviewCenters = centers
        markDirty()
    }

    fun setCurrentLocation(location: LatLng?) {
        if (currentLocation == location) return
        currentLocation = location
        markDirty()
    }

    fun onCameraMove() {
        cameraMoving = true
        postInvalidateOnAnimation()
    }

    fun onCameraIdle() {
        cameraMoving = false
        // Translation/rotation alone do not invalidate a world-anchored bitmap.
        // Refresh resolution only after a meaningful zoom change.
        val zoom = map?.cameraPosition?.zoom
        if (zoom != null && kotlin.math.abs(zoom - cacheZoom) > 0.5) cacheDirty = true
        postInvalidateOnAnimation()
    }

    private fun markDirty() {
        cacheDirty = true
        postInvalidateOnAnimation()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        cacheDirty = true
        if (w > 0 && h > 0) postInvalidateOnAnimation()
    }

    override fun onDetachedFromWindow() {
        cacheBitmap?.recycle()
        spareBitmap?.recycle()
        cacheBitmap = null
        spareBitmap = null
        patternBitmap?.recycle()
        patternBitmap = null
        patternShader = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        // Re-anchor during a gesture too, before the cached footprint runs out.
        rebuildCacheIfPossible()

        val bitmap = cacheBitmap
        val currentMap = map
        val cachedCenter = cacheCenter
        if (bitmap == null || currentMap == null || cachedCenter == null) {
            canvas.drawPaint(fogFillPaint)
            return
        }
        val camera = currentMap.cameraPosition
        val cachedCenterOnScreen = currentMap.projection.toScreenLocation(cachedCenter)
        val mapScale = FogTransform.scale(camera.zoom, cacheZoom).toFloat()
        val rotation = FogTransform.rotation(camera.bearing, cacheBearing).toFloat()

        // Fill everywhere outside the cache rectangle, computed as an ordinary filled
        // Path (screen rect MINUS the cache rect, via a Path boolean op) rather than a
        // difference-mode canvas clip. clipOutRect/clipPath(DIFFERENCE) has a history of
        // unreliable behavior on hardware-accelerated canvases, especially for the very
        // small/degenerate rectangles this cache rect becomes at extreme zoom-out — a
        // plain filled Path has no such caveat. Computed and drawn here, before any
        // canvas transform is applied, so it's already in plain device/screen space.
        cacheRectCorners[0] = -bitmap.width / 2f; cacheRectCorners[1] = -bitmap.height / 2f
        cacheRectCorners[2] = bitmap.width / 2f; cacheRectCorners[3] = -bitmap.height / 2f
        cacheRectCorners[4] = bitmap.width / 2f; cacheRectCorners[5] = bitmap.height / 2f
        cacheRectCorners[6] = -bitmap.width / 2f; cacheRectCorners[7] = bitmap.height / 2f
        cacheRectMatrix.reset()
        cacheRectMatrix.postScale(mapScale / CACHE_PIXEL_SCALE, mapScale / CACHE_PIXEL_SCALE)
        if (rotation != 0f) cacheRectMatrix.postRotate(rotation)
        cacheRectMatrix.postTranslate(cachedCenterOnScreen.x, cachedCenterOnScreen.y)
        cacheRectMatrix.mapPoints(cacheRectCorners)
        cacheRectPath.reset()
        cacheRectPath.moveTo(cacheRectCorners[0], cacheRectCorners[1])
        cacheRectPath.lineTo(cacheRectCorners[2], cacheRectCorners[3])
        cacheRectPath.lineTo(cacheRectCorners[4], cacheRectCorners[5])
        cacheRectPath.lineTo(cacheRectCorners[6], cacheRectCorners[7])
        cacheRectPath.close()
        screenRectPath.reset()
        screenRectPath.addRect(0f, 0f, width.toFloat(), height.toFloat(), Path.Direction.CW)
        outsideCachePath.reset()
        outsideCachePath.op(screenRectPath, cacheRectPath, Path.Op.DIFFERENCE)
        canvas.drawPath(outsideCachePath, fogFillPaint)

        canvas.save()
        canvas.translate(cachedCenterOnScreen.x, cachedCenterOnScreen.y)
        if (rotation != 0f) canvas.rotate(rotation)
        canvas.scale(mapScale / CACHE_PIXEL_SCALE, mapScale / CACHE_PIXEL_SCALE)
        canvas.drawBitmap(bitmap, -bitmap.width / 2f, -bitmap.height / 2f, bitmapPaint)
        drawPattern(canvas, bitmap)
        canvas.restore()
    }

    /** Draw a quiet, map-like illustrated pattern only over unexplored pixels. */
    private fun drawPattern(canvas: Canvas, bitmap: Bitmap) {
        val shader = patternShader ?: return
        patternMatrix.reset()
        patternMatrix.setScale(PATTERN_SCALE, PATTERN_SCALE)
        // Anchor the tile to the cached map bitmap. It therefore pans/zooms/rotates with the map.
        patternMatrix.postTranslate(-bitmap.width / 2f, -bitmap.height / 2f)
        shader.setLocalMatrix(patternMatrix)
        patternPaint.shader = shader
        patternPaint.alpha = PATTERN_ALPHA

        // cacheBitmap already contains the exact fog alpha. DST_IN clips the pattern to fog.
        val save = canvas.saveLayer(
            -bitmap.width / 2f, -bitmap.height / 2f,
            bitmap.width / 2f, bitmap.height / 2f, null
        )
        canvas.drawRect(
            -bitmap.width / 2f, -bitmap.height / 2f,
            bitmap.width / 2f, bitmap.height / 2f, patternPaint
        )
        val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        }
        canvas.drawBitmap(bitmap, -bitmap.width / 2f, -bitmap.height / 2f, maskPaint)
        canvas.restoreToCount(save)
    }

    private fun cacheStillCoversView(): Boolean {
        val bitmap = cacheBitmap ?: return false
        val currentMap = map ?: return false
        val cachedCenter = cacheCenter ?: return false
        val camera = currentMap.cameraPosition
        val center = currentMap.projection.toScreenLocation(cachedCenter)
        val mapScale = FogTransform.scale(camera.zoom, cacheZoom).toFloat()

        val shownW = bitmap.width / CACHE_PIXEL_SCALE * mapScale
        val shownH = bitmap.height / CACHE_PIXEL_SCALE * mapScale
        return FogTransform.covers(width.toDouble(), height.toDouble(),
            center.x.toDouble(), center.y.toDouble(), shownW / 2.0, shownH / 2.0,
            FogTransform.rotation(camera.bearing, cacheBearing))
    }

    private fun rebuildCacheIfPossible() {
        // During gestures reuse the texture while it covers the screen. GPS changes
        // and resolution refresh wait for idle; a genuinely uncovered viewport still
        // re-anchors immediately so distant explored areas do not disappear.
        if (cacheBitmap != null && cacheStillCoversView() && (cameraMoving || !cacheDirty)) return
        val currentMap = map ?: return
        if (width <= 0 || height <= 0) return

        val camera = currentMap.cameraPosition
        val target = camera.target ?: return
        val origin = currentMap.projection.toScreenLocation(target)
        cacheOriginX = origin.x
        cacheOriginY = origin.y
        val cacheW = max(1, (width * CACHE_OVERSCAN * CACHE_PIXEL_SCALE).toInt())
        val cacheH = max(1, (height * CACHE_OVERSCAN * CACHE_PIXEL_SCALE).toInt())
        // Never draw into the currently displayed bitmap. Alternate two buffers.
        val newBitmap = spareBitmap?.takeIf {
            !it.isRecycled && it.width == cacheW && it.height == cacheH
        } ?: Bitmap.createBitmap(cacheW, cacheH, Bitmap.Config.ARGB_8888)
        spareBitmap = null
        // Essential for reuse: otherwise semi-transparent fills accumulate opacity.
        newBitmap.eraseColor(Color.TRANSPARENT)
        val offscreen = Canvas(newBitmap)

        // This canvas already targets an isolated bitmap; an extra layer doubles work.
        drawUniformMask(offscreen, cacheW, cacheH)
        drawSeaOpenings(offscreen, currentMap, cacheW, cacheH)
        if (track.isNotEmpty()) drawExploredRoutes(offscreen, currentMap, cacheW, cacheH)
        drawPlacePreviews(offscreen, currentMap, cacheW, cacheH)
        currentLocation?.let { drawTemporaryOpening(offscreen, currentMap, it, cacheW, cacheH) }

        val old = cacheBitmap
        cacheBitmap = newBitmap
        cacheCenter = LatLng(target.latitude, target.longitude)
        cacheZoom = camera.zoom
        cacheBearing = camera.bearing
        cacheDirty = false
        // A differently sized old buffer will be discarded on the next resize.
        // Do not recycle here: the renderer may still reference its last frame.
        spareBitmap = old
    }

    private fun drawUniformMask(canvas: Canvas, cacheW: Int, cacheH: Int) {
        canvas.drawRect(0f, 0f, cacheW.toFloat(), cacheH.toFloat(), fogFillPaint)
    }

    private fun drawExploredRoutes(canvas: Canvas, currentMap: MapLibreMap, cacheW: Int, cacheH: Int) {
        // Includes the entire oversized cache, not just the current screen, plus
        // the maximum 300-cache-pixel feather/stroke reach.
        val margin = 300f / CACHE_PIXEL_SCALE
        val left = cacheOriginX - cacheW / (2f * CACHE_PIXEL_SCALE) - margin
        val right = cacheOriginX + cacheW / (2f * CACHE_PIXEL_SCALE) + margin
        val top = cacheOriginY - cacheH / (2f * CACHE_PIXEL_SCALE) - margin
        val bottom = cacheOriginY + cacheH / (2f * CACHE_PIXEL_SCALE) + margin
        for (chunks in trackChunks) {
            if (chunks.isEmpty()) continue
            val visible = chunks.filter { it.mayIntersect(currentMap, left, top, right, bottom) }
            if (visible.isEmpty()) continue
            val first = chunks.first().points.first()
            val representativeRadiusPx = radiusMetersToPixels(currentMap,
                first.latitude, first.longitude, REVEAL_RADIUS_M) * CACHE_PIXEL_SCALE

            val path = Path()
            for (chunk in visible) {
                chunk.points.forEachIndexed { index, point ->
                    val screen = currentMap.projection.toScreenLocation(LatLng(point.latitude, point.longitude))
                    chunkCoordinates[2 * index] = (screen.x - cacheOriginX) * CACHE_PIXEL_SCALE + cacheW / 2f
                    chunkCoordinates[2 * index + 1] = (screen.y - cacheOriginY) * CACHE_PIXEL_SCALE + cacheH / 2f
                }
                val kept = ScreenPolyline.simplify(chunkCoordinates, chunk.points.size, 0.15)
                kept.forEachIndexed { index, point ->
                    val x = chunkCoordinates[2 * point]
                    val y = chunkCoordinates[2 * point + 1]
                    if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
            }

            val coreWidth = (representativeRadiusPx * 2f).coerceIn(9f, 550f)
            for (step in FEATHER_STEPS downTo 1) {
                val progress = step / FEATHER_STEPS.toFloat()
                edgeFeatherPaint.strokeWidth =
                    (coreWidth + progress * FEATHER_EXTRA_PX).coerceAtMost(600f)
                edgeFeatherPaint.alpha = (FEATHER_MAX_ALPHA * (1f - progress)).toInt()
                    .coerceIn(1, FEATHER_MAX_ALPHA)
                canvas.drawPath(path, edgeFeatherPaint)
            }
            clearPaint.strokeWidth = coreWidth
            canvas.drawPath(path, clearPaint)

            if (chunks.size == 1 && chunks.first().points.size == 1) {
                val only = first
                val screen = currentMap.projection.toScreenLocation(LatLng(only.latitude, only.longitude))
                val p = screenToCache(screen.x, screen.y, cacheW, cacheH)
                clearCircle(canvas, p.first, p.second, representativeRadiusPx)
            }
        }
    }

    private fun drawSeaOpenings(canvas: Canvas, currentMap: MapLibreMap, cacheW: Int, cacheH: Int) {
        val targetLongitude = currentMap.cameraPosition.target?.longitude ?: return
        for (polygon in seaPolygons) {
            // Separate paths preserve islands (inner rings) and avoid cancelling
            // overlapping ocean polygons at vector-tile boundaries.
            val path = Path().apply { fillType = Path.FillType.EVEN_ODD }
            for (ring in polygon.rings) {
                if (ring.size < 3) continue
                var previousLongitude = targetLongitude
                ring.forEachIndexed { index, point ->
                    val longitude = point.longitude + 360.0 * kotlin.math.round(
                        (previousLongitude - point.longitude) / 360.0)
                    previousLongitude = longitude
                    val screen = currentMap.projection.toScreenLocation(LatLng(point.latitude, longitude))
                    val x = (screen.x - cacheOriginX) * CACHE_PIXEL_SCALE + cacheW / 2f
                    val y = (screen.y - cacheOriginY) * CACHE_PIXEL_SCALE + cacheH / 2f
                    if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
            }
            canvas.drawPath(path, clearPolygonPaint)
        }
    }

    private fun drawPlacePreviews(canvas: Canvas, currentMap: MapLibreMap, cacheW: Int, cacheH: Int) {
        for (center in placePreviewCenters) {
            val screen = currentMap.projection.toScreenLocation(center)
            // Keep the radius geographic: no minimum screen size that would reveal
            // kilometres around a point when the user zooms out to the whole island.
            val north = currentMap.projection.toScreenLocation(LatLng(
                center.latitude + Math.toDegrees(PLACE_PREVIEW_RADIUS_M / 6_378_137.0),
                center.longitude
            ))
            val radius = hypot(screen.x - north.x, screen.y - north.y) * CACHE_PIXEL_SCALE
            if (!radius.isFinite() || radius <= 0f) continue
            val x = (screen.x - cacheOriginX) * CACHE_PIXEL_SCALE + cacheW / 2f
            val y = (screen.y - cacheOriginY) * CACHE_PIXEL_SCALE + cacheH / 2f
            if (!x.isFinite() || !y.isFinite()) continue
            // Feather extends by at most 10 geographic metres, with a small pixel cap.
            val feather = (radius * (PLACE_PREVIEW_FEATHER_M / PLACE_PREVIEW_RADIUS_M).toFloat())
                .coerceAtMost(FEATHER_EXTRA_PX)
            val reach = radius + feather
            if (x + reach < 0f || y + reach < 0f || x - reach > cacheW || y - reach > cacheH) continue
            clearCircle(canvas, x, y, radius, feather)
        }
    }

    private fun drawTemporaryOpening(
        canvas: Canvas,
        currentMap: MapLibreMap,
        location: LatLng,
        cacheW: Int,
        cacheH: Int
    ) {
        val screen = currentMap.projection.toScreenLocation(location)
        val p = screenToCache(screen.x, screen.y, cacheW, cacheH)
        val radius = (radiusMetersToPixels(
            currentMap,
            location.latitude,
            location.longitude,
            CURRENT_OPENING_RADIUS_M
        ) * CACHE_PIXEL_SCALE).coerceAtLeast(17f)
        clearCircle(canvas, p.first, p.second, radius)
    }

    private fun screenToCache(x: Float, y: Float, cacheW: Int, cacheH: Int): Pair<Float, Float> {
        val cx = (x - cacheOriginX) * CACHE_PIXEL_SCALE + cacheW / 2f
        val cy = (y - cacheOriginY) * CACHE_PIXEL_SCALE + cacheH / 2f
        return cx to cy
    }

    private fun clearCircle(canvas: Canvas, x: Float, y: Float, radius: Float, feather: Float = FEATHER_EXTRA_PX) {
        for (i in FEATHER_STEPS downTo 1) {
            val t = i / FEATHER_STEPS.toFloat()
            softCirclePaint.alpha = (FEATHER_MAX_ALPHA * (1f - t)).toInt()
                .coerceIn(1, FEATHER_MAX_ALPHA)
            canvas.drawCircle(x, y, radius + t * feather, softCirclePaint)
        }
        canvas.drawCircle(x, y, radius, clearCirclePaint)
        softCirclePaint.alpha = 255
    }

    private fun radiusMetersToPixels(map: MapLibreMap, lat: Double, lon: Double, radiusM: Double): Float {
        val center = map.projection.toScreenLocation(LatLng(lat, lon))
        val latitudeDelta = radiusM / 111_320.0
        val north = map.projection.toScreenLocation(LatLng(lat + latitudeDelta, lon))
        return hypot(center.x - north.x, center.y - north.y).coerceIn(6f, 560f)
    }

    companion object {
        private const val REVEAL_RADIUS_M = 30.0
        private const val CURRENT_OPENING_RADIUS_M = 44.0
        private const val PLACE_PREVIEW_RADIUS_M = 75.0
        private const val PLACE_PREVIEW_FEATHER_M = 10.0
        private const val FEATHER_EXTRA_PX = 22f
        private const val FEATHER_STEPS = 8
        private const val FEATHER_MAX_ALPHA = 54

        // Lower internal resolution keeps panning/zooming light while overscan hides cache edges.
        private const val CACHE_PIXEL_SCALE = 0.32f
        private const val CACHE_OVERSCAN = 4.00f

        // Keep the pattern at its native size; do not enlarge or shrink it.
        private const val PATTERN_SCALE = 1.00f
        private const val PATTERN_ALPHA = 150
    }
}
