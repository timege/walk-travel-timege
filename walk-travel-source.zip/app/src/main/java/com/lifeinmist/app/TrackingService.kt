package com.lifeinmist.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

class TrackingService : Service() {
    private lateinit var fusedLocation: FusedLocationProviderClient
    private lateinit var database: MistDatabase
    private var walkId: Long = -1L
    private var lastWidgetUpdateElapsed = 0L

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val location = result.lastLocation ?: return
            // Report poor fixes too; otherwise the quality badge can only become stale.
            sendBroadcast(Intent(ACTION_GPS_STATUS).setPackage(packageName)
                .putExtra(EXTRA_ACCURACY, if (location.hasAccuracy()) location.accuracy else 0f)
                .putExtra(EXTRA_FIX_NANOS, location.elapsedRealtimeNanos))
            if (location.accuracy > 55f) return
            if (walkId <= 0) return

            val distance = database.appendLocation(walkId, location)
            val discoveries = DiscoveryStore.get(this@TrackingService).discover(location)
            sendBroadcast(
                Intent(ACTION_LOCATION_UPDATE)
                    .setPackage(packageName)
                    .putExtra(EXTRA_LAT, location.latitude)
                    .putExtra(EXTRA_LON, location.longitude)
                    .putExtra(EXTRA_ACCURACY, location.accuracy)
                    .putExtra(EXTRA_DISTANCE, distance)
                    .putExtra(EXTRA_DISCOVERED_NAMES, discoveries.map { it.name }.toTypedArray())
                    .putExtra(EXTRA_DISCOVERED_IDS, discoveries.map { it.id }.toTypedArray())
            )
            if (MainActivity.PLACES_UI_ENABLED && discoveries.isNotEmpty() && !MainActivity.isVisible) {
                showDiscoveryNotification(discoveries)
            }
            val elapsed = SystemClock.elapsedRealtime()
            if (discoveries.isNotEmpty() || elapsed - lastWidgetUpdateElapsed >= 30_000L) {
                lastWidgetUpdateElapsed = elapsed
                WalkWidgetProvider.updateAll(this@TrackingService)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        AppLanguage.initialize(this)
        fusedLocation = LocationServices.getFusedLocationProviderClient(this)
        database = MistDatabase(this)
        ensureNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopTracking()
            ACTION_LANGUAGE -> {
                AppLanguage.initialize(this)
                ensureNotificationChannel()
                if (walkId > 0) getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification())
                else stopSelf(startId)
            }
            else -> startTracking()
        }
        return START_STICKY
    }

    private fun startTracking() {
        walkId = database.activeWalk()?.id ?: database.startWalk()
        startForeground(NOTIFICATION_ID, buildNotification())
        WalkWidgetProvider.updateAll(this)

        val fine = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (fine != PackageManager.PERMISSION_GRANTED && coarse != PackageManager.PERMISSION_GRANTED) {
            stopTracking()
            return
        }

        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 3_000L)
            .setMinUpdateIntervalMillis(1_500L)
            .setMinUpdateDistanceMeters(2f)
            .build()
        fusedLocation.requestLocationUpdates(request, callback, mainLooper)
    }

    private fun stopTracking() {
        fusedLocation.removeLocationUpdates(callback)
        if (walkId <= 0) walkId = database.activeWalk()?.id ?: -1L
        if (walkId > 0) database.finishWalk(walkId)
        WalkWidgetProvider.updateAll(this)
        sendBroadcast(
            Intent(ACTION_TRACKING_STOPPED)
                .setPackage(packageName)
                .putExtra(EXTRA_WALK_ID, walkId)
        )
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun showDiscoveryNotification(discoveries: List<DiscoveryPlace>) {
        val first = discoveries.first()
        val openIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(EXTRA_OPEN_DISCOVERY_ID, first.id)
        }
        val pendingIntent = PendingIntent.getActivity(
            this, first.id.hashCode(), openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val many = discoveries.size > 1
        val title = if (many) {
            tr("${discoveries.size} new places discovered", "Открыто новых мест: ${discoveries.size}")
        } else {
            tr("New place discovered", "Новое место открыто")
        }
        val names = discoveries.joinToString(", ") { it.name }
        getSystemService(NotificationManager::class.java).notify(
            DISCOVERY_NOTIFICATION_BASE + (first.id.hashCode() and 0x3ff),
            NotificationCompat.Builder(this, DISCOVERY_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentTitle(title)
                .setContentText(names)
                .setStyle(NotificationCompat.BigTextStyle().bigText(names))
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .addAction(android.R.drawable.ic_menu_view, tr("View", "Посмотреть"), pendingIntent)
                .build()
        )
    }

    private fun buildNotification() = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_menu_mylocation)
        .setContentTitle("Walk Travel Timege")
        .setContentText(tr("Recording your walk — explore as you go", "Запись прогулки — карта открывается по пути"))
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setContentIntent(
            PendingIntent.getActivity(
                this,
                0,
                Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        )
        .build()

    private fun ensureNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                tr("Active walk", "Активная прогулка"),
                NotificationManager.IMPORTANCE_LOW
            )
        )
        manager.createNotificationChannel(
            NotificationChannel(
                DISCOVERY_CHANNEL_ID,
                tr("Discoveries", "Открытия"),
                NotificationManager.IMPORTANCE_DEFAULT
            )
        )
    }

    override fun onDestroy() {
        fusedLocation.removeLocationUpdates(callback)
        database.close()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.lifeinmist.app.START_TRACKING"
        const val ACTION_LANGUAGE = "com.lifeinmist.app.REFRESH_LANGUAGE"
        const val ACTION_STOP = "com.lifeinmist.app.STOP_TRACKING"
        const val ACTION_LOCATION_UPDATE = "com.lifeinmist.app.LOCATION_UPDATE"
        const val ACTION_GPS_STATUS = "com.lifeinmist.app.GPS_STATUS"
        const val EXTRA_FIX_NANOS = "fix_elapsed_nanos"
        const val ACTION_TRACKING_STOPPED = "com.lifeinmist.app.TRACKING_STOPPED"
        const val EXTRA_OPEN_DISCOVERY_ID = "open_discovery_id"
        const val EXTRA_DISCOVERED_NAMES = "discovered_names"
        const val EXTRA_DISCOVERED_IDS = "discovered_ids"
        const val EXTRA_WALK_ID = "walk_id"
        const val EXTRA_LAT = "lat"
        const val EXTRA_LON = "lon"
        const val EXTRA_ACCURACY = "accuracy"
        const val EXTRA_DISTANCE = "distance"
        private const val CHANNEL_ID = "walking"
        private const val DISCOVERY_CHANNEL_ID = "discoveries"
        private const val NOTIFICATION_ID = 1101
        private const val DISCOVERY_NOTIFICATION_BASE = 2100
    }
}
