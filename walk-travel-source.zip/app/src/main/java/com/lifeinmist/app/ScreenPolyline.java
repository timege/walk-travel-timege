package com.lifeinmist.app;

import java.util.Arrays;

/** Bounded Ramer-Douglas-Peucker on screen coordinates; never modifies GPS data. */
public final class ScreenPolyline {
    private ScreenPolyline() {}
    public static int[] simplify(float[] xy, int count, double tolerance) {
        if (count < 0 || count > xy.length / 2 || !Double.isFinite(tolerance) || tolerance < 0)
            throw new IllegalArgumentException();
        if (count == 0) return new int[0];
        boolean[] keep = new boolean[count];
        int[] stack = new int[256];
        double limit = tolerance * tolerance;
        // Bound worst-case work on zigzags. Shared endpoints prevent block seams.
        for (int first = 0; first < count; first += 127) {
            int last = Math.min(count - 1, first + 127);
            keep[first] = keep[last] = true;
            int size = 0;
            stack[size++] = first; stack[size++] = last;
            while (size > 0) {
                int b = stack[--size], a = stack[--size];
                double largest = limit;
                int selected = -1;
                for (int i = a + 1; i < b; i++) {
                    double error = distanceSquared(xy, i, a, b);
                    if (!Double.isFinite(error)) return all(count);
                    if (error > largest) { largest = error; selected = i; }
                }
                if (selected >= 0) {
                    keep[selected] = true;
                    stack[size++] = a; stack[size++] = selected;
                    stack[size++] = selected; stack[size++] = b;
                }
            }
            if (last == count - 1) break;
        }
        int[] result = new int[count];
        int length = 0;
        for (int i = 0; i < count; i++) if (keep[i]) result[length++] = i;
        return Arrays.copyOf(result, length);
    }

    private static int[] all(int count) {
        int[] result = new int[count];
        for (int i = 0; i < count; i++) result[i] = i;
        return result;
    }

    private static double distanceSquared(float[] xy, int i, int a, int b) {
        double ax = xy[2 * a], ay = xy[2 * a + 1];
        double dx = (double)xy[2 * b] - ax, dy = (double)xy[2 * b + 1] - ay;
        double px = xy[2 * i] - ax, py = xy[2 * i + 1] - ay;
        double length = dx * dx + dy * dy;
        double t = length == 0 ? 0 : Math.max(0, Math.min(1, (px * dx + py * dy) / length));
        double ex = px - t * dx, ey = py - t * dy;
        return ex * ex + ey * ey;
    }
}
