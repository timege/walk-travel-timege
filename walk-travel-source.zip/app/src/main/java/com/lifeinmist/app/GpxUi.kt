package com.lifeinmist.app

import android.util.AtomicFile
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import org.maplibre.android.geometry.LatLng

data class ImportedGpxRoute(val name: String, val segments: List<List<LatLng>>,
    val points: List<LatLng>, val distanceM: Double)

/** File pickers and disk I/O stay outside MainActivity and outside the location database. */
class GpxUi(private val activity: AppCompatActivity, private val showRoute: (ImportedGpxRoute) -> Unit) {
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs = activity.getSharedPreferences("gpx", 0)
    private val savedRoute = AtomicFile(File(activity.filesDir, "imported-route.gpx"))
    private var revision = 0
    private var closed = false

    private val exportPicker = activity.registerForActivityResult(ActivityResultContracts.CreateDocument("application/gpx+xml")) { uri ->
        val id = prefs.getLong("exportWalk", -1)
        if (uri != null && id > 0) executor.execute {
            val result = runCatching {
                MistDatabase(activity.applicationContext).use { db ->
                    activity.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use {
                        db.exportWalkGpx(id, it)
                    } ?: error("Could not open the destination file")
                }
            }
            onUi { toast(if (result.isSuccess) tr("GPX saved", "GPX сохранён") else tr("Could not export GPX. Try another location.", "Не удалось сохранить GPX. Выберите другое место сохранения.")) }
        }
    }
    private val importPicker = activity.registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) executor.execute {
            val result = runCatching {
                activity.contentResolver.openInputStream(uri)?.use { GpxCodec.read(it) }
                    ?: error(tr("Could not open the file", "Не удалось открыть файл"))
            }
            onUi {
                result.fold({ tracks ->
                    if (tracks.size == 1) confirm(tracks.first())
                    else AlertDialog.Builder(activity).setTitle(tr("Choose a GPX track", "Выберите трек GPX"))
                        .setItems(tracks.map { it.name }.toTypedArray()) { _, index -> confirm(tracks[index]) }
                        .setNegativeButton(tr("Cancel", "Отмена"), null).show()
                }, { toast(tr("Could not import GPX. Use a valid track or route, up to 20 MB and 200,000 points.", "Не удалось загрузить GPX. Выберите трек или маршрут: до 20 МБ и 200 000 точек.")) })
            }
        }
    }

    fun importRoute() { importPicker.launch(arrayOf("*/*")) }

    fun exportWalk() {
        executor.execute {
            val result = runCatching {
                MistDatabase(activity.applicationContext).use { it.walksForGpxExport() }
            }
            onUi {
                result.fold({ walks ->
                    if (walks.isEmpty()) { toast(tr("Record a walk before exporting GPX", "Сначала запишите прогулку")); return@fold }
                    val date = SimpleDateFormat("d MMM yyyy, HH:mm", AppLanguage.locale)
                    val labels = walks.map {
                        "${date.format(Date(it.startedAt))} · ${String.format(AppLanguage.locale, tr("%.2f km", "%.2f км"), it.distanceM / 1000)}" +
                            if (it.endedAt == null) tr(" · recording", " · идёт запись") else ""
                    }
                    AlertDialog.Builder(activity).setTitle(tr("Export a walk", "Экспорт прогулки"))
                        .setItems(labels.toTypedArray()) { _, index ->
                            val walk = walks[index]
                            prefs.edit().putLong("exportWalk", walk.id).apply()
                            val stamp = SimpleDateFormat("yyyy-MM-dd-HHmm", Locale.US).format(Date(walk.startedAt))
                            exportPicker.launch("walk-$stamp.gpx")
                        }.setNegativeButton(tr("Cancel", "Отмена"), null).show()
                }, { toast(tr("Could not load your walks", "Не удалось загрузить прогулки")) })
            }
        }
    }

    private fun confirm(track: GpxCodec.Track) {
        AlertDialog.Builder(activity).setTitle(track.name)
            .setMessage(tr("Show this route on your map? It will stay available after restarting. Imported routes do not reveal the map or unlock places.", "Показать маршрут на карте? Он сохранится после перезапуска. Импорт маршрута не открывает туман и не засчитывает посещение мест."))
            .setPositiveButton(tr("Use route", "Показать маршрут")) { _, _ ->
                val ticket = ++revision
                executor.execute {
                    val result = runCatching {
                        val stream = savedRoute.startWrite()
                        try {
                            val writer = stream.bufferedWriter(Charsets.UTF_8)
                            GpxCodec.write(writer, track)
                            writer.flush()
                            savedRoute.finishWrite(stream)
                        } catch (e: Exception) { savedRoute.failWrite(stream); throw e }
                        prepare(track)
                    }
                    onUi {
                        if (ticket == revision) result.fold({ showRoute(it) }, { toast(tr("Could not save the imported route", "Не удалось сохранить импортированный маршрут")) })
                    }
                }
            }.setNegativeButton(tr("Cancel", "Отмена"), null).show()
    }

    fun restoreRoute() {
        val ticket = revision
        executor.execute {
            val track = runCatching { savedRoute.openRead().use { prepare(GpxCodec.read(it).first()) } }.getOrNull()
            onUi { if (track != null && ticket == revision) showRoute(track) }
        }
    }
    fun clearRoute() { revision++; executor.execute { savedRoute.delete() } }
    private fun prepare(track: GpxCodec.Track): ImportedGpxRoute {
        val segments = track.segments.map { segment -> segment.map { LatLng(it.latitude, it.longitude) } }
        var distance = 0.0
        for (segment in segments) for (index in 1 until segment.size) {
            distance += segment[index - 1].distanceTo(segment[index])
        }
        return ImportedGpxRoute(track.name, segments, segments.flatten(), distance)
    }
    fun close() { closed = true; executor.shutdown() }
    private fun onUi(action: () -> Unit) = activity.runOnUiThread {
        if (!closed && !activity.isFinishing && !activity.isDestroyed) action()
    }
    private fun toast(message: String) = Toast.makeText(activity, message, Toast.LENGTH_LONG).show()
}
