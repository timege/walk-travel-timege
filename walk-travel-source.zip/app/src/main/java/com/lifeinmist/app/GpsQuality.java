package com.lifeinmist.app;

/** Accuracy and freshness only, not a promise that a place can be unlocked. */
public final class GpsQuality {
    public static String state(boolean permission, boolean enabled, float accuracy, long fixNanos, long nowNanos) {
        if (!permission) return "permission";
        if (!enabled) return "off";
        if (fixNanos <= 0 || fixNanos > nowNanos || nowNanos - fixNanos > 20_000_000_000L) return "waiting";
        if (!Float.isFinite(accuracy) || accuracy <= 0) return "waiting";
        if (accuracy <= 15) return "good";
        if (accuracy <= 35) return "fair";
        return "weak";
    }
}
