package com.lifeinmist.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import kotlin.math.hypot

class DiscoveryOverlay(context: Context) : View(context) {
    var map: MapLibreMap? = null
    var onPlaceClick: (DiscoveryPlace) -> Unit = {}
    private val store = DiscoveryStore.get(context)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hits = ArrayList<Triple<DiscoveryPlace, Float, Float>>()
    private val density = resources.displayMetrics.density

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        hits.clear()
        val projection = map?.projection ?: return
        for (place in store.places()) {
            val p = projection.toScreenLocation(LatLng(place.lat, place.lon))
            if (p.x < -24 * density || p.y < -24 * density || p.x > width + 24 * density || p.y > height + 24 * density) continue
            // Avoid overdraw and unselectable stacks at overview zoom levels.
            if (hits.any { hypot(it.second - p.x, it.third - p.y) < 44 * density }) continue
            val opened = store.openedAt(place.id) > 0
            paint.color = Color.WHITE
            canvas.drawCircle(p.x, p.y, 19 * density, paint)
            paint.color = if (opened) Color.rgb(47, 119, 65) else Color.rgb(76, 104, 127)
            canvas.drawCircle(p.x, p.y, 16 * density, paint)
            paint.color = Color.WHITE
            paint.textSize = 21 * density
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText(if (opened) "✓" else "?", p.x, p.y - (paint.ascent() + paint.descent()) / 2, paint)
            hits.add(Triple(place, p.x, p.y))
            if (hits.size >= 120) break
        }
    }

    // MapLibre recognizes taps, so this overlay never steals pan/pinch gestures.
    fun handleMapClick(coordinate: LatLng): Boolean {
        val point = map?.projection?.toScreenLocation(coordinate) ?: return false
        val place = hits.lastOrNull {
            hypot(it.second - point.x, it.third - point.y) <= 22 * density
        }?.first ?: return false
        onPlaceClick(place)
        return true
    }
}
