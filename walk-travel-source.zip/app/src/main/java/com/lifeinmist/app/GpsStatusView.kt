package com.lifeinmist.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.location.LocationManager
import android.os.SystemClock
import android.view.Gravity
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatTextView
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

class GpsStatusView(context: Context) : AppCompatTextView(context) {
    private var accuracy = 0f
    private var fixNanos = 0L
    private var active = false
    private var state = "waiting"
    private val tick = object : Runnable {
        override fun run() { refresh(); if (active) postDelayed(this, 5_000) }
    }
    init {
        textSize = 10f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        gravity = Gravity.CENTER
        minHeight = dp(48)
        setPadding(0, 0, 0, 0)
        background = InsetDrawable(GradientDrawable().apply {
            setColor(Color.argb(235, 246, 250, 241)); cornerRadius = dp(14).toFloat()
        }, dp(2), dp(8), dp(2), dp(8))
        setOnClickListener {
            val details = when (state) {
                "permission" -> tr("Allow location access to show GPS quality.", "Разрешите доступ к местоположению для отображения качества GPS.")
                "off" -> tr("Location services are off. Turn them on in your phone settings.", "Геолокация выключена. Включите её в настройках телефона.")
                "waiting" -> tr("No recent GPS fix. Start a walk for continuous updates, or tap My location to refresh.", "Нет свежих координат. Начните прогулку для постоянного обновления или нажмите кнопку определения местоположения.")
                else -> tr("Estimated accuracy: ±${accuracy.roundToInt()} m.\nLast fix: ${((SystemClock.elapsedRealtimeNanos() - fixNanos) / 1_000_000_000).coerceAtLeast(0)} seconds ago.", "Примерная точность: ±${accuracy.roundToInt()} м.\nПоследние координаты: ${((SystemClock.elapsedRealtimeNanos() - fixNanos) / 1_000_000_000).coerceAtLeast(0)} сек. назад.")
            }
            AlertDialog.Builder(context).setTitle(tr("GPS quality", "Качество GPS"))
                .setMessage(tr("$details\n\nTo unlock places, record a walk and move close enough with a fresh, precise GPS fix. Accuracy alone does not guarantee an unlock.", "$details\n\nДля открытия мест записывайте прогулку и подойдите достаточно близко. Нужны свежие и точные координаты; одной точности недостаточно."))
                .setPositiveButton(tr("Got it", "Понятно"), null).show()
        }
        refresh()
    }
    fun update(accuracyM: Float, elapsedNanos: Long) {
        if (elapsedNanos < fixNanos) return
        accuracy = accuracyM; fixNanos = elapsedNanos; refresh()
    }
    fun resumeUpdates() { active = true; removeCallbacks(tick); tick.run() }
    fun pauseUpdates() { active = false; removeCallbacks(tick) }
    override fun onDetachedFromWindow() { pauseUpdates(); super.onDetachedFromWindow() }
    private fun refresh() {
        val permission = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val enabled = runCatching { manager.isProviderEnabled(LocationManager.GPS_PROVIDER) || manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) }.getOrDefault(false)
        state = GpsQuality.state(permission, enabled, accuracy, fixNanos, SystemClock.elapsedRealtimeNanos())
        val qualityLabel = when (state) {
            "good", "fair" -> tr("GPS ±${accuracy.roundToInt()} m", "GPS ±${accuracy.roundToInt()} м")
            "weak" -> tr("GPS · weak", "GPS · слабый сигнал")
            "off" -> tr("GPS · off", "GPS · выключен")
            "permission" -> tr("GPS · access", "GPS · нет доступа")
            else -> tr("GPS · waiting", "GPS · ожидание")
        }
        setTextColor(when (state) {
            "good" -> Color.rgb(20, 94, 35)
            "fair", "weak" -> Color.rgb(131, 83, 0)
            else -> Color.rgb(80, 89, 82)
        })
        text = "● GPS"
        contentDescription = tr("$qualityLabel. Tap for GPS quality details.", "$qualityLabel. Нажмите, чтобы узнать качество GPS.")
    }
    private fun dp(n: Int) = (n * resources.displayMetrics.density).roundToInt()
}
