package com.lifeinmist.app

import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap

/** Bounds are built only when the saved track changes. Adjacent chunks share an endpoint. */
internal class TrackChunk(val points: List<TrackPoint>) {
    private val minLat = points.minOf { it.latitude }
    private val maxLat = points.maxOf { it.latitude }
    private val minLon = points.minOf { it.longitude }
    private val maxLon = points.maxOf { it.longitude }
    private val corners = arrayOf(LatLng(minLat, minLon), LatLng(minLat, maxLon),
        LatLng(maxLat, minLon), LatLng(maxLat, maxLon))

    fun mayIntersect(map: MapLibreMap, left: Float, top: Float, right: Float, bottom: Float): Boolean {
        // Be conservative around world wrapping. Never reject an ambiguous chunk.
        val target = map.cameraPosition.target ?: return true
        if (maxLon - minLon > 180 || kotlin.math.abs((minLon + maxLon) / 2 - target.longitude) > 150) return true
        var x0 = Double.POSITIVE_INFINITY
        var y0 = Double.POSITIVE_INFINITY
        var x1 = Double.NEGATIVE_INFINITY
        var y1 = Double.NEGATIVE_INFINITY
        for (corner in corners) {
            val p = map.projection.toScreenLocation(corner)
            if (!p.x.isFinite() || !p.y.isFinite()) return true
            x0 = minOf(x0, p.x.toDouble()); y0 = minOf(y0, p.y.toDouble())
            x1 = maxOf(x1, p.x.toDouble()); y1 = maxOf(y1, p.y.toDouble())
        }
        return TrackVisibility.intersects(x0, y0, x1, y1,
            left.toDouble(), top.toDouble(), right.toDouble(), bottom.toDouble())
    }
}
