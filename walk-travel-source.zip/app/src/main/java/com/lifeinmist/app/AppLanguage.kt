package com.lifeinmist.app

import android.content.Context
import java.util.Locale

/** App-owned UI language. Place content and user-created GPX names are left intact. */
object AppLanguage {
    @Volatile var isRussian = false
        private set
    val locale: Locale get() = if (isRussian) Locale.forLanguageTag("ru") else Locale.ENGLISH
    fun initialize(context: Context) {
        isRussian = context.getSharedPreferences("language", 0).getString("code", "en") == "ru"
    }
    fun select(context: Context, russian: Boolean) {
        context.getSharedPreferences("language", 0).edit().putString("code", if (russian) "ru" else "en").apply()
        isRussian = russian
    }
}

internal fun tr(english: String, russian: String): String = if (AppLanguage.isRussian) russian else english
