package com.lifeinmist.app;

public final class TrackVisibility {
    private TrackVisibility() {}
    public static boolean intersects(double x0, double y0, double x1, double y1,
                                     double left, double top, double right, double bottom) {
        return x1 >= left && x0 <= right && y1 >= top && y0 <= bottom;
    }
}
