package com.lifeinmist.app

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.text.InputFilter
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.offline.OfflineManager
import org.maplibre.android.offline.OfflineRegion
import org.maplibre.android.offline.OfflineRegionError
import org.maplibre.android.offline.OfflineRegionStatus
import org.maplibre.android.offline.OfflineTilePyramidRegionDefinition
import java.text.SimpleDateFormat
import java.util.Date
import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.tan

/** Explicit region downloads in MapLibre's persistent offline database, separate from walk progress. */
class OfflineMapsUi(
    private val activity: AppCompatActivity,
    private val map: () -> MapLibreMap?,
    private val styleUrl: String
) {
    private class Entry(val region: OfflineRegion, val name: String) {
        var status: OfflineRegionStatus? = null
        var active = false
        var deleting = false
        var error = false
        var statusView: TextView? = null
        var progressView: ProgressBar? = null
        var toggleView: Button? = null
    }

    private val manager = OfflineManager.getInstance(activity.applicationContext)
    private val entries = linkedMapOf<Long, Entry>()
    private val handler = Handler(Looper.getMainLooper())
    private var dialog: AlertDialog? = null
    private var content: LinearLayout? = null
    private var loaded = false
    private var loading = false
    private var creating = false
    private var closed = false
    private var appForeground = false
    private var updateScheduled = false
    private val updateRows = Runnable {
        updateScheduled = false
        if (!closed) entries.values.forEach(::updateRow)
    }

    fun onStart() { appForeground = true; scheduleUpdate() }

    fun onStop() {
        appForeground = false
        entries.values.filter { it.active }.forEach(::pause)
    }

    fun close() {
        onStop()
        closed = true
        handler.removeCallbacks(updateRows)
        entries.values.forEach { it.region.setObserver(null) }
        dialog?.dismiss()
        dialog = null
        content = null
        entries.values.forEach { it.statusView = null; it.progressView = null; it.toggleView = null }
    }

    fun show() {
        if (closed || activity.isFinishing) return
        dialog?.dismiss()
        val column = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(16))
        }
        content = column
        val shown = AlertDialog.Builder(activity)
            .setTitle(tr("Offline maps", "Офлайн-карты"))
            .setView(ScrollView(activity).apply { addView(column) })
            .setNegativeButton(tr("Close", "Закрыть"), null).create()
        dialog = shown
        shown.setOnDismissListener {
            if (dialog === shown) {
                dialog = null; content = null
                entries.values.forEach { it.statusView = null; it.progressView = null; it.toggleView = null }
            }
        }
        renderList()
        shown.show()
        shown.window?.setBackgroundDrawable(cardBackground())
        // Re-enumerate on opening as a pending native create may have finished
        // after the previous Activity was destroyed during rotation.
        loadRegions()
    }

    private fun loadRegions() {
        if (loading || closed) return
        loading = true
        manager.listOfflineRegions(object : OfflineManager.ListOfflineRegionsCallback {
            override fun onList(offlineRegions: Array<OfflineRegion>?) {
                if (closed) return
                loading = false; loaded = true
                for (region in offlineRegions.orEmpty()) {
                    // Own only regions created by this screen.
                    val metadata = runCatching { JSONObject(String(region.metadata, Charsets.UTF_8)) }.getOrNull() ?: continue
                    if (metadata.optString("owner") != OWNER || entries.containsKey(region.id)) continue
                    addRegion(region, metadata.optString("name", tr("Saved area", "Сохранённая область")))
                }
                renderList()
            }
            override fun onError(error: String) {
                if (closed) return
                loading = false
                renderList()
                toast(tr("Could not load saved maps. Try again.", "Не удалось открыть список карт. Попробуйте ещё раз."))
            }
        })
    }

    private fun addRegion(region: OfflineRegion, name: String): Entry {
        entries[region.id]?.let { return it }
        val entry = Entry(region, name)
        entries[region.id] = entry
        observe(entry)
        readStatus(entry)
        return entry
    }

    private fun isCurrent(entry: Entry): Boolean = !closed && !entry.deleting && entries[entry.region.id] === entry

    private fun observe(entry: Entry) {
        entry.region.setObserver(object : OfflineRegion.OfflineRegionObserver {
            override fun onStatusChanged(status: OfflineRegionStatus) {
                if (!isCurrent(entry)) return
                acceptStatus(entry, status)
            }
            override fun onError(error: OfflineRegionError) {
                if (!isCurrent(entry)) return
                entry.error = true
                pause(entry)
                scheduleUpdate()
            }
            override fun mapboxTileCountLimitExceeded(limit: Long) {
                if (!isCurrent(entry)) return
                entry.error = true
                pause(entry)
                toast(tr("This area is too large. Download a smaller area.", "Область слишком большая. Выберите меньший участок."))
            }
        })
    }

    private fun readStatus(entry: Entry) {
        entry.region.getStatus(object : OfflineRegion.OfflineRegionStatusCallback {
            override fun onStatus(status: OfflineRegionStatus?) {
                if (isCurrent(entry) && status != null) acceptStatus(entry, status)
            }
            override fun onError(error: String?) {
                if (isCurrent(entry)) { entry.error = true; scheduleUpdate() }
            }
        })
    }

    private fun complete(status: OfflineRegionStatus?): Boolean = status != null &&
        status.isRequiredResourceCountPrecise && status.requiredResourceCount > 0 && status.isComplete

    private fun acceptStatus(entry: Entry, status: OfflineRegionStatus) {
        entry.status = status
        if (complete(status)) {
            val wasActive = entry.active
            entry.error = false
            pause(entry)
            if (wasActive && appForeground) toast(tr("Map saved: ${entry.name}", "Карта сохранена: ${entry.name}"))
        } else if (entry.active && activity.filesDir.usableSpace < FREE_SPACE_RESERVE) {
            entry.error = true
            pause(entry)
            if (appForeground) toast(tr("Not enough free space. Download paused.", "Мало свободной памяти. Загрузка приостановлена."))
        }
        scheduleUpdate()
    }

    private fun pause(entry: Entry) {
        if (entry.active) {
            entry.active = false
            entry.region.setDownloadState(OfflineRegion.STATE_INACTIVE)
        }
        scheduleUpdate()
    }

    private fun resume(entry: Entry) {
        if (!appForeground || !isCurrent(entry) || complete(entry.status)) return
        if (StatFs(activity.filesDir.absolutePath).availableBytes < FREE_SPACE_RESERVE) {
            toast(tr("Free some storage before downloading.", "Освободите память перед загрузкой.")); return
        }
        entries.values.filter { it !== entry && it.active }.forEach(::pause)
        entry.error = false
        entry.active = true
        entry.region.setDownloadState(OfflineRegion.STATE_ACTIVE)
        scheduleUpdate()
    }

    private fun renderList() {
        val parent = content ?: return
        parent.removeAllViews()
        label(parent, tr(
            "Position the map over the area you need, then download it here. Downloads pause when you leave the app; you can continue later. Saved maps work without internet.",
            "Расположите нужную область на экране карты и загрузите её здесь. При выходе из приложения загрузка встаёт на паузу — её можно продолжить позже. Скачанные карты работают без интернета."))
        label(parent, tr(
            "Place search, new walking routes, articles and photos still need internet. GPS, recorded walks, saved places and imported GPX remain available offline.",
            "Поиск мест, построение новых маршрутов, статьи и фото требуют интернета. GPS, запись прогулок, сохранённые точки и импортированный GPX доступны офлайн."), 12f)
        button(parent, tr("Download visible area", "Скачать область на экране")) { confirmDownload() }.isEnabled = loaded && !creating
        if (!loaded) {
            label(parent, if (loading) tr("Loading saved maps…", "Загружаем список карт…") else tr("Saved maps are not loaded yet.", "Список карт пока не загружен."))
            button(parent, tr("Refresh list", "Обновить список")) { loadRegions() }
        } else if (entries.isEmpty()) {
            label(parent, tr("No offline areas yet.", "Скачанных областей пока нет."))
        }
        for (entry in entries.values) {
            val row = LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(12))
                background = cardBackground()
            }
            parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
            label(row, entry.name, 17f).typeface = AppTypography.emphasis
            entry.statusView = label(row, "", 13f)
            entry.progressView = ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                row.addView(this, LinearLayout.LayoutParams(-1, dp(6)).apply { bottomMargin = dp(6) })
            }
            entry.toggleView = button(row, "") { if (entry.active) pause(entry) else resume(entry) }
            button(row, tr("Show on map", "Показать на карте")) {
                val bounds = entry.region.definition.bounds ?: return@button
                dialog?.dismiss()
                map()?.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, dp(30)))
            }
            button(row, tr("Delete downloaded map", "Удалить скачанную карту")) { confirmDelete(entry) }
            updateRow(entry)
        }
    }

    private fun scheduleUpdate() {
        if (closed || updateScheduled) return
        updateScheduled = true
        handler.postDelayed(updateRows, 300)
    }

    private fun updateRow(entry: Entry) {
        val status = entry.status
        val done = complete(status)
        val percent = if (status != null && status.isRequiredResourceCountPrecise && status.requiredResourceCount > 0)
            (100.0 * status.completedResourceCount / status.requiredResourceCount).toInt().coerceIn(0, if (done) 100 else 99) else null
        val size = String.format(AppLanguage.locale, "%.1f", (status?.completedResourceSize ?: 0L) / 1_048_576.0)
        val state = when {
            entry.deleting -> tr("Deleting…", "Удаляем…")
            done -> tr("Ready offline", "Доступна офлайн")
            entry.error -> tr("Paused — check internet or free space", "Пауза — проверьте интернет и свободную память")
            entry.active -> tr("Downloading", "Загрузка")
            else -> tr("Paused", "На паузе")
        }
        entry.statusView?.text = "$state · $size ${tr("MB", "МБ")}" + (percent?.let { " · $it%" } ?: "")
        entry.progressView?.apply {
            isIndeterminate = entry.active && percent == null
            if (percent != null) progress = percent
            visibility = if (done) View.GONE else View.VISIBLE
        }
        entry.toggleView?.apply {
            text = if (entry.active) tr("Pause", "Пауза") else tr("Continue download", "Продолжить загрузку")
            visibility = if (done) View.GONE else View.VISIBLE
            isEnabled = !entry.deleting && appForeground
        }
    }

    private fun confirmDownload() {
        if (closed || creating || !appForeground) return
        val currentMap = map() ?: return
        if (currentMap.style?.isFullyLoaded != true) {
            toast(tr("Wait for the map to load first.", "Дождитесь загрузки карты.")); return
        }
        val bounds = currentMap.projection.visibleRegion.latLngBounds
        val tiles = estimateTiles(bounds)
        if (tiles == null || tiles > MAX_TILE_ESTIMATE) {
            toast(tr("Zoom in and choose a smaller area to download.", "Приблизьте карту и выберите меньшую область для загрузки.")); return
        }
        dialog?.dismiss()
        val form = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(6), dp(22), dp(12))
        }
        val stamp = SimpleDateFormat("dd.MM HH:mm", AppLanguage.locale).format(Date())
        val name = EditText(activity).apply {
            setSingleLine(true)
            filters = arrayOf(InputFilter.LengthFilter(60))
            setText(tr("Map $stamp", "Карта $stamp"))
            selectAll()
            form.addView(this, LinearLayout.LayoutParams(-1, -2))
        }
        label(form, tr(
            "Save the area currently visible on the map, including street detail. The download uses internet; its actual size will appear during downloading.",
            "Сохранить область, которая сейчас видна на карте, с детализацией до улиц. Загрузка использует интернет; фактический размер появится в процессе."))
        val confirm = AlertDialog.Builder(activity).setTitle(tr("Save map", "Скачать карту"))
            .setView(form).setNegativeButton(tr("Cancel", "Отмена"), null)
            .setPositiveButton(tr("Download", "Скачать"), null).create()
        confirm.setOnShowListener {
            confirm.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val title = name.text.toString().trim()
                if (title.isEmpty()) { name.error = tr("Enter a name", "Введите название"); return@setOnClickListener }
                confirm.dismiss()
                createRegion(title, bounds)
            }
        }
        confirm.show()
    }

    private fun createRegion(name: String, bounds: LatLngBounds) {
        if (closed || creating || !appForeground) return
        if (activity.filesDir.usableSpace < FREE_SPACE_RESERVE) {
            toast(tr("Free some storage before downloading.", "Освободите память перед загрузкой.")); return
        }
        creating = true
        val definition = OfflineTilePyramidRegionDefinition(styleUrl, bounds, 0.0, MAX_ZOOM.toDouble(),
            activity.resources.displayMetrics.density, false)
        val metadata = JSONObject().put("owner", OWNER).put("name", name).put("created_at", System.currentTimeMillis())
            .toString().toByteArray(Charsets.UTF_8)
        manager.createOfflineRegion(definition, metadata, object : OfflineManager.CreateOfflineRegionCallback {
            override fun onCreate(offlineRegion: OfflineRegion) {
                creating = false
                if (closed) { offlineRegion.setDownloadState(OfflineRegion.STATE_INACTIVE); return }
                val entry = addRegion(offlineRegion, name)
                if (appForeground) { resume(entry); show() }
            }
            override fun onError(error: String) {
                creating = false
                if (!closed && appForeground) { toast(tr("Could not create the download. Try again.", "Не удалось начать загрузку. Попробуйте ещё раз.")); show() }
            }
        })
    }

    private fun confirmDelete(entry: Entry) {
        if (!isCurrent(entry)) return
        AlertDialog.Builder(activity).setTitle(tr("Delete ${entry.name}?", "Удалить «${entry.name}»?"))
            .setMessage(tr("Only this downloaded map will be removed. Your walks, places and explored progress stay saved.",
                "Удалится только скачанная карта. Прогулки, интересные места и прогресс останутся."))
            .setNegativeButton(tr("Cancel", "Отмена"), null)
            .setPositiveButton(tr("Delete", "Удалить")) { _, _ ->
                if (!isCurrent(entry)) return@setPositiveButton
                pause(entry)
                entry.deleting = true
                entry.region.setObserver(null)
                updateRow(entry)
                entry.region.delete(object : OfflineRegion.OfflineRegionDeleteCallback {
                    override fun onDelete() {
                        if (closed) return
                        entries.remove(entry.region.id)
                        renderList()
                    }
                    override fun onError(error: String) {
                        if (closed) return
                        entry.deleting = false
                        observe(entry)
                        renderList()
                        toast(tr("Could not delete this map. Try again.", "Не удалось удалить карту. Попробуйте ещё раз."))
                    }
                })
            }.show()
    }

    /** Conservative single-source tile estimate; avoids accidentally downloading a continent. */
    private fun estimateTiles(bounds: LatLngBounds): Long? {
        val west = bounds.longitudeWest; val east = bounds.longitudeEast
        val north = bounds.latitudeNorth; val south = bounds.latitudeSouth
        if (west < -180 || east > 180 || west >= east || east - west > 180 || south >= north || south < -85 || north > 85) return null
        var total = 0L
        for (zoom in 0..MAX_ZOOM) {
            val n = 2.0.pow(zoom)
            fun x(lon: Double) = floor((lon + 180) / 360 * n).toLong().coerceIn(0, n.toLong() - 1)
            fun y(lat: Double) = floor((1 - ln(tan(PI / 4 + Math.toRadians(lat) / 2)) / PI) / 2 * n)
                .toLong().coerceIn(0, n.toLong() - 1)
            total += (x(east) - x(west) + 1) * (y(south) - y(north) + 1)
            if (total > MAX_TILE_ESTIMATE) return total
        }
        return total
    }

    private fun label(parent: LinearLayout, value: String, size: Float = 14f): TextView = TextView(activity).apply {
        text = value; textSize = size; typeface = AppTypography.body
        setTextColor(Color.rgb(40, 74, 53))
        parent.addView(this, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }

    private fun button(parent: LinearLayout, value: String, action: () -> Unit): Button = Button(activity).apply {
        text = value; isAllCaps = false; typeface = AppTypography.emphasis
        setTextColor(Color.rgb(25, 87, 42))
        setOnClickListener { if (!closed) action() }
        parent.addView(this, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun cardBackground() = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(Color.rgb(255, 255, 246), Color.rgb(230, 238, 218))).apply {
        cornerRadius = dp(16).toFloat(); setStroke(dp(1), Color.rgb(184, 202, 167))
    }
    private fun toast(message: String) { if (!closed && !activity.isFinishing) Toast.makeText(activity, message, Toast.LENGTH_LONG).show() }
    private fun dp(value: Int) = (value * activity.resources.displayMetrics.density).toInt()

    companion object {
        private const val OWNER = "wtt-offline-v1"
        private const val MAX_ZOOM = 16
        private const val MAX_TILE_ESTIMATE = 15_000L
        private const val FREE_SPACE_RESERVE = 150L * 1024 * 1024
    }
}
