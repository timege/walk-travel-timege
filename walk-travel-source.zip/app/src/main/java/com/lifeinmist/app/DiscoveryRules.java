package com.lifeinmist.app;

/** Platform-independent acceptance rule; distance and accuracy are in metres. */
public final class DiscoveryRules {
    private DiscoveryRules() {}
    public static boolean canDiscover(double distance, double radius, double accuracy,
                                      double ageSeconds, double speed) {
        return Double.isFinite(distance) && distance >= 0
            && Double.isFinite(radius) && radius >= 25 && radius <= 500
            && Double.isFinite(accuracy) && accuracy > 0 && accuracy <= 35
            && Double.isFinite(ageSeconds) && ageSeconds >= 0 && ageSeconds <= 20
            && Double.isFinite(speed) && speed >= 0 && speed <= 3.5
            && distance + accuracy <= radius;
    }
}
