# 0.9.0 — English, GPS quality and GPX

## Included

- English app-owned controls, accessibility labels, errors and recording notification.
- Native Android sans-serif typography (Roboto on stock Android), medium-weight
  titles and controls. No network request or extra font asset is needed.
- About: app version, “Walk. Discover. Make the map yours.”, © 2026 Timege,
  map/provider credits and normalthai.ru. Existing map attribution is retained.
- GPS badge above My location, using reported accuracy and monotonic fix age.
  Good: <=15 m; fair: <=35 m; weak: >35 m; waiting: no fix or >20 s old.
  The badge is informational: it does not relax DiscoveryRules. Polling stops
  while the activity is paused. GPS tracking updates include rejected poor fixes
  for this badge only. Outside recording, My location refreshes the last known fix;
  the badge does not start a new background tracking service.
- Export a chosen recorded walk through the Android file picker as GPX 1.1.
  Active walks may be exported as a snapshot of points read at export time.
- Import GPX tracks/routes, choose a track if several are present, and confirm it
  as a reference route. Segment gaps are retained, including when map style changes.
  Saving/parsing/route preparation is done on a separate worker. The imported route
  never enters walks, track_points, permanent_explored_points or discoveries.
- The reference route persists in an atomic private file across app restarts.
  Its original timestamps/elevations are preserved in that private GPX. The map
  displays its path and total length, without online route recalculation.
- Exports preserve recorded positions and timestamps; no synthetic altitude.
  Waypoint-only GPX files are not imported as routes. Files must be <=20 MB and
  contain <=200,000 track/route points. DTDs/external entities are rejected.

## Validation

- GpxCodecTest: 26 JVM checks, including round trip, UTC conversion, Unicode names,
  separate segments, routes, namespaces, 10k points, size-by-point limit, invalid
  coordinates/timestamps, malformed XML and DTD/external-entity rejection.
- GpsQualityTest: 12 JVM checks for accuracy thresholds, freshness, future time,
  permission, disabled location and invalid accuracy.
- Android SAX parser feature/property compatibility was checked against AOSP
  ExpatReader source. These JVM tests do not substitute for an Android device run.
- GPX format reference: https://www.topografix.com/GPX/1/1/
- Full Android build and on-device UI/file-picker/third-party import validation
  remain to be run. Existing build-tool and dependency versions are unchanged.

## Device check after the GitHub build

1. Start a walk outdoors. Tap the GPS badge; compare its reported precision and age.
   Turn location off and back on, then background and resume the app.
2. Finish a short walk. Map menu → Export GPX → select that walk → save the file.
3. Import that GPX, confirm Use route, restart the app, and switch map styles.
   The reference route should remain visible; importing must not reveal new areas.
4. Test a GPX containing two disconnected segments; no line should bridge the gap.
5. Open the exported file in your preferred GPX app. No direct account integration
   with Strava, AllTrails or Organic Maps is included or claimed as tested.

## Agreed future stages (not included)

- Walk summary and discovery notification with a View action.
- WordPress places plugin; offline photo caching and quiet nearby reminders.
- Widgets, personal places, exploration suggestions, visit-density mode and reports.
- Offline regional maps and cloud backup with explicit provider/account setup.
- Larger MainActivity refactor, complete Gradle wrapper and device FPS/memory profiling.
- Define an honest geographic measure before showing “area explored” percentages.

Cloud rendering, strict discovery rules and existing progress data are unchanged.
