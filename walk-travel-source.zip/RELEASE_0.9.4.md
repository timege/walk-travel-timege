# Walk Travel Timege 0.9.4 (43)

Combines the 0.9.3 home-screen widget with the latest clear-all places action.
- Today’s distance and discoveries in the last seven days on the widget.
- Start/finish a walk from the widget.
- Remove all imported places and discovery history with confirmation.
- Walk history, explored map data and GPX routes are preserved.
- Uses the existing persistent Android signing key for in-place updates.
