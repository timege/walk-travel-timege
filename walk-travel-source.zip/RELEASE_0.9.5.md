# Walk Travel Timege 0.9.5 (44)

- Place names are visible before discovery in the list, detail card, and navigation target.
- Previously imported Samui names are corrected from the saved article-title export by article URL. Place IDs, coordinates, and discovery history are preserved; no places are added.
- GPS position marker is sky blue with a glossy highlight, white rim, blue halo, and a soft shadow. The sprite remains cached.
- Map styles and fog reveal rules are unchanged. Water visibility and 50 m previews remain proposals.
