import com.lifeinmist.app.GpxCodec;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.*;

public class GpxCodecTest {
    static int checks;
    static void check(boolean value, String message) {
        checks++; if (!value) throw new AssertionError(message);
    }
    static List<GpxCodec.Track> read(String xml) throws Exception {
        return GpxCodec.read(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
    }
    static void reject(String xml) throws Exception {
        try { read(xml); } catch (Exception expected) { checks++; return; }
        throw new AssertionError("Accepted invalid GPX: " + xml.substring(0, Math.min(80, xml.length())));
    }
    public static void main(String[] args) throws Exception {
        String xml = "<gpx xmlns='http://www.topografix.com/GPX/1/1' version='1.1' creator='test'>"
            + "<trk><name>A &amp; B — прогулка</name><trkseg><trkpt lat='59.86' lon='30.32'>"
            + "<ele>12.5</ele><time>2026-09-19T10:00:00+03:00</time></trkpt>"
            + "<trkpt lat='59.87' lon='30.33'/></trkseg><trkseg><trkpt lat='60' lon='31'/></trkseg></trk>"
            + "<rte><name>Route 2</name><rtept lat='0' lon='0'/><rtept lat='-1' lon='-180'/></rte></gpx>";
        List<GpxCodec.Track> tracks = read(xml);
        check(tracks.size() == 2, "Multiple tracks and routes");
        GpxCodec.Track t = tracks.get(0);
        check(t.name.equals("A & B — прогулка"), "Unicode and XML entities");
        check(t.segments.size() == 2, "Keep segment breaks");
        check(t.segments.get(0).size() == 2 && t.segments.get(1).size() == 1, "No bridge across gaps");
        check(t.segments.get(0).get(0).time == Instant.parse("2026-09-19T07:00:00Z").toEpochMilli(), "Timestamp timezone");
        check(t.segments.get(0).get(0).elevation == 12.5, "Elevation");
        check(t.segments.get(0).get(1).time == null, "Do not invent time");
        check(tracks.get(1).segments.get(0).get(0).latitude == 0, "Equator accepted");
        StringWriter out = new StringWriter(); GpxCodec.write(out, t);
        GpxCodec.Track again = read(out.toString()).get(0);
        check(again.name.equals(t.name) && again.segments.size() == 2, "Round trip");
        check(again.segments.get(0).get(0).longitude == 30.32, "Coordinates unchanged");
        check(again.segments.get(0).get(0).time.equals(t.segments.get(0).get(0).time), "Time preserved");
        check(read("<gpx><rte><rtept lat='90' lon='180'/></rte></gpx>").size() == 1, "No namespace supported");
        check(read("<g:gpx xmlns:g='http://www.topografix.com/GPX/1/0'><g:rte><g:rtept lat='1' lon='2'/></g:rte></g:gpx>").size() == 1, "GPX 1.0 prefix");
        reject("<gpx><trk><trkseg><trkpt lat='NaN' lon='0'/></trkseg></trk></gpx>");
        reject("<gpx><rte><rtept lat='91' lon='0'/></rte></gpx>");
        reject("<gpx><rte><rtept lon='0'/></rte></gpx>");
        reject("<gpx><rte><rtept lat='1' lon='2'><time>yesterday</time></rtept></rte></gpx>");
        reject("<gpx><wpt lat='1' lon='2'/></gpx>");
        reject("<gpx><trk>");
        reject("<notgpx><rte><rtept lat='1' lon='2'/></rte></notgpx>");
        reject("<!DOCTYPE gpx [<!ENTITY bomb 'boom'>]><gpx><name>&bomb;</name></gpx>");
        reject("<!DOCTYPE gpx SYSTEM 'file:///etc/passwd'><gpx/>");
        reject("<gpx xmlns='https://example.com/not-gpx'><rte><rtept lat='1' lon='2'/></rte></gpx>");
        reject("<gpx><extensions><trk><trkseg><trkpt lat='1' lon='2'/></trkseg></trk></extensions></gpx>");
        StringBuilder large = new StringBuilder("<gpx><trk><trkseg>");
        for (int i = 0; i < 10_000; i++) large.append("<trkpt lat='59.86' lon='30.32'/>");
        large.append("</trkseg></trk></gpx>");
        check(read(large.toString()).get(0).segments.get(0).size() == 10_000, "10k points");
        StringBuilder tooMany = new StringBuilder("<gpx><rte>");
        for (int i = 0; i <= GpxCodec.MAX_POINTS; i++) tooMany.append("<rtept lat='1' lon='2'/>");
        reject(tooMany.append("</rte></gpx>").toString());
        System.out.println("GPX: " + checks + " checks passed");
    }
}
