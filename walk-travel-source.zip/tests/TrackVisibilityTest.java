import com.lifeinmist.app.TrackVisibility;

public class TrackVisibilityTest {
    static void check(boolean condition) {
        if (!condition) throw new AssertionError();
    }
    public static void main(String[] args) {
        check(TrackVisibility.intersects(-100, 40, 200, 60, 0, 0, 100, 100)); // crossing
        check(TrackVisibility.intersects(100, 100, 150, 150, 0, 0, 100, 100)); // edge
        check(!TrackVisibility.intersects(101, 0, 200, 100, 0, 0, 100, 100));
        check(!TrackVisibility.intersects(0, -200, 100, -1, 0, 0, 100, 100));
        check(TrackVisibility.intersects(50, 50, 50, 50, 0, 0, 100, 100)); // singleton
        // Deterministic synthetic workload: 10 nearby blocks and 9,990 distant ones.
        long projected = 0;
        for (int i = 0; i < 10000; i++) {
            double x = i < 10 ? 20 : 10000 + i;
            projected += 4;
            if (TrackVisibility.intersects(x, 20, x + 10, 30, 0, 0, 100, 100)) projected += 128;
        }
        check(projected == 41280);
        System.out.println("Visibility checks passed. Synthetic projection count: 1,280,000 -> " + projected);
    }
}
