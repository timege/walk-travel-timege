import com.lifeinmist.app.DiscoveryRules;

public class DiscoveryRulesTest {
    private static void expect(boolean expected, double distance, double radius,
                               double accuracy, double age, double speed) {
        if (DiscoveryRules.canDiscover(distance, radius, accuracy, age, speed) != expected)
            throw new AssertionError("Unexpected discovery decision: " + distance + ", " + accuracy);
    }
    public static void main(String[] args) {
        expect(true, 60, 100, 10, 3, 1.4);
        expect(true, 90, 100, 10, 3, 0);
        expect(false, 91, 100, 10, 3, 1.4); // GPS uncertainty reaches outside radius
        expect(false, 120, 100, 5, 3, 1.4);
        expect(false, 10, 100, 50, 3, 1.4); // weak GPS
        expect(false, 10, 100, 0, 3, 1.4); // missing precision
        expect(false, 10, 100, 5, 21, 1.4); // stale fix
        expect(false, 10, 100, 5, -1, 1.4);
        expect(false, 10, 100, 5, 3, 12); // driving
        expect(false, Double.NaN, 100, 5, 3, 1.4);
        expect(false, 10, 100, Double.NaN, 3, 1.4);
        expect(false, 10, 100, 5, 3, Double.NaN);
        expect(false, 10, 1000, 5, 3, 1.4);
        expect(true, 10, 25, 5, 3, 1.4);
        System.out.println("14 discovery boundary checks passed");
    }
}
