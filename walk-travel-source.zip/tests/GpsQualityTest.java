import com.lifeinmist.app.GpsQuality;

public class GpsQualityTest {
    static void check(String expected, boolean permission, boolean enabled, float accuracy, long fix, long now) {
        String actual = GpsQuality.state(permission, enabled, accuracy, fix, now);
        if (!expected.equals(actual)) throw new AssertionError(expected + " != " + actual);
    }
    public static void main(String[] args) {
        long now = 100_000_000_000L;
        check("permission", false, true, 5, now, now);
        check("off", true, false, 5, now, now);
        check("waiting", true, true, 5, 0, now);
        check("waiting", true, true, 5, now + 1, now);
        check("waiting", true, true, 5, now - 20_000_000_001L, now);
        check("good", true, true, 15, now - 20_000_000_000L, now);
        check("fair", true, true, 15.1f, now, now);
        check("fair", true, true, 35, now, now);
        check("weak", true, true, 35.1f, now, now);
        check("weak", true, true, 80, now, now);
        check("waiting", true, true, Float.NaN, now, now);
        check("waiting", true, true, 0, now, now);
        System.out.println("GPS quality: 12 checks passed");
    }
}
