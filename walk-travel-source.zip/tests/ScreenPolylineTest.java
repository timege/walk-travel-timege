import com.lifeinmist.app.ScreenPolyline;
import java.util.Arrays;
import java.util.Random;

public class ScreenPolylineTest {
    static void check(boolean ok) { if (!ok) throw new AssertionError(); }
    static void verify(float[] xy, double tolerance) {
        float[] original = xy.clone();
        int count = xy.length / 2;
        int[] kept = ScreenPolyline.simplify(xy, count, tolerance);
        check(Arrays.equals(original, xy));
        if (count == 0) { check(kept.length == 0); return; }
        check(kept[0] == 0 && kept[kept.length - 1] == count - 1);
        for (int k = 1; k < kept.length; k++) {
            int a = kept[k - 1], b = kept[k];
            check(b > a);
            for (int i = a; i <= b; i++) {
                double dx = xy[2*b] - (double)xy[2*a], dy = xy[2*b+1] - (double)xy[2*a+1];
                double px = xy[2*i] - (double)xy[2*a], py = xy[2*i+1] - (double)xy[2*a+1];
                double length = dx*dx + dy*dy;
                double t = length == 0 ? 0 : Math.max(0, Math.min(1, (px*dx + py*dy)/length));
                check(Math.hypot(px - t*dx, py - t*dy) <= tolerance + 1e-6);
            }
        }
    }
    public static void main(String[] args) {
        verify(new float[0], .1);
        verify(new float[] {1,2}, .1);
        verify(new float[] {1,2,1,2,1,2}, .1);
        float[] loop = {0,0,10,0,10,10,0,10,0,0};
        verify(loop, .1);
        check(ScreenPolyline.simplify(loop, 5, .1).length == 5);
        float[] straight = new float[20000];
        for (int i = 0; i < 10000; i++) { straight[2*i] = i; straight[2*i+1] = i * 2; }
        verify(straight, .1);
        int retained = ScreenPolyline.simplify(straight, 10000, .1).length;
        check(retained < 100);
        Random r = new Random(34);
        for (int trial = 0; trial < 200; trial++) {
            float[] points = new float[(2 + r.nextInt(1024))*2];
            for (int i = 0; i < points.length; i++) points[i] = r.nextFloat()*40;
            verify(points, .15);
        }
        System.out.println("200 random error-bound checks, loops, endpoints and source immutability passed.");
        System.out.println("Synthetic straight line: 10000 -> " + retained + " display vertices.");
    }
}
