"""Exercise the actual cursor SQL against SQLite, including old-date imports."""
import pathlib
import re
import sqlite3
import unittest

SOURCE = (pathlib.Path(__file__).parents[1] / "app/src/main/java/com/lifeinmist/app/MistDatabase.kt").read_text()
QUERY = re.search(r'"(SELECT id, walk_id, lat, lon, accuracy, recorded_at FROM permanent_explored_points WHERE id > \? ORDER BY id)"', SOURCE).group(1)
SCHEMA = re.search(r'(CREATE TABLE IF NOT EXISTS permanent_explored_points\s*\(.*?\))', SOURCE, re.S).group(1)
INDEX = re.search(r'"(CREATE UNIQUE INDEX IF NOT EXISTS idx_permanent_explored_unique[^"\n]+)"', SOURCE).group(1)

class IncrementalProgress(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(":memory:")
        self.db.execute(SCHEMA)
        self.db.execute(INDEX)

    def tearDown(self):
        self.db.close()

    def insert(self, timestamp, lat=59.8, walk=1):
        self.db.execute("INSERT OR IGNORE INTO permanent_explored_points(walk_id,lat,lon,accuracy,recorded_at) VALUES (?,?,?,?,?)",
                        (walk, lat, 30.3, 5, timestamp))

    def test_only_new_rows(self):
        self.insert(100)
        first = self.db.execute(QUERY, (0,)).fetchall()
        cursor = first[-1][0]
        self.assertEqual([], self.db.execute(QUERY, (cursor,)).fetchall())
        self.insert(200)
        batch = self.db.execute(QUERY, (cursor,)).fetchall()
        self.assertEqual([200], [p[5] for p in batch])

    def test_import_of_old_points_and_duplicate(self):
        self.insert(1000)
        cursor = self.db.execute(QUERY, (0,)).fetchall()[-1][0]
        self.insert(1000)  # identical backup point must not duplicate progress
        self.insert(10, lat=59.9, walk=-42)  # historical restored segment
        batch = self.db.execute(QUERY, (cursor,)).fetchall()
        self.assertEqual(1, len(batch))
        self.assertEqual((-42, 10), (batch[0][1], batch[0][5]))
        self.assertEqual(2, len(self.db.execute(QUERY, (0,)).fetchall()))

    def test_restart_and_indexed_cursor(self):
        for i in range(100): self.insert(i)
        self.assertEqual(100, len(self.db.execute(QUERY, (0,)).fetchall()))
        self.assertEqual(1, len(self.db.execute(QUERY, (99,)).fetchall()))
        plan = str(self.db.execute("EXPLAIN QUERY PLAN " + QUERY, (99,)).fetchall())
        self.assertIn("SEARCH", plan)
        self.assertIn("PRIMARY KEY", plan)

if __name__ == "__main__":
    unittest.main()
