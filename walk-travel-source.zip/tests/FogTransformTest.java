import com.lifeinmist.app.FogTransform;

public class FogTransformTest {
    private static void near(double actual, double expected) {
        if (Math.abs(actual - expected) > 1e-8) throw new AssertionError(actual + " != " + expected);
    }
    private static void check(boolean value) {
        if (!value) throw new AssertionError("Coverage mismatch");
    }
    public static void main(String[] args) {
        near(FogTransform.scale(12, 15), 0.125);
        near(FogTransform.scale(20, 15), 32); // no artificial zoom clamp
        near(FogTransform.rotation(90, 0), -90);
        near(FogTransform.rotation(1, 359), -2);
        near(FogTransform.rotation(359, 1), 2);
        check(FogTransform.covers(400, 800, 200, 400, 800, 1600, 0));
        check(FogTransform.covers(400, 800, 200, 400, 800, 1600, 90));
        check(!FogTransform.covers(400, 800, 200, 400, 100, 200, 0));
        check(!FogTransform.covers(400, 800, 200, 400, 230, 450, 90));
        check(!FogTransform.covers(400, 800, 1800, 400, 800, 1600, 0));
        check(!FogTransform.covers(400, 800, 200, 400, 230, 450, 45));
        // Simulated world point: cache at bearing A, rotate it to bearing B.
        for (int a = 0; a < 360; a += 15) {
            for (int b = 0; b < 360; b += 15) {
                double ca = Math.cos(Math.toRadians(-a)), sa = Math.sin(Math.toRadians(-a));
                double delta = Math.toRadians(FogTransform.rotation(b, a));
                double x = 20 * ca - 70 * sa, y = 20 * sa + 70 * ca;
                double cb = Math.cos(Math.toRadians(-b)), sb = Math.sin(Math.toRadians(-b));
                near(x * Math.cos(delta) - y * Math.sin(delta), 20 * cb - 70 * sb);
                near(x * Math.sin(delta) + y * Math.cos(delta), 20 * sb + 70 * cb);
            }
        }
        System.out.println("Zoom/coverage checks and 576 bearing pairs passed");
    }
}
