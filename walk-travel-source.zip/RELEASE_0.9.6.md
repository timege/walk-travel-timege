# Walk Travel Timege 0.9.6 (45) — pending build approval

- One Liberty map style.
- Ocean and coast visible through fog, based on the map's ocean polygons.
- 75 m map previews around points of interest, separate from explored progress.
- No question-mark prefix in the places list; visited items retain a check mark.
- Offline area downloads with names, progress, downloaded size, pause/resume and deletion.
- Foreground-only downloading with persistent partial/completed regions.
- No clustering of POIs.

Source prepared only. Not compiled or tested on an Android device.
See PENDING_CHANGES.md for the full change list, validation status and limits.
