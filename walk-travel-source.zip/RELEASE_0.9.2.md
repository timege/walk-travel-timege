# Walk Travel Timege 0.9.2

## Added
- Walk completion card with distance, duration and places discovered during that walk.
- Walk history available from the progress menu; any saved walk can reopen its details card.
- In-app discovery banner with a **View** action while the app is open.
- Android discovery notifications with a **View** action while the app is in the background.
- Notification tap opens the discovered place card directly.

## Fixed
- Notification permission is requested even when location permission had already been granted on a previous install.
- Location permission handling no longer treats notification permission alone as sufficient to start tracking.

## Internal
- Version: 0.9.2 (41).
- No database schema migration required.
