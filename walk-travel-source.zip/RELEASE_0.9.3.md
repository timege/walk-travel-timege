# Walk Travel Timege 0.9.3

## Added
- Android home-screen widget.
- Today's walking distance.
- Number of places discovered during the last 7 days.
- One-tap **Start walk** action from the widget when permissions are already granted.
- The same widget button changes to **Finish** while a walk is being recorded.
- If Android still needs location/notification permission, the widget opens the app and continues through the normal permission flow.

## Updated
- Widget content refreshes when tracking starts or stops, after discoveries, and periodically during an active walk.
- Widget text follows the app's English/Russian language setting.

## Data safety
- No database schema change.
- Existing walk history, explored map progress, discoveries and backups remain compatible.

## Internal
- Version: 0.9.3 (42).
