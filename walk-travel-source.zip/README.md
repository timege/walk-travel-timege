# Walk Travel Timege v0.9.3

- Android home-screen widget: today's distance, discoveries over the last 7 days, and Start/Finish walk.
- One-tap widget start works directly when required permissions already exist; otherwise the app opens the normal permission flow.
- Widget follows the selected English/Russian UI language and refreshes during active tracking.
- No database migration; existing progress remains compatible.

# Walk Travel Timege v0.9.1

- Map menu → Language / Язык: English and Russian, saved across restarts.
  UI text, GPX dialogs, GPS details, search language and recording notifications
  follow the selection. Authored content and system dialogs are left intact.
- GPS is a small top-right badge with a 48 dp touch area; tap for full details.
  The top search/destination panels reserve space for it. The duplicate SDK compass
  is hidden; the app's existing compass remains at bottom right.
- Map camera, destination and route segments are retained during language changes.
  Recording stays in the service and progress is not reset.
- Preserves the user's 0.9.0 lastRouteSegments guard and the corrected animated clouds.
- Android device checks still needed: switch languages during recording and with a
  GPX route selected; check both layouts with a large system font.

- Based on the supplied 0.8.8 archive with animated-cloud lifecycle and repeat fixes.
- English app interface, native sans-serif typography with medium-weight controls,
  and About with © 2026 Timege. Authored place content and map labels are not translated.
- GPS badge shows accuracy and freshness; tap for details. Poor fixes are reported
  without changing the recording filters or strict discovery rules.
- Map menu: Export GPX (choose a recorded walk), Import GPX route, About.
  Imports remain reference routes; they never modify exploration or discoveries.
  GPX 1.0/1.1 tracks/routes, multiple tracks and segment gaps are supported.
  The selected import persists locally across restarts. Select another destination
  or close its card to remove it. Import limit: 20 MB / 200,000 points.
- GPX exports contain original coordinates and UTC timestamps. Elevation is not
  invented because the current recording database does not store it.
- See RELEASE_0.9.0.md for validation and the agreed next stages.

- Version 0.8.8 rounds place cards to 24 dp, preserving dialog insets and theme
  background, and renames the locked card title to «Место ждёт открытия».
- Version 0.8.7 simplifies only display paths using bounded 128-point RDP blocks.
  Source GPS points remain unchanged. Error at rebuild: 0.1 screen px for routes,
  0.15 cache px for mask edges (about 0.47 screen px at rebuild).
  Large zoom changes restore appropriate route detail. Two reusable mask bitmaps
  alternate; each back buffer is cleared before drawing. This trades a second
  retained bitmap for less allocation churn; device FPS/memory are not measured.
- Version 0.8.6 adds conservative mask culling in overlapping 128-point chunks.
  Bounds include the oversized mask cache and maximum stroke/feather extent.
  All GPS points remain stored; antimeridian ambiguity falls back to rendering.
  Synthetic test: 1,280,000 point projections become 41,280 bounds/point projections
  with 10 near and 9,990 far chunks. This is an operation count, not measured device
  frame time; all-local tracks benefit less. Full Android/device validation is pending.
- Version 0.8.5 reads progress on a single background worker with an indexed ID cursor,
  coalesces GPS refresh requests and repairs the permanent table once per database
  helper (and explicitly after imports). Restore resets the cursor. Camera idle no
  longer rebuilds unchanged route geometry; mask resolution refresh uses a zoom threshold.
- Version 0.8.4 caches projected route contours, groups explored segments on data
  updates, pre-renders location/destination effects and uses hardware rendering
  on API 28+. No track points are removed. Reprojection occurs on data changes
  and camera idle. Real-device frame timing and full Android build are unverified.
- Version 0.8.3 removes per-frame full-screen offscreen compositing and redundant
  bitmap layers. Gestures reuse the cached mask until its actual coverage runs out;
  GPS/quality refreshes are coalesced at camera idle. Device frame timing is unverified.
- Version 0.8.2 fixes mask zoom/rotation: full-viewport cover, gesture-time cache
  renewal, corrected rotation and rotation-independent opening radius.
  Retains the original green UI; the proposed redesign is deferred.
- Version 0.8.0 adds discoverable places: map markers, proximity unlocks,
  place cards, a collection, WordPress feed support and JSON import. See PLACES.md.
- The map mask is now a uniform light grey-blue at 95% opacity, without textures.
- Unexplored map is fully covered; explored GPS corridors stay clear permanently.
- Soft feathered cloud edges remain around explored territory.
- Progress stays in kilometers, with `км` on a separate line in the UI.
- Persistent signing/update and backup/restore logic are preserved.

Walk Travel Timege v0.5.8

# Walk Travel Timege v0.5.5

UI: compact left vertical skeuomorphic exploration menu, permanent explored-distance counter, denser cloud cover, thin permanent explored route line, search shown only on demand. Progress backup/restore and update-safe database are preserved.

# Walk Travel Timege — v0.5.4

Android prototype of a persistent exploration map.

## v0.5.4

- New green/lime skeuomorphic visual theme based on the approved mockup.
- Tactile layered search panel, search/layers buttons, location button, compass and Start/Finish button.
- Green route and destination styling.
- Softer irregular cloud clusters for unexplored areas.
- Permanent explored-world progress remains unchanged.
- Backup/restore progress remains available from the layers menu.
- Same application id and incremented versionCode for normal Android updates.


## v0.5.7
- Self-healing permanent explored layer: historical track points are merged back before every render.
- Restore now repopulates explored cloud cutouts even when track history already existed.
- Import verifies persisted explored points before redrawing/focusing the map.


## v0.6.0
- 5 animated cloud layers with slow drift
- explored territory remains permanently cut out of the cloud field
- progress is hidden from the main interface and shown only on tapping the statistics button
- progress popup: total, today, 7 days, last walk, walk count
